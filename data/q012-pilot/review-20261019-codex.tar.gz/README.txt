Codex Q-012 amended P11 review, 19 October 2026.

Execution snapshots and evidence, not a new production package. The review
in ideas/2026-10-19-q012-amended-p11-review-codex.md controls interpretation.
The full joint replay in replay.py terminated with exit 143 before a result;
replay.json covers completed provenance/statistics only. spot_checks.json
records the two completed direct quadrature checks. trajectory-agent results
are finite fresh-momentum diagnostic paths, not original sampler replay.

Paths retain their original scratch layout. Inspect/extract into a temporary
directory before choosing whether to restore that layout under the repository.
The scripts expect the repository as cwd, its existing pilot Python environment,
the hash-bound local model executable and fetched chain banks; raw chain banks
are not duplicated here. Consult protocol.json for binary/data/source hashes.
Run order for the trajectory probe was probe.py, minimum_stress.py, then
endpoint_fd.py. Their shared 2,000-call cap includes all three stages (1,982 used).
The memo has a later read-only instrumentation feasibility addendum.

# Uses the same evaluator/integrator definitions, without rerunning probe main.
import pathlib,json
P=pathlib.Path('scratch/q012-p11-amended-review-20261019/trajectory-agent/probe.py')
exec(compile(P.read_text().split('# Analytic normal toy')[0],str(P),'exec'))
base=json.loads((O/'results.json').read_text());COUNT=base['actual_gradient_evaluations']
protocol=json.loads((O/'protocol.json').read_text()); states=protocol['selection'];results=[]
for state in [s for s in states if s['name'].endswith('-min')]:
 q=np.array(state['q']);_,metric,h=CHAINS[state['chain']];z=np.zeros(q.size);z[IS]=-math.sqrt(q.size);p=z/np.sqrt(metric);initial=ev(q)
 pair={'state':state['name'],'chain':state['chain'],'momentum':'directional_stress_negative_log_sigma_equal_typical_total_kinetic_energy','z':z.tolist(),'initial':obs(q),'inv_metric':metric.tolist()}
 for label,hh,L in [('h',h,24),('h2',h/2,48)]:pair[label]=integrate(q,p,metric,hh,L,initial)
 results.append(pair);print(json.dumps({'state':state['name'],'count':COUNT,**{k:{n:pair[k][n] for n in ['status','max_signed_deltaH','min_signed_deltaH']} for k in ['h','h2']}}),flush=True)
fd=[]
for pair in results:
 for k in ['h','h2']:
  if pair[k]['status']!='positive_energy_divergence' or COUNT+13>CAP:continue
  q=np.array(pair[k]['end_q']);lp,g,e=ev(q);out=[]
  if e:continue
  for ix in sorted(set([IS,NAMES.index('kappa_b'),int(np.argmax(np.abs(g)))])):
   for step in [1e-4,1e-5]:
    qp=q.copy();qm=q.copy();qp[ix]+=step;qm[ix]-=step;a,_,ea=ev(qp);b,_,eb=ev(qm)
    if ea or eb:out.append({'coordinate':NAMES[ix],'step':step,'error_plus':ea,'error_minus':eb});continue
    d=(a-b)/(2*step);out.append({'coordinate':NAMES[ix],'step':step,'ad':float(g[ix]),'fd':d,'scaled_abs_error':abs(d-g[ix])/max(1,abs(d),abs(g[ix]))})
  fd.append({'state':pair['state']+'-'+k,'checks':out})
dump(O/'minimum_stress.json',{'previous_count':base['actual_gradient_evaluations'],'total_actual_gradient_evaluations':COUNT,'cap':CAP,'pairs':results,'finite_differences':fd,'elapsed_extra_seconds':time.monotonic()-START})

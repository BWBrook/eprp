# Bounded actual-Stan P11 trajectory probe

**Completed:** 1,982 actual log-density/AD calls of the existing local v6 binary, below the 2,000 cap; serial execution, about 97 seconds total. No compile, fit, installation, remote call or tracked edit. Every matched path completed with finite energies and gradients; no positive deltaH > 1,000 and no numerical rejection. This does not reproduce either original divergence.

## Target, transforms, metric and integrator checks

Used exact `payload_v6p2/data/P11.json` (N=19, Q=64, f_tol=1e-10). Local model source is byte-identical to payload source; binary/data/chain/source hashes are in `protocol.json`. The existing local binary is not the cluster binary. Both target comparisons use Jacobian=true and proportional constants dropped, as does the sampler.

Unconstrained coordinate order is 54 coordinates: log_h0_1, z_rw[1:24], log(tau), log_k, log_lambda0, kappa, log_b0, kappa_b, beta, gamma, log(sigma), logit(rho), w[1:19]. Stan output gradient names assert this ordering on every call. A constrained-versus-manual-unconstrained comparison matches log density and every gradient exactly. Saved CSV lp differs by 1.30e-6, consistent with its 8-digit precision.

The CSV inverse mass v means K=.5 sum(v*p^2), dq/dt=v*p, and p~N(0,diag(1/v)). This is verified in installed CmdStan 2.38 / Stan sources: `diag_e_metric.hpp`; `base_leapfrog.hpp` / `expl_leapfrog.hpp` set the half-kick / full-drift / half-kick sequence; `model_functional.hpp` uses log_prob<true,true>; `command_helper.hpp` services_log_prob_grad also uses <true,true>. Unconstrained input is JSON variable params_r, not an invented CSV convention. `base_nuts.hpp` tests signed H-H0 >1000, not abs(H-H0). Source hashes are retained.

Recovered h uses stepsize__ in each saved CSV row: chain 1 0.039571317, chain 2 0.047472732. Inverse metrics come from their CSV adaptation comments, which are rounded to about six significant digits. Starts are rounded saved CSV states and momenta are fresh NumPy Gaussian draws (seed 20261019017), not Stan's original unsaved momenta. These paths are deliberately not claimed as exact replays.

Analytic two-dimensional normal toy reverses to <4e-16 and reduces energy error approximately fourfold at h/2 over equal integration time. An actual-target 8-step forward/reverse check returns q within 2.22e-16 and p within 5.33e-15.

## Defined starts and matched paths

In each chain: state immediately before the divergent transition, minimum saved sigma, closest saved sigma to the 1% empirical quantile, and closest to the median. Prediv starts are retained rows 2425 and 4651, preceding divergent rows 2426 / 4652 (total transitions 4426 / 6652). All random paths use 64 steps at fitted h and 128 at h/2. Additional negative-log-sigma stress momenta put all typical kinetic energy (54/2) in that one direction: 32/64 steps from prediv starts; 24/48 from minimum-sigma starts. These stress directions have no frequency interpretation.

| Start | Momentum | Initial sigma | min sigma at h / h2 | signed deltaH range at h | signed deltaH range at h2 |
|---|---|---:|---:|---:|---:|
| c1-prediv | Gaussian | 1.3787 | 1.08 / 1.09 | -0.10873 to 0.14546 | -0.028783 to 0.030604 |
| c1-min | Gaussian | 4.9497e-05 | 4.26e-05 / 4.25e-05 | -0.011454 to 0.036748 | -0.0029585 to 0.0090664 |
| c1-q01 | Gaussian | 0.0063418 | 0.00634 / 0.00634 | -0.0088959 to 0.018257 | -0.0022269 to 0.0045093 |
| c1-central | Gaussian | 0.33253 | 0.287 / 0.288 | -0.020952 to 0.01515 | -0.0053318 to 0.0038521 |
| c2-prediv | Gaussian | 0.030497 | 0.0184 / 0.0183 | -0.010243 to 0.0031487 | -0.0025878 to 0.00078978 |
| c2-min | Gaussian | 4.2276e-05 | 4.23e-05 / 4.23e-05 | -0.071638 to 0.072612 | -0.018253 to 0.018051 |
| c2-q01 | Gaussian | 0.0030528 | 0.00292 / 0.00292 | -0.038332 to 0.00080675 | -0.0095839 to 0.00079835 |
| c2-central | Gaussian | 0.33179 | 0.142 / 0.142 | -0.057531 to 0.026568 | -0.014545 to 0.0064585 |
| c1-prediv | directed stress | 1.3787 | 0.0517 / 0.0621 | 0 to 3.5482 | 0 to 0.83324 |
| c2-prediv | directed stress | 0.030497 | 4.57e-06 / 4.45e-06 | -1.0862 to 0.70553 | -0.27298 to 0.18974 |
| c1-min | directed stress | 4.9497e-05 | 7.72e-09 / 7.02e-09 | -6.2858 to 0.92229 | -1.7409 to 0.33284 |
| c2-min | directed stress | 4.2276e-05 | 1.9e-08 / 1.67e-08 | -6.4398 to 2.1457 | -1.8793 to 0.48202 |

The fresh-momentum paths show ordinary h^2 scaling of maximal absolute energy error: for example c1-prediv .1455 -> .03060 and c2-min .07261 -> .01825. Deep stress paths have larger, often negative, energy errors; signed reporting matters because negative errors of -6.4 do not meet Stan's divergence condition.

## Gradients and curvature

Central finite differences at steps 1e-4 / 1e-5 check log(sigma), kappa_b and the largest gradient coordinate at both prediv and both minimum-sigma starts. Maximum scaled AD-FD discrepancy is 3.71e-07. At the two deepest h/2 stress endpoints (sigma 7.02e-9 and 1.67e-8), the analogous log(sigma), kappa_b and largest-w-gradient comparisons have maximum scaled discrepancy 8.52e-10. These checks concern derivatives of the implemented approximate log density; they are not an independent proof of exact quadrature accuracy.

At those deep endpoints, finite differences of AD give w-coordinate potential curvature about 1826 and 1291. The corresponding fitted h*sqrt(v_w*curvature) values are 1.34 and 1.20. Conditional w-prior curvature is sigma^(-0.4) under a=.2, which grows without bound toward zero. The probe therefore demonstrates a concrete source of tail stiffness while gradients remain locally accurate at checked points. It does not identify the location or cause of either original rare energy failure. A diagonal curvature is not a full Hessian eigenvalue or a global stability certificate.

## Decision assessment

**A single adapt_delta=.999 P11 resolution trial is defensible as a bounded computational test, with the exact target, a=.2, priors, f_tol, Q, seed/starts, 2,000+8,000 draws, screens and resource ceiling unchanged.** The local h/2 comparisons supply affirmative finite evidence that smaller steps improve resolution at these states. They do not predict the h selected by .999, its new adapted metric, runtime, rare-divergence rate, or a pass. An adaptation run will follow a different warmup path; .999 is not equivalent to fixing the present metric and exactly halving h.

The more discriminating alternative is passive divergence-only instrumentation in that same prospective trial. Preserve the actual transition initial q/p, previous and failing leapfrog q/p and lp/gradient, signed epsilon, inverse metric and H0/current H at >=17 digits, with chain/transition labels and a bound on log volume. An unexpected numerical exception also needs the attempted unconstrained q. A diagnostic_file alone is insufficient if it writes the selected state rather than the failing leapfrog. Keep sampler RNG and arithmetic unchanged and bind the instrumented source/binary. If instrumentation is deferred, a clean .999 run may supply a prospective technical pass; another failure should stop blind delta/alpha/seed tuning and require actual-path capture before further fits. No prior/floor change follows from this probe.

The strictly concave log kernel has a unique valid root: genuine competing root switches are mathematically excluded. Numerical solver convergence and gradient accuracy remain empirical questions. The checks here find no defect at their finite points, but cannot clear unsampled regions.

## Shared-prefix causal correction

Identical finite-precision saved CSV values demonstrate the same recorded output prefix. They do not establish identical unsaved trajectories, prove the tolerance amendment changed no proposal, or imply that every change to an unsaved proposal must change every subsequent saved draw. A formerly rejected point could become finite without being selected or altering the recorded trajectory. Nor does the unchanged divergence label locate that formerly rejected point. The amendment did not eliminate the same recorded divergence; its original causal path remains unidentified.

## Limits and next owner

This fixed finite probe cannot estimate a failure frequency, establish sampler validity, exonerate unvisited regions, prove either original divergence was at small sigma, or support biological inference. No primary or panel fit is released by this memo. Parent Codex integrates the evidence and decides the bounded next method with Claude; all other panel cases remain held.

2026-10-19 11:21:45 AEDT

## Follow-up: unchanged-sampler diagnostic replay is preferred

Parent proposes unchanged adapt_delta=.995 and only chain IDs 1–2, seed 77017,
the exact data/starts/f_tol=1e-10/a=.2/Q64, 2,000 warmup plus 6,000 retained
draws. Both known failures (total transitions 4426 / 6652) lie inside that
run. This is a more discriminating next action than .999 adaptation: it
attempts to recover actual known failure coordinates rather than changing
the path before observing it. It supports no new qualified-posterior claim.
Two CPUs, 8 GiB, 3-hour runner / 3:10 PBS plus one 4-CPU, 1-hour build reserve
at most 10.333 core-hours. No fatal methodological or source-level feasibility
problem was found; this inspection does not guarantee runtime or exact replay.

Pinned Stan source permits a small passive patch:

- `stan/src/stan/mcmc/hmc/nuts/base_nuts.hpp:84–85`: after existing momentum
  sampling and Hamiltonian initialization, copy the complete transition-initial
  `ps_point` to an observational member buffer. Do not later use `z_fwd` as the
  initial state because it is overwritten during tree expansion. A member
  transition counter, initialized to zero and incremented once on entry to
  `transition`, counts warmup and sampling; `init_stepsize` does not call this
  transition method. For this bound run, counters 1–2000 are warmup, then
  sampling; per-process sidecar/metadata identifies chain ID.
- `base_nuts.hpp:253–255`: copy `ps_point` immediately before the existing
  `integrator_.evolve`, retaining previous q,p,V,g. Reusable member buffers
  (`ps_point trace_initial_{0}`, `trace_previous_{0}`) avoid per-leaf allocation;
  their copy assignment resizes on first use. Copy only observational state.
- `base_nuts.hpp:258–263`: snapshot the existing computed raw H before its
  existing NaN-to-infinity conversion; on the existing signed `(h-H0)>1000`
  branch emit the initial, previous and current q,p,V,g, H0/raw H/checked H,
  signed epsilon, full current inverse metric, transition counter and leapfrog
  ordinal. Preserve the sampler's arithmetic, conditions, returns, force calls
  and RNG calls exactly; do not evaluate extra target functions or reinitialize
  the Hamiltonian for diagnostics.
- `base_hamiltonian.hpp:61–69`: stored g is gradient of **potential V**, hence
  minus the LPAD gradient. On a caught domain error, V becomes infinity and
  stored g can be stale or sign-flipped; it must not be presented as a valid
  failing-point derivative. Preserve it with an explicit validity caveat and
  inspect gradients later by deterministic LPAD. Nonfinite coordinates/values
  need a defined serialization rather than invalid JSON or silent omission.
- `diag_e_point.hpp:44–51`: do not call its ordinary `write_metric` for the
  capture, since its fresh stringstream uses default precision. Serialize
  inverse-metric entries and all scalar/vector fields explicitly at >=17
  significant digits (e.g. an independent stream and numeric loops).

A failing leaf returns `!divergent_` at `base_nuts.hpp:281`; recursive calls
return immediately on that false result (`:299–300`, `:318–319`) and the
transition exits tree expansion at `:157–158`. No further leapfrog leaf is
executed in that transition. Thus first-per-transition capture is complete for
this implementation; subsequent warmup step-size searches are a different
path, not additional NUTS leaves. If bounding emitted events, keep separate
warmup and sampling budgets (e.g. first four of each per chain), record dropped
counts and a final trace summary, and never let the logging limit alter sampler
control or RNG. A shared first-four cap could be exhausted during warmup and
miss the relevant sampling events. A trace-writing failure should be reported
as a diagnostic failure, not silently described as a successful capture.

`services/util/run_adaptive_sampler.hpp:70–96` passes num_samples only to loop
bounds/progress finish; warmup-window construction in
`services/sample/hmc_nuts_diag_e_adapt.hpp:99` depends on num_warmup. Chain RNG
creation uses the fixed seed and chain ID (`services/util/create_rng.hpp:28–32`).
Keeping thin=1, save_warmup=false, generated-quantity behavior and separate
chain invocations identical means 6,000 versus 8,000 retained draws has no
intended effect on the first 6,000 rows. Compare all 125 recorded columns of
all 6,000 rows per chain, including sampler diagnostics, plus step/metric
records. Report the first mismatch if any. Recompilation/instrumentation may
still change floating-point execution, and identical rounded rows alone do
not prove identical hidden paths. Call this exact recorded-prefix replay only
when the prefix comparison succeeds; otherwise preserve the discrepancy and
analyze any newly captured event without claiming it is the original one.

This follow-up was source inspection only: no further LPAD calls, tests,
compilation, remote calls or board messages. Parent Codex owns integration and
handoff to Claude.

"""Bounded deterministic log_prob-only Hamiltonian probe; no fitting/compilation."""
import csv, hashlib, json, math, os, pathlib, subprocess, time
import numpy as np
R=pathlib.Path.cwd(); O=R/'scratch/q012-p11-amended-review-20261019/trajectory-agent'
B=R/'scratch/q012-prototype/model_v6'; DATA=R/'data/q012-pilot/payload_v6p2/data/P11.json'
RUN=R/'scratch/q012-pilot/fetch-20261018-v6p2/runs/P11/attempt1'
SRC=pathlib.Path('/home/bwbrook/.cmdstan/cmdstan-2.38.0')
CAP=2000; COUNT=0; START=time.monotonic(); SEED=20261019017
ENV=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',STAN_NUM_THREADS='1')
N=json.loads(DATA.read_text())['N']
NAMES=['log_h0_1']+[f'z_rw.{j}' for j in range(1,25)]+['tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']+[f'w.{j}' for j in range(1,N+1)]
IS=NAMES.index('sigma'); IW=NAMES.index('w.1'); IR=NAMES.index('rho'); IT=NAMES.index('tau')
def dump(path,x): path.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def readchain(c):
 p=RUN/f'chain{c}.csv'; txt=p.read_text(); lines=txt.splitlines()
 metric=np.array([float(x) for x in lines[next(i for i,x in enumerate(lines) if 'Diagonal elements of inverse mass matrix' in x)+1][2:].split(',')])
 rows=list(csv.DictReader(l for l in lines if l and not l.startswith('#')))
 assert len(rows)==8000 and len(metric)==len(NAMES)
 h=float(rows[0]['stepsize__']); assert all(float(row['stepsize__'])==h for row in rows)
 return rows,metric,h
CHAINS={c:readchain(c) for c in [1,2]}
def unc(row):
 q=np.array([float(row[k]) for k in NAMES]);q[IT]=math.log(q[IT]);q[IS]=math.log(q[IS]);q[IR]=math.log(q[IR])-math.log1p(-q[IR]);return q

def ev(q,constrained=False):
 global COUNT
 if COUNT>=CAP: raise RuntimeError('gradient cap reached')
 COUNT+=1
 if constrained:
  vals=dict(zip(NAMES,q)); cp={k:v for k,v in vals.items() if not k.startswith(('w.','z_rw.'))};cp['w']=[vals[f'w.{j}'] for j in range(1,N+1)];cp['z_rw']=[vals[f'z_rw.{j}'] for j in range(1,25)]
  dump(O/'current-c.json',cp);arg=f'constrained_params={O/"current-c.json"}'
 else: dump(O/'current-u.json',{'params_r':q.tolist()});arg=f'unconstrained_params={O/"current-u.json"}'
 cmd=[str(B),'log_prob',arg,'jacobian=1','data',f'file={DATA}','output',f'file={O/"current-out.csv"}','sig_figs=18']
 assert cmd[1]=='log_prob'
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=15,env=ENV)
 if p.returncode:
  err=(p.stdout+p.stderr)[-4000:];return None,None,err
 lines=[l for l in (O/'current-out.csv').read_text().splitlines() if l and not l.startswith('#')]
 row=list(csv.DictReader(lines));assert len(row)==1
 row=row[0];assert list(row)==['lp__']+['g_'+x for x in NAMES]
 lp=float(row['lp__']);g=np.array([float(row['g_'+x]) for x in NAMES])
 if not math.isfinite(lp) or not np.all(np.isfinite(g)):return None,None,'nonfinite output'
 return lp,g,None

def obs(q):
 s=math.exp(q[IS]) if q[IS]<700 else float('inf'); w=q[IW:];eps=w/math.exp(.2*q[IS])
 return {'log_sigma':float(q[IS]),'sigma':s,'w_norm':float(np.linalg.norm(w)),'max_abs_w':float(np.max(np.abs(w))),'eps_norm':float(np.linalg.norm(eps)),'max_abs_eps':float(np.max(np.abs(eps)))}

def integrate(q0,p0,metric,h,L,initial=None,stop_div=True):
 q=q0.copy();p=p0.copy(); lp,g,e=ev(q) if initial is None else initial
 assert e is None
 H0=-lp+.5*float(np.dot(p,metric*p));hist=[];hist.append(dict(step=0,time=0.,deltaH=0.,**obs(q)))
 lastg=g.copy(); lastlp=lp;status='completed'
 for l in range(1,L+1):
  p+=.5*h*g;q+=h*metric*p
  lp,g,e=ev(q)
  if e:
   hist.append(dict(step=l,time=l*h,deltaH=None,error=e,**obs(q)));status='gradient_rejection';break
  p+=.5*h*g;H=-lp+.5*float(np.dot(p,metric*p));dH=H-H0
  hist.append(dict(step=l,time=l*h,deltaH=float(dH),**obs(q)))
  lastg=g.copy();lastlp=lp
  if not math.isfinite(dH):status='nonfinite_energy';break
  if stop_div and dH>1000:status='positive_energy_divergence';break
 return {'status':status,'h':h,'requested_steps':L,'requested_time':h*L,'H0':H0,'max_signed_deltaH':max(x['deltaH'] for x in hist if x['deltaH'] is not None),'min_signed_deltaH':min(x['deltaH'] for x in hist if x['deltaH'] is not None),'history':hist,'end_q':q.tolist(),'end_p':p.tolist(),'end_lp':lastlp,'end_g':lastg.tolist()}

# Analytic normal toy validates metric, force sign, update order, reversibility and h convergence.
def toy(h,L):
 q=np.array([.9,-.7]);p=np.array([.4,1.2]);metric=np.array([.3,2.]);q0=q.copy();p0=p.copy();H0=.5*np.dot(q,q)+.5*np.dot(p,metric*p)
 def f(q,p,h,L):
  for _ in range(L):p-=.5*h*q;q+=h*metric*p;p-=.5*h*q
  return q,p
 q,p=f(q,p,h,L);dh=.5*np.dot(q,q)+.5*np.dot(p,metric*p)-H0
 qr,pr=f(q.copy(),-p.copy(),h,L)
 return {'deltaH':float(dh),'reversibility_q':float(np.max(np.abs(qr-q0))),'reversibility_p':float(np.max(np.abs(pr+p0)))}
TOY={'h':toy(.1,20),'h2':toy(.05,40)}
assert TOY['h']['reversibility_q']<1e-13 and TOY['h']['reversibility_p']<1e-13 and abs(TOY['h2']['deltaH'])<abs(TOY['h']['deltaH'])/3

# Selection depends only on recorded sigma and divergent transition locations.
states=[]
for c in [1,2]:
 rows,metric,h=CHAINS[c]; div=[i for i,x in enumerate(rows) if float(x['divergent__'])==1];assert len(div)==1
 ix=div[0]-1
 states.append({'name':f'c{c}-prediv','chain':c,'retained_row':ix+1,'q':unc(rows[ix]).tolist(),'next_divergent_retained_row':div[0]+1})
 sig=np.array([float(x['sigma']) for x in rows])
 for label,quant in [('min',0.),('q01',.01),('central',.5)]:
  ix=int(np.argmin(np.abs(sig-np.quantile(sig,quant))))
  states.append({'name':f'c{c}-{label}','chain':c,'retained_row':ix+1,'q':unc(rows[ix]).tolist()})

dump(O/'protocol.json',{'seed':SEED,'gradient_cap':CAP,'N':N,'coordinate_names':NAMES,'selection':states,'integration':'8 fresh Gaussian momenta, matched h x64 and h/2 x128; 2 prediv directional stress h x32 and h/2 x64; stop positive deltaH >1000 or numerical failure','metric':'CSV inverse mass v: K=.5 sum(v*p^2), dq/dt=v*p, p~N(0,diag(1/v))','binary_sha256':sha(B),'data_sha256':sha(DATA),'chain_sha256':{str(c):sha(RUN/f'chain{c}.csv') for c in CHAINS},'source_sha256':{str(p.relative_to(SRC)):sha(p) for p in [SRC/'src/cmdstan/command_helper.hpp',SRC/'stan/src/stan/mcmc/hmc/hamiltonians/diag_e_metric.hpp',SRC/'stan/src/stan/mcmc/hmc/integrators/expl_leapfrog.hpp',SRC/'stan/src/stan/mcmc/hmc/nuts/base_nuts.hpp']}})

first=states[0];q=np.array(first['q']); rows,metric,h=CHAINS[first['chain']]; row=rows[first['retained_row']-1];lp,g,e=ev(q);assert e is None
lpc,gc,ec=ev(np.array([float(row[k]) for k in NAMES]),constrained=True);assert ec is None
TRANS={'lp_absdiff':abs(lp-lpc),'max_gradient_absdiff':float(np.max(np.abs(g-gc))),'csv_lp_absdiff':abs(lp-float(row['lp__']))}
assert TRANS['lp_absdiff']<1e-10 and TRANS['max_gradient_absdiff']<1e-8 and TRANS['csv_lp_absdiff']<1e-4
print(json.dumps({'ready':True,'transform_check':TRANS,'toy':TOY}),flush=True)

rng=np.random.default_rng(SEED); results=[]
for state in states:
 q=np.array(state['q']);rows,metric,h=CHAINS[state['chain']];z=rng.normal(size=q.size);p=z/np.sqrt(metric)
 pair={'state':state['name'],'chain':state['chain'],'retained_row':state['retained_row'],'momentum':'fresh_gaussian','z':z.tolist(),'initial':obs(q),'inv_metric':metric.tolist()}
 initial=ev(q)
 for label,hh,LL in [('h',h,64),('h2',h/2,128)]:pair[label]=integrate(q,p,metric,hh,LL,initial)
 results.append(pair);dump(O/'partial.json',{'actual_gradient_evaluations':COUNT,'pairs':results});print(json.dumps({'pair':state['name'],'count':COUNT,**{k:{n:pair[k][n] for n in ['status','max_signed_deltaH','min_signed_deltaH']} for k in ['h','h2']}}),flush=True)
for state in [x for x in states if x['name'].endswith('prediv')]:
 q=np.array(state['q']);rows,metric,h=CHAINS[state['chain']];z=np.zeros(q.size);z[IS]=-math.sqrt(q.size);p=z/np.sqrt(metric)
 pair={'state':state['name'],'chain':state['chain'],'retained_row':state['retained_row'],'momentum':'directional_stress_negative_log_sigma_equal_typical_total_kinetic_energy','z':z.tolist(),'initial':obs(q),'inv_metric':metric.tolist()};initial=ev(q)
 for label,hh,LL in [('h',h,32),('h2',h/2,64)]:pair[label]=integrate(q,p,metric,hh,LL,initial)
 results.append(pair);dump(O/'partial.json',{'actual_gradient_evaluations':COUNT,'pairs':results});print(json.dumps({'stress':state['name'],'count':COUNT,**{k:{n:pair[k][n] for n in ['status','max_signed_deltaH','min_signed_deltaH']} for k in ['h','h2']}}),flush=True)

# Actual-target finite differences at both prediv starts, both sigma minima,
# plus every finite positive-energy divergence endpoint. Two step sizes,
# sigma, kappa_b, and dominant force coordinate; preserve signed discrepancies.
fd=[];targets=[]
for st in states:
 if st['name'].endswith(('prediv','min')):targets.append((st['name'],np.array(st['q'])))
for pair in results:
 for k in ['h','h2']:
  if pair[k]['status']=='positive_energy_divergence':targets.append((pair['state']+'-'+k+'-divendpoint',np.array(pair[k]['end_q'])))
for name,q in targets:
 if COUNT+15>CAP:break
 lp,g,e=ev(q)
 if e:fd.append({'state':name,'error':e});continue
 inds=sorted(set([IS,NAMES.index('kappa_b'),int(np.argmax(np.abs(g)))]));out=[]
 for ix in inds:
  for step in [1e-4,1e-5]:
   if COUNT+2>CAP:break
   qp=q.copy();qm=q.copy();qp[ix]+=step;qm[ix]-=step
   a,_,ea=ev(qp);b,_,eb=ev(qm)
   if ea or eb:out.append({'coordinate':NAMES[ix],'step':step,'error_plus':ea,'error_minus':eb});continue
   d=(a-b)/(2*step);out.append({'coordinate':NAMES[ix],'step':step,'ad':float(g[ix]),'fd':d,'signed_error':d-float(g[ix]),'scaled_abs_error':abs(d-g[ix])/max(1,abs(d),abs(g[ix]))})
 fd.append({'state':name,'checks':out})

# Actual-target forward/reverse check, 8 steps, central state chain 1.
st=next(x for x in states if x['name']=='c1-central');q=np.array(st['q']);_,metric,h=CHAINS[1];p=np.array(next(x for x in results if x['state']==st['name'])['z'])/np.sqrt(metric)
fwd=integrate(q,p,metric,h,8);rev=integrate(np.array(fwd['end_q']),-np.array(fwd['end_p']),metric,h,8)
REV={'max_q_abs_error':float(np.max(np.abs(np.array(rev['end_q'])-q))),'max_p_abs_error':float(np.max(np.abs(np.array(rev['end_p'])+p))),'forward_status':fwd['status'],'reverse_status':rev['status']}
assert REV['max_q_abs_error']<1e-8 and REV['max_p_abs_error']<1e-7
res={'actual_gradient_evaluations':COUNT,'cap':CAP,'elapsed_seconds':time.monotonic()-START,'transform_check':TRANS,'toy':TOY,'actual_reversibility':REV,'pairs':results,'finite_differences':fd}
dump(O/'results.json',res);print(json.dumps({'done':True,'actual_gradient_evaluations':COUNT,'elapsed_seconds':res['elapsed_seconds'],'reversibility':REV}),flush=True)

# Final bounded checks at the deepest completed stress endpoints, no replay.
import pathlib,json
P=pathlib.Path('scratch/q012-p11-amended-review-20261019/trajectory-agent/probe.py')
exec(compile(P.read_text().split('# Analytic normal toy')[0],str(P),'exec'))
previous=json.loads((O/'minimum_stress.json').read_text());COUNT=previous['total_actual_gradient_evaluations'];checks=[]
for pair in previous['pairs']:
 endpoint=pair['h2'];q=np.array(endpoint['end_q']);lp,g,e=ev(q);assert e is None
 _,metric,h=CHAINS[pair['chain']];inds=[IS,NAMES.index('kappa_b'),IW+int(np.argmax(np.abs(g[IW:])))];out=[]
 for ix in inds:
  for step in [1e-4,1e-5]:
   qp=q.copy();qm=q.copy();qp[ix]+=step;qm[ix]-=step;a,ga,ea=ev(qp);b,gb,eb=ev(qm)
   if ea or eb:out.append({'coordinate':NAMES[ix],'step':step,'error_plus':ea,'error_minus':eb});continue
   d=(a-b)/(2*step);curvature=-(ga[ix]-gb[ix])/(2*step)
   out.append({'coordinate':NAMES[ix],'step':step,'ad':float(g[ix]),'fd':d,'scaled_abs_error':abs(d-g[ix])/max(1,abs(d),abs(g[ix])),'potential_diagonal_curvature_from_AD_FD':float(curvature),'h_sqrt_metric_curvature':h*math.sqrt(metric[ix]*curvature) if curvature>=0 else None})
 checks.append({'state':pair['state']+'-h2-endpoint','sigma':math.exp(q[IS]),'checks':out})
dump(O/'endpoint_fd.json',{'previous_count':previous['total_actual_gradient_evaluations'],'total_actual_gradient_evaluations':COUNT,'cap':CAP,'checks':checks,'elapsed_extra_seconds':time.monotonic()-START})
print(json.dumps({'total_actual_gradient_evaluations':COUNT,'checks':checks}),flush=True)

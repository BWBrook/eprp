import pathlib, json, hashlib, importlib.util, subprocess, gzip, re
import numpy as np
import pandas as pd

R=pathlib.Path('/home/bwbrook/git/eprp')
O=R/'scratch/q012-p11-amended-review-20261019'
F=pathlib.Path('scratch/q012-pilot/fetch-20261018-v6p2')
A=F/'runs/P11/attempt1'
B=pathlib.Path('scratch/q012-pilot/fetch-20261017-v6p/runs/P11/attempt1')
E=R/'data/q012-pilot/results/P11-amended-20261018-v6p2'
spec=importlib.util.spec_from_file_location('pilot', R/'data/q012-pilot/pilot.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
p=m.P
h=lambda q: hashlib.sha256(pathlib.Path(q).read_bytes()).hexdigest()
out={}
out['chain_hashes']={name:h(A/name)==sha for sha,name in (ln.split() for ln in (E/'chain_files.sha256').read_text().splitlines())}
out['archive_hash_matches']=h(F/'fetch-P11.tar.gz')==(E/'fetch_archive.sha256').read_text().split()[0]
out['receipt_copies_match']=(A/'receipt.txt').read_bytes()==(E/'receipt.txt').read_bytes() and (F/'build/receipt.txt').read_bytes()==(E/'build_receipt.txt').read_bytes()
out['manifest_matches_fetch']=(F/'manifest.sha256').read_bytes()==(m.PAY/'manifest.sha256').read_bytes()
out['manifest_checks']=subprocess.run(['sha256sum','-c','--strict','--quiet','manifest.sha256'],cwd=m.PAY).returncode==0
out['manifest_entries']=len((m.PAY/'manifest.sha256').read_text().splitlines())
out['archived_compressed_logs_match']={str(k):gzip.decompress((E/f'chain{k}.log.gz').read_bytes())==(A/f'chain{k}.log').read_bytes() for k in range(1,5)}
oldpay=m.HERE/'payload_v6p'
out['data_and_starts']={}
for sc in ['R00','P11']:
    old=json.loads((oldpay/'data'/f'{sc}.json').read_text())
    new=json.loads((m.PAY/'data'/f'{sc}.json').read_text())
    delta={key:[old.get(key),new.get(key)] for key in old.keys()|new.keys() if old.get(key)!=new.get(key)}
    out['data_and_starts'][sc]={'field_differences':delta,'starts_identical':[(m.PAY/'inits'/sc/f'chain{k}.json').read_bytes()==(oldpay/'inits'/sc/f'chain{k}.json').read_bytes() for k in range(1,5)]}
out['model_source_identical']=(oldpay/'model_v6.stan').read_bytes()==(m.PAY/'model_v6.stan').read_bytes()
out['permitted_fits']=(m.PAY/'fits.txt').read_text().split()
res=m.diagnose(A,'P11',write=False)
out['diagnostics_exact']=res==json.loads((E/'diagnostics.json').read_text())
out['diagnostics']=res
out['preflight']={}
for f in sorted((F/'build').glob('point_*.csv')):
    actual=pd.read_csv(f,comment='#').to_numpy(float)
    ref=pd.read_csv(m.PAY/'preflight'/('ref_'+f.name),comment='#').to_numpy(float)
    err=np.max(np.abs(actual-ref)/np.maximum(1,np.abs(ref)))
    out['preflight'][f.name]={'max_scaled_error':float(err),'pass':bool(err<=1e-6)}
out['p53_build_rejection']=[ln for ln in (F/'build/reject_control_p53.stdout').read_text().splitlines() if 'Exception:' in ln]
dfs=[pd.read_csv(A/f'chain{k}.csv',comment='#') for k in range(1,5)]
df=pd.concat(dfs,ignore_index=True)
out['shape']={'chains':len(dfs),'draws_each':[len(x) for x in dfs],'columns':len(df.columns),'monitored':len([c for c in df if not c.endswith('__') or c=='lp__'])}
out['independent_bfmi']=[float(np.sum(np.diff(x.energy__.to_numpy())**2)/np.sum((x.energy__-x.energy__.mean())**2)) for x in dfs]
out['prefix_comparison']={}
out['divergent_transitions']=[]
for k,x in enumerate(dfs,1):
    old=pd.read_csv(B/f'chain{k}.csv',comment='#')
    oldtext=(B/f'chain{k}.csv').read_text().splitlines()
    newtext=(A/f'chain{k}.csv').read_text().splitlines()
    datalines=lambda lines:[ln for ln in lines if ln and not ln.startswith('#')]
    meta=lambda lines:[ln for j,ln in enumerate(lines) if 'Step size' in ln or (j>0 and 'Diagonal elements of inverse mass matrix' in lines[j-1])]
    out['prefix_comparison'][str(k)]={'float_values_exact':np.array_equal(old.to_numpy(),x.iloc[:4000].to_numpy()),'csv_header_and_4000_data_lines_exact':datalines(oldtext)==datalines(newtext)[:4001],'adaptation_lines_exact':meta(oldtext)==meta(newtext),'new_draws':len(x)-len(old)}
    for i in x.index[x.divergent__==1]:
        out['divergent_transitions'].append({'chain':k,'retained_row_zero_based':int(i),'total_transition':int(i)+2001,'previous_sigma':float(x.loc[i-1,'sigma']),'saved_sigma':float(x.loc[i,'sigma']),'stepsize':float(x.loc[i,'stepsize__']),'leapfrogs':int(x.loc[i,'n_leapfrog__'])})
out['accounting']=[ln.strip() for ln in (E/'accounting.txt').read_text().splitlines() if any(w in ln for w in ['Job Id:', 'resources_used.', 'Exit_status'])]
out['amendment_elapsed_coreh']=(19*60+10+115*60)*4/3600
out['tranche_elapsed_coreh']=out['amendment_elapsed_coreh']+(28*60+38+62*60+13)*4/3600
out['remaining_original_ceiling_coreh']=53+1/3-out['tranche_elapsed_coreh']
(O/'replay.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['diagnostics','accounting']},indent=2),flush=True)
j=m.joint_checks(A,m.PAY/'data/P11.json')
(O/'joint_checks.json').write_text(json.dumps(j,indent=2)+'\n')
r={'joint_checks_exact':j==json.loads((E/'joint_checks.json').read_text()),**{k:v for k,v in j.items() if k!='states'}}
(O/'joint_replay_summary.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2),flush=True)

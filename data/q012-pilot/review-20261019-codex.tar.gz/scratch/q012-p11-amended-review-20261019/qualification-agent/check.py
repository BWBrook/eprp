import importlib.util
import json
import pathlib
import re

ROOT = pathlib.Path('/home/bwbrook/git/eprp')
OUT = ROOT / 'scratch/q012-p11-amended-review-20261019/qualification-agent'
spec = importlib.util.spec_from_file_location('pilot', ROOT / 'data/q012-pilot/pilot.py')
M = importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)
A = ROOT / 'scratch/q012-pilot/fetch-20261018-v6p2/runs/P11/attempt1'
env = dict(x.split('=', 1) for x in (M.PAY / 'run.env').read_text().splitlines())
W, S = int(env['WARMUP']), int(env['SAMPLING'])
out = dict(actual={}, fixtures={})
for k in range(1, 5):
    f, r = M.parse_log((A / f'chain{k}.log').read_text(), W, S)
    out['actual'][str(k)] = dict(failures=f, rejections=r)
out['actual_qualification_failures'] = M.qualify(A, 'P11', env, M.sha(M.PAY / 'manifest.sha256'), M._receipt(A.parents[2] / 'build/receipt.txt'))
out['qualification_fixtures'] = {}
for name, status, code in [('nonzero_exit', 'failed', '1'), ('timeout', 'timeout', '124'), ('terminated', 'terminated_TERM', '143'), ('false_complete_nonzero', 'complete', '1')]:
    dest = OUT / name / 'attempt1'
    dest.mkdir(parents=True, exist_ok=True)
    for f in A.iterdir():
        if f.name != 'receipt.txt' and f.name != 'chain1.exit' and not (dest / f.name).exists():
            (dest / f.name).symlink_to(f)
    receipt = (A / 'receipt.txt').read_text().replace('status=complete', f'status={status}').replace('chain1_exit=0', f'chain1_exit={code}')
    (dest / 'receipt.txt').write_text(receipt)
    (dest / 'chain1.exit').write_text(code+'\n')
    f = M.qualify(dest, 'P11', env, M.sha(M.PAY / 'manifest.sha256'), M._receipt(A.parents[2] / 'build/receipt.txt'))
    out['qualification_fixtures'][name] = dict(failures=f, fails_closed=bool(f))
base = (A / 'chain1.log').read_text()
known = "Exception: Exception: Q012 input failure: 1-D initial score (in 'model_v6.stan', line 39)"
def envelope(cause=known):
    return '\n'.join([M.LOG_FIXED['rej'], cause, M.LOG_FIXED['rej3'], M.LOG_FIXED['rej4']])
def inject_after_marker(text, k, extra):
    return re.sub(rf'(^Iteration:\s+{k} /[^\n]*\n)', lambda x: x[1]+extra+'\n', text, count=1, flags=re.M)
def drop_marker(text, k):
    return re.sub(rf'^Iteration:\s+{k} /[^\n]*\n', '', text, count=1, flags=re.M)
cases = {
 'baseline': base,
 'warmup': inject_after_marker(base, 252, envelope()),
 'last_warmup': inject_after_marker(base, W, envelope()),
 'first_sampling': inject_after_marker(base, W+1, envelope()),
 'last_sampling': inject_after_marker(base, W+S, envelope()),
 'stepsize_init': base.replace(M.LOG_FIXED['adjust'], M.LOG_FIXED['adjust']+'\n'+envelope(), 1),
 'initial_rejection': base.replace('num_threads = 1 (Default)', 'num_threads = 1 (Default)\n'+ '\n'.join([M.LOG_FIXED['init'], M.LOG_FIXED['init_eval'], known]), 1),
 'unknown_text_sampling': inject_after_marker(base, W+1, 'Unknown error during sampling'),
 'orphan_sampling_exception': inject_after_marker(base, W+1, known),
 'unknown_cause_warmup': inject_after_marker(base, 252, envelope('Exception: unrecognized numerical failure')),
 'unknown_cause_sampling': inject_after_marker(base, W+1, envelope('Exception: unrecognized numerical failure')),
 'truncated_envelope': inject_after_marker(base, 252, '\n'.join([M.LOG_FIXED['rej'], known])),
 'missing_first_sampling_marker': drop_marker(base, W+1),
 'missing_first_marker': drop_marker(base, 1),
 'wrong_boundary_phase': re.sub(rf'(^Iteration:\s+{W+1} /[^\n]*)Sampling', r'\1Warmup', base, count=1, flags=re.M),
 'repeated_marker': inject_after_marker(base, W+1, f'Iteration: {W+1} / {W+S} [20%] (Sampling)'),
 'out_of_order_marker': inject_after_marker(base, W+1, f'Iteration: {W} / {W+S} [20%] (Warmup)'),
 'missing_completion': base[:base.index(' Elapsed Time:')],
 'truncated_sampling': base[:re.search(rf'^Iteration:\s+{W+2} /', base, re.M).start()],
 'unexpected_post_completion': base+'ERROR\n',
 'unknown_singleword_startup': 'ERROR\n'+base,
 'unknown_assignment_startup': 'fatal_error = unexpected numerical failure\n'+base,
 'unknown_cause_mentions_newton': inject_after_marker(base, 252, envelope('Exception: completely unknown failure in newton bookkeeping')),
}
for name, text in cases.items():
    f, r = M.parse_log(text, W, S)
    out['fixtures'][name] = dict(failure_count=len(f), failures=f[:3], rejections=r,
        parser_accepts=not f,
        no_fatal_or_sampling_phase_failures=(not f and not any(x['phase']=='sampling' for x in r)))
out['reference_units'] = {
 'signed_cancellation_detected': M._converged({'value':1e-3,'sigma':2e-3},{'value':-1e-3,'sigma':-2e-3}),
 'nan_rejected': M._converged({'value':float('nan'),'sigma':0.0},{'value':float('nan'),'sigma':0.0}),
 'inf_rejected': M._converged({'value':float('inf'),'sigma':0.0},{'value':float('inf'),'sigma':0.0}),
}
(OUT/'evidence.json').write_text(json.dumps(M._clean(out), indent=2, allow_nan=False)+'\n')
print(json.dumps(M._clean(out), indent=2, allow_nan=False))

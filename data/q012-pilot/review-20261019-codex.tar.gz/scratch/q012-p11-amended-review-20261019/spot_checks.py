import importlib.util, json, pathlib, time
import pandas as pd
R=pathlib.Path('/home/bwbrook/git/eprp')
O=R/'scratch/q012-p11-amended-review-20261019'
s=importlib.util.spec_from_file_location('pilot',R/'data/q012-pilot/pilot.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
d=json.loads((m.PAY/'data/P11.json').read_text())
a=json.loads((m.HERE/'results/P11-amended-20261018-v6p2/joint_checks.json').read_text())
df=pd.concat([pd.read_csv(R/f'scratch/q012-pilot/fetch-20261018-v6p2/runs/P11/attempt1/chain{k}.csv',comment='#') for k in range(1,5)],ignore_index=True)
worst_der=max(a['states'],key=lambda i:max(v for k,v in a['states'][i].items() if k.startswith('d_') and k.endswith('_err')))
# Fixed finite audit: archived worst value/derivative states, and the last new draw.
indices=list(dict.fromkeys([a['worst_state'],worst_der,'31999']))
out={'scope':'Spot checks after full 49-state replay was terminated with exit 143 before returning results; not a completed full replay','selection':indices,'states':{}}
for i in indices:
    t=time.monotonic();q=m.P.draw_to_params(df.iloc[int(i)],d['N'])
    g=dict(sigma=float(q['sigma']),rho=float(q['rho']),kappa_b=float(q['kappa_b']),**m.gate_point(d,q))
    out['states'][i]={'gate':g,'exact_archived_match':g==a['states'][i],'elapsed_seconds':time.monotonic()-t}
    (O/'spot_checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print(i,g['pass'],out['states'][i]['exact_archived_match'],flush=True)

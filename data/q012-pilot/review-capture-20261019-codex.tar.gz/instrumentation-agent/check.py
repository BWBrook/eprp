import copy, gzip, hashlib, importlib.util, json, math, pathlib, re
import numpy as np
ROOT=pathlib.Path('/home/bwbrook/git/eprp')
OUT=ROOT/'scratch/q012-p11-capture-review-20261019/instrumentation-agent'
spec=importlib.util.spec_from_file_location('pilot',ROOT/'data/q012-pilot/pilot.py')
M=importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
PAY=ROOT/'data/q012-pilot/payload_v6d'
A=ROOT/'scratch/q012-pilot/fetch-20261019-v6d/runs/P11/attempt1'
F=A.parents[2]
ARC=ROOT/'data/q012-pilot/results/P11-diagnostic-20261019-v6d'
env=dict(x.split('=',1) for x in (PAY/'run.env').read_text().splitlines())
out={'actual':{},'parser_regressions':{},'trace_fixtures':{},'preflight':{}}
for k in (1,2):
    rows=M.read_trace(A/f'chain{k}.trace.jsonl')
    faults,summary=M.trace_structure(A,env,k)
    lf,rej=M.parse_log((A/f'chain{k}.log').read_text(),2000,6000,
       M.expected_header(env,'P11',k,f'runs/P11/attempt1/chain{k}.csv'),M.payload_grammar('P11'))
    events=[]
    for e in rows[1:-1]:
        m=np.asarray(e['inv_metric']); si=e['initial']; sf=e['failing']
        H=lambda s: s['V']+.5*float(np.sum(m*np.asarray(s['p'])**2))
        errs=[]
        if e['signed_epsilon']!=e['sign']*e['epsilon']: errs.append('signed step')
        if e['sign'] not in [-1,1]: errs.append('sign')
        if e['max_deltaH']!=1000: errs.append('threshold')
        if not (np.isfinite(m).all() and (m>0).all()): errs.append('metric')
        if e['delta_effective']!=e['H_effective']-e['H0']: errs.append('delta')
        for sn in ('initial','previous','failing'):
            s=e[sn]
            if s['V_finite']!=math.isfinite(s['V']) or s['grad_V_current']!=math.isfinite(s['V']): errs.append(sn+' stale flag')
        def diff(a,b):
            if a==b: return 0.0
            return abs(a-b)
        events.append(dict(transition=e['transition'],phase=e['phase'],finite_failing=math.isfinite(sf['V']),
             H0_from_record_diff=diff(H(si),e['H0']),H_raw_from_record_diff=diff(H(sf),e['H_raw']),
             H0_from_record_scaled_diff=diff(H(si),e['H0'])/max(1,abs(e['H0'])),
             H_raw_from_record_scaled_diff=(diff(H(sf),e['H_raw'])/max(1,abs(e['H_raw'])) if math.isfinite(e['H_raw']) else 0),
             grad_current=sf['grad_V_current'],errors=errs))
    out['actual'][str(k)]=dict(trace_structure_failures=faults,summary=summary,parse_failures=lf,rejections=rej,events=events,
       archived_trace_identical=gzip.decompress((ARC/f'chain{k}.trace.jsonl.gz').read_bytes())==(A/f'chain{k}.trace.jsonl').read_bytes(),
       archived_log_identical=gzip.decompress((ARC/f'chain{k}.log.gz').read_bytes())==(A/f'chain{k}.log').read_bytes())
out['qualification_failures']=M.qualify(A,'P11',env,M.sha(PAY/'manifest.sha256'),M._receipt(F/'build/receipt.txt'))
base=(A/'chain1.log').read_text()
hdr=M.expected_header(env,'P11',1,'runs/P11/attempt1/chain1.csv'); gram=M.payload_grammar('P11')
for name,extra in [('ERROR','ERROR'),('assignment','fatal_error = unexpected numerical failure')]:
    out['parser_regressions'][name]=M.parse_log(extra+'\n'+base,2000,6000,hdr,gram)[0][:3]
block='\n'.join([M.LOG_FIXED['rej'],'Exception: completely unknown failure in newton bookkeeping',M.LOG_FIXED['rej3'],M.LOG_FIXED['rej4']])
mut=re.sub(r'(^Iteration:\s+252 /[^\n]*\n)',lambda x:x[1]+block+'\n',base,count=1,flags=re.M)
out['parser_regressions']['unknown_newton']=M.parse_log(mut,2000,6000,hdr,gram)[0][:3]
rows=M.read_trace(A/'chain1.trace.jsonl')
variants={}
r=copy.deepcopy(rows); r.pop(); variants['no_summary']=r
r=copy.deepcopy(rows); r[-1]['write_ok']=False; variants['failed_write']=r
r=copy.deepcopy(rows); r[-2]['phase']='warmup'; variants['wrong_sampling_phase']=r
r=copy.deepcopy(rows); r.pop(-2); variants['missing_sampling_event']=r
r=copy.deepcopy(rows); r[1]['inv_metric'].pop(); variants['wrong_metric_length']=r
r=copy.deepcopy(rows); r[1]['captured']=False; variants['incorrect_full_flag']=r
for name,r in variants.items():
    dest=OUT/'fixtures'/name; dest.mkdir(parents=True,exist_ok=True)
    if not (dest/'chain1.csv').exists(): (dest/'chain1.csv').symlink_to(A/'chain1.csv')
    (dest/'chain1.trace.jsonl').write_text('\n'.join(json.dumps(x) for x in r)+'\n')
    out['trace_fixtures'][name]=M.trace_structure(dest,env,1)[0]
def body(p):
    # Retain data/header plus adaptation comments; strip variable timing/config comments.
    return [x for x in p.read_text().splitlines() if not x.startswith('#') or
       re.search(r'Step size|Diagonal elements|^# [-0-9.e]+(, [-0-9.e+]+)*$',x)]
for st in ('0.2','0.5'):
    ex=F/'build/exercise'; rows=M.read_trace(ex/f's{st}.trace.jsonl'); ev=rows[1:-1]
    out['preflight']['exercise_'+st]=dict(summary=rows[-1], transitions=[e['transition'] for e in ev],
       captured_warmup=[e['transition'] for e in ev if e['phase']=='warmup' and e['captured']],
       captured_sampling=[e['transition'] for e in ev if e['phase']=='sampling' and e['captured']],
       all_phases_correct=all(e['phase']==('warmup' if e['transition']<=4 else 'sampling') for e in ev),
       all_full_flags_correct=all(all(x in e for x in ('initial','previous','failing','inv_metric'))==e['captured'] for e in ev),
       onoff_body_identical=body(ex/f's{st}_on.csv')==body(ex/f's{st}_off.csv'))
on=F/'build/onoff'
out['preflight']['on_off_identical']=body(on/'on.csv')==body(on/'off.csv')
out['preflight']['old_off_identical']=body(on/'old.csv')==body(on/'off.csv')
out['preflight']['on_trace_summary']=M.read_trace(on/'on.trace.jsonl')[-1]
out['source']={'original_hash':M.sha(ROOT/'data/q012-pilot/patch_v6d/base_nuts.orig.hpp'),
    'payload_patch_identical':(PAY/'patch/base_nuts.hpp').read_bytes()==(ROOT/'data/q012-pilot/patch_v6d/base_nuts.hpp').read_bytes()}
(OUT/'evidence.json').write_text(json.dumps(M._clean(out),indent=2,allow_nan=False)+'\n')
print(json.dumps(M._clean(out),indent=2,allow_nan=False))

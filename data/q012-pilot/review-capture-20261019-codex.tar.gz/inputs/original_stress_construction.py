import pathlib,json,csv,math,subprocess,hashlib,importlib.util,numpy as np
R=pathlib.Path.cwd(); O=R/'scratch/q012-p11-review-20261018/solver-agent'; H=R/'data/q012-prototype'
spec=importlib.util.spec_from_file_location('prototype',H/'prototype.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
# Import defines helpers only. Never call p.model/checks/sample or pilot helpers.
def load(path): return json.loads(path.read_text())
def write(path,obj):path.write_text(json.dumps(obj,indent=2,default=float)+'\n')
def csvrows(path):
 with path.open() as f: return [{k:float(v) for k,v in q.items()} for q in csv.DictReader(l for l in f if l.strip() and not l.startswith('#'))]
def run(ver,d,q,key):
 folder=O/key;folder.mkdir(parents=True,exist_ok=True)
 pf=folder/f'{ver}-params.json';df=folder/f'{ver}-data.json';of=folder/f'{ver}.csv';write(pf,q);write(df,d)
 cmd=[str(R/f'scratch/q012-prototype/model_{ver}'),'log_prob',f'constrained_params={pf}','jacobian=1','data',f'file={df}','output',f'file={of}','sig_figs=15']
 assert cmd[1]=='log_prob'
 proc=subprocess.run(cmd,capture_output=True,text=True,timeout=10);(folder/f'{ver}.txt').write_text(proc.stdout+proc.stderr)
 rows=csvrows(of) if proc.returncode==0 else []
 if not rows:return {'accepted':False,'exit':proc.returncode,'error':(proc.stdout+proc.stderr)[-2400:]}
 assert len(rows)==1
 return {'accepted':True,'finite':all(math.isfinite(v) for v in rows[0].values()),'row':rows[0]}
res={'source':{},'preflight':{},'tolerance':{}}
for v in ['v4','v6']:
 exe=R/f'scratch/q012-prototype/model_{v}';res['source'][v]={'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'source_matches_tracked':exe.with_suffix('.stan').read_bytes()==(H/f'model_{v}.stan').read_bytes()}
record=load(R/'data/q012-pilot/tranche_preflight_v6p.json')
for sc in ['P11','P06']:
 d=load(R/f'data/q012-pilot/payload_v6p/data/{sc}.json');starts=[load(R/f'data/q012-pilot/payload/inits/{sc}/chain{k}.json') for k in range(1,5)]
 pts={f'start_chain{k}':q for k,q in enumerate(starts,1)};pts.update(sigma_001=dict(starts[0],sigma=.01),sigma_0001=dict(starts[0],sigma=.001))
 res['preflight'][sc]={}
 for name,q in pts.items():
  old=run('v4',d,q,f'preflight-{sc}-{name}');new=run('v6',d,p.to_nc(q),f'preflight-{sc}-{name}');assert old['accepted'] and new['accepted']
  go,gn=old['row'],new['row'];n=d['N'];a=.2;ge=np.array([go[f'g_eps.{i}'] for i in range(1,n+1)]);gw=np.array([gn[f'g_w.{i}'] for i in range(1,n+1)]);eps=np.array(q['eps'])
  scaled=lambda x,y:float(np.max(np.abs(np.asarray(x)-np.asarray(y))/np.maximum(1,np.abs(y))))
  other=[c for c in go if c.startswith('g_') and not c.startswith('g_eps.') and c!='g_sigma']
  row={'sigma':q['sigma'],'lp_v5':go['lp__'],'lp_v6':gn['lp__'],'log_identity_error':abs(gn['lp__']-go['lp__']+a*n*math.log(q['sigma'])),'grad_w_error':scaled(gw,q['sigma']**(-a)*ge),'grad_logsigma_error':scaled(gn['g_sigma'],go['g_sigma']-a*float(eps@ge)-a*n),'grad_other_error':scaled([gn[c] for c in other],[go[c] for c in other]),'finite':old['finite'] and new['finite']}
  row['max_difference_from_record']=max(abs(row[k]-record[sc]['identity']['rows'][name][k]) for k in row if k!='finite');res['preflight'][sc][name]=row
D=load(R/'data/q012-pilot/payload_v6p/data/P11.json');N=D['N'];base=R/'scratch/q012-pilot/fetch-20261017-v6p/runs/P11/attempt1'
draws=[]
for k in range(1,5):
 for idx,q in enumerate(csvrows(base/f'chain{k}.csv')):q.update(_chain=k,_draw=idx);draws.append(q)
joint=load(R/'data/q012-pilot/results/P11-20261017-v6p/joint_checks.json')
ids=list(map(int,joint['states']));ids.extend(i for i,q in enumerate(draws) if q['divergent__'])
for k in range(1,5):ids.append(min((i for i,q in enumerate(draws) if q['_chain']==k),key=lambda i:draws[i]['sigma']))
ids=list(dict.fromkeys(ids));points={}
scalar=['log_h0_1','tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']
for i in ids:
 r=draws[i];q={k:r[k] for k in scalar};q['z_rw']=[r[f'z_rw.{j}'] for j in range(1,25)];q['w']=[r[f'w.{j}'] for j in range(1,N+1)];points[f'draw{i}']=q
starts=[load(R/f'data/q012-pilot/payload_v6p/inits/P11/chain{k}.json') for k in range(1,5)]
points.update({f'start{k}':q for k,q in enumerate(starts,1)})
for sig in [.01,.001]:points[f'sigma{sig}']=p.to_nc(dict(load(R/'data/q012-pilot/payload/inits/P11/chain1.json'),sigma=sig))
# Finite stress grid chosen before looking at tolerance outcomes. Keep w fixed from start 1.
for sig in [.001,.1,1.,3.]:
 for hshift in [0.,2.,5.,10.]:
  for kb in [-1.5,0.,1.5]:
   q=dict(starts[0],sigma=sig,log_h0_1=starts[0]['log_h0_1']+hshift,kappa_b=kb);points[f'grid-s{sig}-h{hshift}-kb{kb}']=q
write(O/'point_selection.json',{'saved_ids':ids,'divergent_saved_ids':[i for i,q in enumerate(draws) if q['divergent__']],'points':points})
for name,q in points.items():
 outs={}
 for tol in [1e-11,1e-10]:outs[str(tol)]=run('v6',dict(D,solver_f_tol=tol),q,f'tol-{name}-{tol}')
 r={'sigma':q['sigma'],'rho':q['rho'],'kappa_b':q['kappa_b'],'outcomes':outs};a,b=outs.values()
 if a['accepted'] and b['accepted']:
  r['max_absolute_density_gradient_difference']=max(abs(a['row'][k]-b['row'][k]) for k in a['row']);r['density_difference']=abs(a['row']['lp__']-b['row']['lp__'])
 res['tolerance'][name]=r
write(O/'audit.json',res)
summary={'points':len(points),'saved_states':len(ids),'preflight_points':sum(len(v) for v in res['preflight'].values()),'preflight_worst_record_difference':max(q['max_difference_from_record'] for vals in res['preflight'].values() for q in vals.values()),'both_accepted':sum(all(v['accepted'] for v in r['outcomes'].values()) for r in res['tolerance'].values()),'newly_admitted':[n for n,r in res['tolerance'].items() if not r['outcomes']['1e-11']['accepted'] and r['outcomes']['1e-10']['accepted']],'rejected_both':[n for n,r in res['tolerance'].items() if not any(v['accepted'] for v in r['outcomes'].values())],'max_both_accepted_difference':max(r.get('max_absolute_density_gradient_difference',0) for r in res['tolerance'].values())}
write(O/'summary.json',summary);print(json.dumps(summary,indent=2))

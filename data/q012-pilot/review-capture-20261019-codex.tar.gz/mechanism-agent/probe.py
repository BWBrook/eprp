"""Existing-binary LPAD only: two captured P11 leaves, deterministic subdivision, FD and curvature."""
import csv,hashlib,json,math,os,pathlib,subprocess,time
import numpy as np
R=pathlib.Path.cwd();O=R/'scratch/q012-p11-capture-review-20261019/mechanism-agent';B=R/'scratch/q012-pilot/trace_build/model_v6';D=R/'data/q012-pilot/payload_v6d/data/P11.json';RUN=R/'scratch/q012-pilot/fetch-20261019-v6d/runs/P11/attempt1';COUNT=0;CAP=2000;START=time.monotonic()
ENV=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',STAN_NUM_THREADS='1')
names=['log_h0_1']+[f'z_rw.{j}' for j in range(1,25)]+['tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']+[f'w.{j}' for j in range(1,20)]
IS=names.index('sigma');IW=names.index('w.1');targets=['kappa','log_k','sigma'];events=[]
for c in [1,2]:
 evs=[json.loads(l) for l in (RUN/f'chain{c}.trace.jsonl').read_text().splitlines()];evs=[e for e in evs if e.get('phase')=='sampling' and e.get('type')=='divergence'];assert len(evs)==1;events+=evs

def dump(name,x):(O/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def lp(q):
 global COUNT
 if COUNT>=CAP:raise RuntimeError('CAP')
 COUNT+=1;dump('current.json',{'params_r':q.tolist()});cmd=[str(B),'log_prob',f'unconstrained_params={O/"current.json"}','jacobian=1','data',f'file={D}','output',f'file={O/"current.csv"}','sig_figs=18'];assert cmd[1]=='log_prob';p=subprocess.run(cmd,capture_output=True,text=True,env=ENV,timeout=15)
 if p.returncode:return None,None,(p.stdout+p.stderr)[-2000:]
 rr=list(csv.DictReader(x for x in (O/'current.csv').read_text().splitlines() if x and not x.startswith('#')));assert len(rr)==1 and list(rr[0])==['lp__']+['g_'+n for n in names]
 v=float(rr[0]['lp__']);g=np.array([float(rr[0]['g_'+n]) for n in names]);assert math.isfinite(v) and np.isfinite(g).all();return v,g,None

def H(st,m):return st['V']+.5*float(np.dot(st['p'],m*np.array(st['p'])))
def pieces(q):
 d=json.loads(D.read_text());tau=math.exp(q[names.index('tau')]);logs=np.r_[q[0],q[0]+np.cumsum(tau*q[1:25])];sig=math.exp(q[IS]);rho=1/(1+math.exp(-q[names.index('rho')]));eps=q[IW:]/sig**.2;x=np.zeros(19)
 for i in range(19):x[i]=sig*eps[i] if d['parent'][i]==0 else rho*x[d['parent'][i]-1]+sig*math.sqrt(1-rho*rho)*eps[i]
 logz=x-.5*sig*sig;k=math.exp(q[names.index('log_k')]);sv=np.exp(logs[np.array(d['seg_bin'])-1]+q[names.index('beta')]*np.array(d['seg_E'])+q[names.index('gamma')]*np.array(d['seg_miss']))*(np.array(d['seg_a1'])**k-np.array(d['seg_a0'])**k);cum=np.zeros(19)
 for i in range(19):cum[i]=sum(sv[np.array(d['seg_lin'])==i+1])
 dpost=np.array(d['v'])-np.array(d['r']);kp=q[names.index('kappa')];kb=q[names.index('kappa_b')]
 return {'sigma':sig,'kappa':kp,'log_k':float(q[names.index('log_k')]),'k':k,'logz_min':float(min(logz)),'logz_max':float(max(logz)),'post_extinction_cumulative_hazard':float(np.dot(np.exp(logz),cum)),'post_poisson_intensity':float(math.exp(q[names.index('log_lambda0')])*np.dot(np.exp(kp*logz),dpost)),'post_birth_cumulative_hazard':float(math.exp(q[names.index('log_b0')])*np.dot(np.exp(kb*logz),dpost))}

results=[]
for e in events:
 m=np.array(e['inv_metric']);res={k:e[k] for k in ['chain','transition','H0','H_raw','signed_epsilon','n_leapfrog']};res['states']={};res['subdivisions']=[]
 for typ in ['initial','previous','failing']:
  st=e[typ];q=np.array(st['q']);v,g,err=lp(q);assert err is None;hv=H(st,m);res['states'][typ]={'H':hv,'H_minus_H0':hv-e['H0'],'V':st['V'],'V_recheck_abs_error':abs(-v-st['V']),'g_recheck_max_abs_error':float(max(abs(-g-np.array(st['grad_V'])))),'pieces':pieces(q)}
  if typ!='initial':
   fd=[]
   for j,name in enumerate(names):
    for hrel in [1e-4,1e-5]:
     h=hrel*max(1,abs(q[j]));a=q.copy();b=q.copy();a[j]+=h;b[j]-=h;va,_,ea=lp(a);vb,_,eb=lp(b)
     if ea or eb:fd.append({'coordinate':name,'hrel':hrel,'error':ea or eb});continue
     ff=(va-vb)/(2*h);fd.append({'coordinate':name,'hrel':hrel,'step':h,'AD':float(g[j]),'FD':ff,'scaled_error':abs(g[j]-ff)/max(1,abs(g[j]),abs(ff))})
   res['states'][typ]['full_AD_FD']=fd
   blocks=[]
   for hrel in [1e-4,1e-5]:
    ix=[names.index(n) for n in targets];cols=[]
    for j in ix:
     h=hrel*max(1,abs(q[j]));a=q.copy();b=q.copy();a[j]+=h;b[j]-=h;_,ga,ea=lp(a);_,gb,eb=lp(b);assert ea is None and eb is None;cols.append(-(ga[ix]-gb[ix])/(2*h))
    mat=np.array(cols).T;weighted=np.sqrt(m[ix,None])*mat*np.sqrt(m[None,ix]);sym=.5*(weighted+weighted.T);eig,vec=np.linalg.eigh(sym)
    blocks.append({'hrel':hrel,'coordinates':['kappa','log_k','log_sigma'],'potential_Hessian':mat.tolist(),'max_Hessian_asymmetry':float(np.max(np.abs(mat-mat.T))),'weighted_eigenvalues':eig.tolist(),'h_sqrt_largest_weighted_eigenvalue':abs(e['signed_epsilon'])*math.sqrt(max(0,eig[-1])),'largest_eigenvector':vec[:,-1].tolist()})
   res['states'][typ]['curvature_blocks']=blocks
 baseline=H(e['previous'],m)-e['H0'];hp=H(e['previous'],m)
 for n in [1,2,4,8,16,32]:
  q=np.array(e['previous']['q']);p=np.array(e['previous']['p']);V=e['previous']['V'];g=np.array(e['previous']['grad_V']);dt=e['signed_epsilon']/n;hist=[];err=None
  for step in range(1,n+1):
   p-=.5*dt*g;q+=dt*m*p;v,gl,err=lp(q)
   if err:hist.append({'step':step,'error':err,'q':q.tolist()});break
   V=-v;g=-gl;p-=.5*dt*g;hh=V+.5*float(np.dot(p,m*p));hist.append({'step':step,'H_minus_H0':hh-e['H0'],'H_minus_Hprevious':hh-hp,'sigma':math.exp(q[IS])})
  z={'n':n,'signed_dt':dt,'baseline_Hprevious_minus_H0':baseline,'status':'rejected' if err else 'completed','history':hist,'final_q':q.tolist(),'final_p':p.tolist(),'final_V':V,'final_g':g.tolist() if g is not None else None}
  if err is None:
   z.update(H=hh,H_minus_H0=hh-e['H0'],H_minus_Hprevious=hh-hp)
   if n==1:z['reproduction']={'q_abs_error':float(max(abs(q-np.array(e['failing']['q'])))),'p_abs_error':float(max(abs(p-np.array(e['failing']['p'])))),'H_abs_error':abs(hh-e['H_raw'])}
  res['subdivisions'].append(z)
 dp=np.array(e['failing']['p'])-np.array(e['previous']['p']);dT=.5*m*(np.array(e['failing']['p'])**2-np.array(e['previous']['p'])**2);res['last_step_energy_split']={'dV':e['failing']['V']-e['previous']['V'],'dT':float(sum(dT)),'largest_dT_coordinates':[(names[j],float(dT[j]),float(dp[j])) for j in np.argsort(-np.abs(dT))[:10]]}
 results.append(res);dump('checkpoint.json',{'calls':COUNT,'events':results});print(json.dumps({'chain':e['chain'],'calls':COUNT,'baseline':baseline,'subdivisions':[{k:x[k] for k in ['n','H_minus_H0','H_minus_Hprevious']} for x in res['subdivisions']]}),flush=True)
dump('results.json',{'actual_LPAD_calls':COUNT,'cap':CAP,'elapsed_seconds':time.monotonic()-START,'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'data_sha256':hashlib.sha256(D.read_bytes()).hexdigest(),'events':results});print(json.dumps({'done':True,'calls':COUNT,'elapsed_seconds':time.monotonic()-START}),flush=True)

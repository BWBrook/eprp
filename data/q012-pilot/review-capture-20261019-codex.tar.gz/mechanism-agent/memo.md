# P11 captured sampling events: independent mechanism review

**The last leapfrog is badly under-resolved at both recorded events; finer steps remove its local energy error. A newly checked preceding state also fails the fixed-Q64 normaliser value gate. Q80 is the lowest tested order clearing the unchanged gates at all four captured previous/failing states.**

Existing compiled instrumented v6 model, exact P11 v6d payload, Jacobian=true, 18-digit LPAD output. No compile, fit, remote call, installation or tracked edit. 1,574 attempted LPAD evaluations of a 2,000 cap: 1,573 valid-state evaluations and one rejected malformed JSON batch point, corrected with source-verified RDump layout. All intended captured/subdivision/FD points remain finite. Scripts and raw/checkpoint JSON preserve that interface failure. Parent owns archive/provenance and prefix qualification.

## Energy attribution and subdivision

At all six initial/previous/failing captures, actual Stan reproduces V and all 54 stored potential-gradient coordinates exactly. One full signed leapfrog reproduces both failed q/p vectors and H exactly. Gradient naming follows the model parameter order; tau/sigma/rho names denote unconstrained log/log/logit coordinates. K=.5 sum(inv_metric*p^2), and stored trace g=grad(V)=-grad(lp).

| Chain / transition | H0 | Hprevious | Baseline Hprevious−H0 | Last-step ΔV | Last-step ΔK |
|---|---:|---:|---:|---:|---:|
| 1 / 4426 | 151.538790526 | 265.360398522 | 113.821607995 | 7757.02 | 1.07717e+07 |
| 2 / 6652 | 148.742196277 | 224.533681261 | 75.791484984 | 527.013 | 1308.35 |

Holding exactly the captured previous q/p and metric, integrate the same original signed-step time using n equal substeps. These are local deterministic tests, not alternative NUTS fits.

| n | C1 Hfinal−H0 | C1 Hfinal−Hprevious | C2 Hfinal−H0 | C2 Hfinal−Hprevious |
|---:|---:|---:|---:|---:|
| 1 | 10779554.4 | 10779440.6 | 1911.15441 | 1835.36292 |
| 2 | 145.50307 | 31.6814619 | 116.483063 | 40.6915781 |
| 4 | 115.879169 | 2.05756143 | 82.1950684 | 6.40358337 |
| 8 | 114.176722 | 0.355114388 | 77.0966083 | 1.30512329 |
| 16 | 113.901571 | 0.0799631618 | 76.0996557 | 0.308170763 |
| 32 | 113.841066 | 0.0194584125 | 75.8674339 | 0.0759489028 |

The n=32 residual local errors are .01946 and .07595. H−H0 converges to the already accumulated baselines 113.82 and 75.79. Thus the 146/116 after two halves are **not an irreducible ~100 local error**. Refinement is consistent with ordinary leapfrog convergence. It does not remove energy error accumulated before the captured preceding leaf, reconstruct unrecorded earlier leaves, or predict a whole adapted chain. Stan tests signed positive H−H0>1000.

## Forces and coupled geometry

All 54 unconstrained AD components were checked against actual-target central finite differences at both previous and failing states, at relative steps 1e-4 and 1e-5. No finite-difference point rejects. At the smaller step the worst scaled discrepancies are:

- Chain 1 previous: 5.78e-09 (z_rw.9).
- Chain 1 failing: 1.32e-07 (z_rw.4).
- Chain 2 previous: 6.69e-09 (z_rw.21).
- Chain 2 failing: 9.45e-09 (z_rw.23).

The larger step has expected truncation error up to 1.67e-6 scaled in the huge chain-1 log-sigma force; the smaller step reduces that dominant-force error. These comparisons verify derivatives of the implemented approximate density locally; they do not establish the scientific model or exact normaliser globally.

**Chain 1:** previous sigma=1.912, kappa=−.2450, log_k=1.0709; failed sigma=6.205, kappa=−.3363, log_k=1.0223. The latent logz=x−sigma²/2 range moves from [−5.04,.710] to [−27.67,−13.74]. With negative kappa, the model Poisson intensity lambda0*sum(dpost*exp(kappa*logz)) rises from 4.4167 to 7,565.50. This explains a concrete kappa–log-sigma force coupling: failed grad(V) components are about −194,241 in kappa and +111,758 in log-sigma. Their kinetic increments are 6.210e6 and 4.557e6, dominating the final-step ΔK. The cohort normaliser has no kappa dependence.

**Chain 2:** previous sigma=3.571, kappa=−.3183, log_k=1.25435 (k=3.506); failed sigma=1.588, kappa=.2571, log_k=1.27393 (k=3.575). Post-extinction cumulative hazard sum(exp(logz)*cum) rises from 3.33784 to 622.292, while Poisson intensity falls from 39.8857 to .8001. The failed log-k and log-sigma potential gradients are about +5,951 and −2,050. The largest final-step kinetic increments include log-sigma 685.5 and log-k 286.4. The failed endpoint itself is not in the far upper sigma tail; the problematic step follows an upper excursion at its preceding leaf. Contributions here are selected exact likelihood components, not a decomposition of all V.

Two-step-size finite differences of AD give the metric-weighted 3x3 potential-Hessian block in (kappa,log_k,log_sigma). At the preceding leaves, |h|sqrt(largest block eigenvalue) is 2.47 / 3.75; at failed leaves 111 / 4.27. For a frozen positive quadratic mode the leapfrog stability threshold is 2. The measured blocks therefore identify stiff coupled directions; these nonlinear, sometimes indefinite blocks are neither a full Hessian nor a global stability proof. They strengthen the resolution explanation beyond a sigma-only story.

## Newly observed Q64 gate failure and fixed-order checks

Claude's normaliser checks at finite failed endpoints cover value and sigma/rho/kappa_b derivatives, not their preceding leaves or log_k/log_h0 derivatives. We checked all four previous/failing endpoints against independent fixed-innovation Simpson integration with 1,600/3,200 intervals on [−12,12], comparing signed reference changes directly. We added all five axes sigma,rho,kappa_b,log_k,log_h0_1 at each fixed Q=64,80,96,128. Formal derivative tolerances use natural sigma/rho; log_k/log_h0 are already unconstrained real parameters.

| State | Q | signed log error | max abs derivative error across five axes | Existing 1e-4 / 1e-3 gates |
|---|---:|---:|---:|---|
| C1 previous | 64 | -5.41932e-09 | 3.44036e-08 | pass |
| C1 previous | 80 | -1.05689e-10 | 4.55191e-09 | pass |
| C1 previous | 96 | 4.79679e-11 | 9.54792e-10 | pass |
| C1 previous | 128 | -1.07203e-12 | 3.10862e-11 | pass |
| C1 failing | 64 | 9.02133e-06 | 0.000295107 | pass |
| C1 failing | 80 | -2.19131e-06 | 8.51706e-05 | pass |
| C1 failing | 96 | 1.3156e-06 | 0.000117095 | pass |
| C1 failing | 128 | -4.33079e-06 | 0.000158024 | pass |
| C2 previous | 64 | 0.000136254 | 0.000268222 | FAIL |
| C2 previous | 80 | -4.35035e-05 | 0.000178782 | pass |
| C2 previous | 96 | 1.54692e-05 | 7.07435e-05 | pass |
| C2 previous | 128 | 2.05015e-06 | 9.81363e-06 | pass |
| C2 failing | 64 | 1.49679e-10 | 2.06946e-09 | pass |
| C2 failing | 80 | 7.1303e-12 | 9.76996e-11 | pass |
| C2 failing | 96 | 3.37508e-13 | 8.88178e-12 | pass |
| C2 failing | 128 | -7.10543e-15 | 8.88178e-12 | pass |

Reference grid changes in value are at rounding scale and five-axis derivative changes are <=1.8e-11. For domain truncation, survival factors lie in [0,1] for A,B>=0, so each 1-D/2-D integrand is bounded by its standard-normal density. Outside [−12,12], a 1-D tail is <=2Phi(−12); outside the 2-D box the union bound is <=4Phi(−12). For C1=4, C2=1, the total probability-product error is at most (2*C1+4*C2)*Phi(−12)=2.13e-32. Relative to the observed reference probability products, the corresponding log-domain error scale is at most 1.46e-27. This bounds value truncation, not every parameter derivative tail analytically; derivative reference-grid stability is directly checked.

Actual Stan Q80−Q64 density changes at all four endpoints match minus the independent Python normaliser changes to <=2.5e-13. At the offending c2 preceding state, Q64−Q192 actual force differences peak at 2.67e-4 in log-sigma and 2.03e-4 in log-k: small relative to the captured forces. This supports local integration error as the dominant mechanism without pretending numerical approximation is exact.

**Nonmonotonicity is explicit:** c1-failed value errors at Q80/96/128 are −2.19e-6, +1.32e-6 and −4.33e-6: Q128 is worse in absolute error than 80 or 96 there. Every tested order is retained. Q80 is the lowest tested passing order in this finite set, not a certified minimum order over parameter space or a monotonic-convergence theorem.

## Assessment and next prospective test

The blanket claims “gradient/normaliser/lower-tail ruled out; target not wrong” are too broad. The captured last leaves are finite, locally differentiable, under-resolved upper-excursion/coupled-force events; their huge local energy failures reproduce with the recorded target. A Q64 numerical gate breach nevertheless exists at c2 previous. Earlier trajectory regions are not captured, and neither full scientific target validity nor global quadrature accuracy follows. The strongest remaining numerical rival is approximation error in other intermediate states/axes; the available snapshots cannot exclude it globally. It is implausible that the measured ~1e-4 value/~1e-4 force discrepancies alone generate the observed single-leaf energy jumps, but that scale comparison is an inference, not a global exclusion.

Parent's proposed Q80 + adapt_delta=.999 trial is defensible **conditional on wider Q80 preflight passing unchanged gates**: same mathematical likelihood/priors and a=.2, improved fixed quadrature approximation, fixed seed/IDs/starts, diag_e/depth12, solver guards, passive traces, and one prospectively fixed four-chain 2,000+6,000 attempt. Q80 changes the implemented approximation, so do not claim numerical target or path identity with Q64. The joint amendment cannot attribute success separately to Q80 versus .999; it is prospective technical qualification, not a causal comparison. Any preflight failure stops before fitting; any further fit failure stops blind retuning. All six thousand draws must pass every original screen; all other panel cases remain held.

The proposed wider set (both old 49-state banks, original starts, p75/p53 guards, four known captured endpoints) is appropriate for finite qualification; compare Q80 directly to a converged independent reference rather than treating Q64 agreement or a higher order as truth. Add the two **captured transition-initial** states cheaply if not already present, making both known event triads explicit and matching the planned initial/previous/failing postfit requirement. There is no need to certify every warmup explosion or claim coverage of all support. Postfit include every captured sampling event's initial/previous/failing states; unresolved reference accuracy remains unresolved.

Balanced reverse/forward actual-Stan batches of 32 gradients, with one CPU thread, give child-CPU costs Q64/80/96/128 about 4.97/7.97/11.70/19.70 ms per gradient (ratios 1/1.60/2.35/3.96). The first sequential timing pass gave larger/noisier ratios 1/1.90/4.42/6.89; both are preserved. These are local batch proxies including amortised process startup, not cluster MCMC forecasts. .999 may alter the adapted metric, step size, tree lengths and warmup; it is not a deterministic h/2 change.

I favour prospectively fixed 6,000 retained draws over 8,000 under the six-hour cap: retained work is 25% smaller and total transition count 20% smaller. The old unqualified bank gives conditional eta endpoint-MCSE planning estimate .00756*sqrt(8000/6000)=.00873. This assumes comparable efficiency and cannot guarantee precision or runtime. The observed node/path variation is material; six thousand may still time out. Preserve the 6-hour runner/6:10 PBS, four CPUs/8GiB and <=1-hour four-CPU build/preflight ceiling (28.6667 core-hours within 32.6156 remaining), with no extension, passing-prefix rescue or automatic retry.

Evidence files: `results.json` (captures/FD/curvature/subdivision), `orders.json` (all fixed orders and signed references), `order_identity.json`, `critical_Q.json`, both benchmark JSON files, raw scripts/logs and `summary.json`. Complete within this bounded local scope; parent Codex integrates, Claude owns conditional preparation/execution.

2026-10-19 15:14:04 AEDT

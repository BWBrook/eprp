"""Two c2 states, missing log-k / log-h0 derivative axes; chunked Simpson reference."""
import importlib.util,json,math,pathlib,time
import numpy as np
R=pathlib.Path.cwd();O=R/'scratch/q012-p11-capture-review-20261019/mechanism-agent';START=time.monotonic()
spec=importlib.util.spec_from_file_location('prototype_readonly',R/'data/q012-prototype/prototype.py');P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
d=json.loads((R/'data/q012-pilot/payload_v6d/data/P11.json').read_text());f=R/'scratch/q012-pilot/fetch-20261019-v6d/runs/P11/attempt1/chain2.trace.jsonl';ev=next(x for x in [json.loads(l) for l in f.read_text().splitlines()] if x.get('phase')=='sampling' and x.get('type')=='divergence')
names=['log_h0_1']+[f'z_rw.{j}' for j in range(1,25)]+['tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']+[f'w.{j}' for j in range(1,20)]
def params(q):
 v=dict(zip(names,q));return dict(log_h0_1=v['log_h0_1'],z_rw=q[1:25],tau=math.exp(v['tau']),log_k=v['log_k'],gamma=v['gamma'],log_b0=v['log_b0'],kappa_b=v['kappa_b'],sigma=math.exp(v['sigma']),rho=1/(1+math.exp(-v['rho'])))
def lse(z):m=float(np.max(z));return m+math.log(float(np.sum(np.exp(z-m))))
def ref(p,n):
 e=np.linspace(-12.,12.,n+1);w=np.ones(n+1);w[1:-1:2]=4;w[2:-1:2]=2;w*=24/(3*n);lw=np.log(w);s,pr=P.cohort_terms(d,p,P.cohort_A(d,p));sig=p['sigma'];rho=p['rho'];kb=p['kappa_b'];sh=.5*sig*sig
 def ls(x,a,b):return -a*np.exp(x-sh)-b*np.exp(kb*(x-sh))
 ans=0.
 for a,b in s:ans+=lse(lw+ls(sig*e,a,b)-.5*e*e-.5*math.log(2*math.pi))
 for ap,bp,ad,bd in pr:
  arr=[]
  for start in range(0,n+1,64):
   e1=e[start:start+64,None];e2=e[None,:];xp=sig*e1;xd=rho*xp+sig*math.sqrt(1-rho*rho)*e2;z=lw[start:start+64,None]+lw[None,:]+ls(xp,ap,bp)+ls(xd,ad,bd)-.5*(e1*e1+e2*e2)-math.log(2*math.pi);arr.append(lse(z))
  ans+=lse(np.array(arr))
 return ans
out=[]
for state in ['previous','failing']:
 q=np.array(ev[state]['q']);points={'center':q};hs={}
 for name in ['log_k','log_h0_1']:
  j=names.index(name);h=1e-4*max(1,abs(q[j]));hs[name]=h
  for sign,suffix in [(1,'plus'),(-1,'minus')]:v=q.copy();v[j]+=sign*h;points[name+'_'+suffix]=v
 values={}
 for label,u in points.items():
  p=params(u);agh=P.log_norm_agh(d,p,P.cohort_A(d,p));r16=ref(p,1600);r32=ref(p,3200);values[label]={'Q64':agh,'reference1600':r16,'reference3200':r32,'signed_reference_value_change':r32-r16,'signed_Q64_minus_ref3200':agh-r32}
 deriv={}
 for name,h in hs.items():
  dv={k:(values[name+'_plus'][k]-values[name+'_minus'][k])/(2*h) for k in ['Q64','reference1600','reference3200']};deriv[name]={'step':h,**dv,'signed_reference_derivative_change':dv['reference3200']-dv['reference1600'],'signed_Q64_minus_ref3200':dv['Q64']-dv['reference3200']}
 out.append({'chain':2,'state':state,'sigma':params(q)['sigma'],'values':values,'derivatives':deriv});print(json.dumps(out[-1]),flush=True)
(O/'normaliser_axes.json').write_text(json.dumps({'states':out,'method':'fixed innovations Simpson [-12,12],1600/3200 intervals,chunk64, signed references directly compared; central FD two missing axes','LPAD_calls':0,'elapsed_seconds':time.monotonic()-START},indent=2)+'\n')

# All four sampling previous/failing states; fixed-order comparison, no fitting.
import pathlib
S=pathlib.Path('scratch/q012-p11-capture-review-20261019/mechanism-agent/normaliser_axes.py')
exec(compile(S.read_text().split('out=[]')[0],str(S),'exec'))
import subprocess,os,csv
START=time.monotonic();events=[]
for c in [1,2]:
 events+= [x for x in [json.loads(l)for l in (R/f'scratch/q012-pilot/fetch-20261019-v6d/runs/P11/attempt1/chain{c}.trace.jsonl').read_text().splitlines()]if x.get('phase')=='sampling'and x.get('type')=='divergence']
orders=[64,80,96,128];res=json.loads((O/'orders_checkpoint.json').read_text()) if (O/'orders_checkpoint.json').exists() else []
for event in events:
 for kind in ['previous','failing']:
  if any(x['chain']==event['chain'] and x['state']==kind for x in res):continue
  q=np.array(event[kind]['q']);p=params(q);hs={n:(1e-4*max(1,abs(p[n])) if n in ['log_k','log_h0_1']else 1e-4)for n in ['sigma','rho','kappa_b','log_k','log_h0_1']};ps={'center':p}
  for n,h in hs.items():
   for sign,tag in [(1,'plus'),(-1,'minus')]:ps[n+'_'+tag]=dict(p,**{n:p[n]+sign*h})
  vals={}
  for label,pp in ps.items():
   r16,r32=ref(pp,1600),ref(pp,3200);levels={}
   for Q in orders:
    tt,ww=np.polynomial.hermite.hermgauss(Q);dd=dict(d,Q=Q,gh_t=tt.tolist(),gh_w=ww.tolist());levels[str(Q)]=P.log_norm_agh(dd,pp,P.cohort_A(dd,pp))
   vals[label]={'ref1600':r16,'ref3200':r32,'Q':levels,'signed_reference_change':r32-r16}
  details={}
  for Q in orders:
   dr={}
   for n,h in hs.items():
    v=vals[n+'_plus'];w=vals[n+'_minus'];g=(v['Q'][str(Q)]-w['Q'][str(Q)])/(2*h);g16=(v['ref1600']-w['ref1600'])/(2*h);g32=(v['ref3200']-w['ref3200'])/(2*h);dr[n]={'step':h,'Q_derivative':g,'ref1600':g16,'ref3200':g32,'signed_reference_derivative_change':g32-g16,'signed_error':g-g32}
   valerr=vals['center']['Q'][str(Q)]-vals['center']['ref3200'];details[str(Q)]={'signed_value_error':valerr,'derivatives':dr,'passes_value_1e4_derivative_1e3':bool(abs(valerr)<=1e-4 and all(abs(x['signed_error'])<=1e-3 for x in dr.values()))}
  z={'chain':event['chain'],'state':kind,'sigma':p['sigma'],'reference_value_change':vals['center']['signed_reference_change'],'values':vals,'fixed_orders':details};res.append(z);(O/'orders_checkpoint.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({'chain':event['chain'],'state':kind,'orders':{k:{'value_error':v['signed_value_error'],'max_derivative_error':max(abs(x['signed_error'])for x in v['derivatives'].values()),'passes':v['passes_value_1e4_derivative_1e3']}for k,v in details.items()}}),flush=True)
(O/'orders.json').write_text(json.dumps({'orders':orders,'states':res,'elapsed_seconds':time.monotonic()-START,'LPAD_calls':0,'scope':'fixed orders chosen prospectively after Q64 breach; all orders retained; five derivative axes at four sampling endpoints, direct signed1600/3200 convergence'},indent=2)+'\n')
# Whole-process batched actual-Stan LPAD timing. 1+32+32=65 calls/order.
bench=[];exe=R/'scratch/q012-pilot/trace_build/model_v6';qs=[e[k]['q']for e in events for k in ['previous','failing']];env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',STAN_NUM_THREADS='1')
for Q in orders:
 tt,ww=np.polynomial.hermite.hermgauss(Q);dd=dict(d,Q=Q,gh_t=tt.tolist(),gh_w=ww.tolist());df=O/f'bench-Q{Q}-data.json';df.write_text(json.dumps(dd));runs=[]
 for rep,n in enumerate([1,32,32]):
  uq=O/'bench-u.R';flat=[x for j in range(n) for x in qs[j%4]];uq.write_text('params_r <- structure(c('+','.join(format(x,'.17g') for x in flat)+'), .Dim=c('+str(n)+',54))');out=O/'bench-out.csv';t0=time.monotonic();proc=subprocess.run([str(exe),'log_prob',f'unconstrained_params={uq}','jacobian=1','data',f'file={df}','output',f'file={out}','sig_figs=18'],capture_output=True,text=True,env=env,timeout=30);elapsed=time.monotonic()-t0;assert proc.returncode==0,proc.stdout+proc.stderr;rows=list(csv.DictReader(x for x in out.read_text().splitlines()if x and not x.startswith('#')));assert len(rows)==n
  if Q==64:
   assert max(abs(float(row['lp__'])+events[(j%4)//2][['previous','failing'][j%2]]['V'])for j,row in enumerate(rows))<1e-10
  runs.append({'n':n,'elapsed_seconds':elapsed,'seconds_per_LPAD':elapsed/n})
 bench.append({'Q':Q,'runs':runs,'median_batch_seconds_per_LPAD':float(np.median([r['seconds_per_LPAD']for r in runs if r['n']==32]))})
baseline=bench[0]['median_batch_seconds_per_LPAD']
for b in bench:b['ratio_vs_Q64']=b['median_batch_seconds_per_LPAD']/baseline
(O/'benchmark.json').write_text(json.dumps({'benchmark':'wholeprocess log_prob batches at4 captured states, not MCMC/runtimeforecast','additional_LPAD_calls':260,'total_successful_LPAD_calls':1309,'total_attempted_LPAD_evaluations':1310,'batch_JSON_rejection_note':'One successful singleton and one invalidly reshaped JSON batch rejection preceded this RDump benchmark; raw source vals_r reshape verified and Q64 outputs verified' ,'orders':bench},indent=2)+'\n');print(json.dumps({'bench':bench}),flush=True)

import csv,json,os,pathlib,subprocess
O=pathlib.Path('scratch/q012-p11-capture-review-20261019/mechanism-agent').resolve();R=pathlib.Path.cwd();levels=json.loads((O/'orders.json').read_text())['states'];qs=[]
for c in [1,2]:
 e=next(x for x in [json.loads(l)for l in (R/f'scratch/q012-pilot/fetch-20261019-v6d/runs/P11/attempt1/chain{c}.trace.jsonl').read_text().splitlines()]if x.get('type')=='divergence'and x.get('phase')=='sampling');qs.extend([e['previous']['q'],e['failing']['q']])
u=O/'identity-u.R';u.write_text('params_r <- structure(c('+','.join(format(x,'.17g')for q in qs for x in q)+'), .Dim=c(4,54))');rows={}
for Q in [64,80]:
 out=O/f'identity-Q{Q}.csv';p=subprocess.run([str(R/'scratch/q012-pilot/trace_build/model_v6'),'log_prob',f'unconstrained_params={u}','jacobian=1','data',f'file={O/f"bench-Q{Q}-data.json"}','output',f'file={out}','sig_figs=18'],capture_output=True,text=True,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',STAN_NUM_THREADS='1'),timeout=30);assert p.returncode==0,p.stdout+p.stderr;rows[Q]=list(csv.DictReader(x for x in out.read_text().splitlines()if x and not x.startswith('#')));assert len(rows[Q])==4
checks=[]
for i,st in enumerate(levels):
 obs=float(rows[80][i]['lp__'])-float(rows[64][i]['lp__']);pred=st['values']['center']['Q']['64']-st['values']['center']['Q']['80'];checks.append({'chain':st['chain'],'state':st['state'],'Stan_lp_Q80_minus_Q64':obs,'normaliser_prediction':pred,'abs_identity_error':abs(obs-pred)})
assert max(c['abs_identity_error']for c in checks)<1e-9
(O/'order_identity.json').write_text(json.dumps({'extra_valid_LPAD_evaluations':8,'total_attempted_LPAD_evaluations':1574,'total_valid_LPAD_evaluations':1573,'checks':checks},indent=2)+'\n');print(json.dumps(checks,indent=2))

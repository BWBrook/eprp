import csv,json,os,pathlib,resource,subprocess,time
O=pathlib.Path('scratch/q012-p11-capture-review-20261019/mechanism-agent').resolve();B=pathlib.Path('scratch/q012-pilot/trace_build/model_v6').resolve();env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',STAN_NUM_THREADS='1');rows=[]
for cycle,orders in enumerate([[128,96,80,64],[64,80,96,128]]):
 for Q in orders:
  out=O/'bench-interleaved.csv';cmd=[str(B),'log_prob',f'unconstrained_params={O/"bench-u.R"}','jacobian=1','data',f'file={O/f"bench-Q{Q}-data.json"}','output',f'file={out}','sig_figs=18'];r0=resource.getrusage(resource.RUSAGE_CHILDREN);t0=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=30);wall=time.monotonic()-t0;r1=resource.getrusage(resource.RUSAGE_CHILDREN);assert p.returncode==0,p.stdout+p.stderr;vals=list(csv.DictReader(x for x in out.read_text().splitlines()if x and not x.startswith('#')));assert len(vals)==32;rows.append({'cycle':cycle,'Q':Q,'n':32,'wall_seconds_per_LPAD':wall/32,'CPU_seconds_per_LPAD':(r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime)/32})
summ=[]
for Q in [64,80,96,128]:
 x=[r for r in rows if r['Q']==Q];summ.append({'Q':Q,'mean_wall_seconds_per_LPAD':sum(r['wall_seconds_per_LPAD']for r in x)/len(x),'mean_CPU_seconds_per_LPAD':sum(r['CPU_seconds_per_LPAD']for r in x)/len(x)})
for r in summ:r['CPU_ratio_vs_Q64']=r['mean_CPU_seconds_per_LPAD']/summ[0]['mean_CPU_seconds_per_LPAD'];r['wall_ratio_vs_Q64']=r['mean_wall_seconds_per_LPAD']/summ[0]['mean_wall_seconds_per_LPAD']
(O/'benchmark_interleaved.json').write_text(json.dumps({'additional_valid_LPAD_evaluations':256,'total_successful_LPAD_evaluations':1565,'total_attempted_LPAD_evaluations_including_one_invalid_JSON_batch_point':1566,'cap':2000,'runs':rows,'summary':summ},indent=2)+'\n');print(json.dumps(summ,indent=2))

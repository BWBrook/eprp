import pathlib, json, hashlib, importlib.util, subprocess, gzip, re
import numpy as np
import pandas as pd

R=pathlib.Path('/home/bwbrook/git/eprp')
O=R/'scratch/q012-p11-capture-review-20261019'
F=pathlib.Path('scratch/q012-pilot/fetch-20261019-v6d')
A=F/'runs/P11/attempt1'
B=pathlib.Path('scratch/q012-pilot/fetch-20261018-v6p2/runs/P11/attempt1')
E=R/'data/q012-pilot/results/P11-diagnostic-20261019-v6d'
spec=importlib.util.spec_from_file_location('pilot',R/'data/q012-pilot/pilot.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
h=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
out={}
out['chain_hashes']={name:h(A/name)==sha for sha,name in (line.split() for line in (E/'chain_files.sha256').read_text().splitlines())}
out['archive_hash_matches']=h(F/'fetch-P11.tar.gz')==(E/'fetch_archive.sha256').read_text().split()[0]
out['receipt_copies_match']=(A/'receipt.txt').read_bytes()==(E/'receipt.txt').read_bytes() and (F/'build/receipt.txt').read_bytes()==(E/'build_receipt.txt').read_bytes()
out['manifest_matches_fetch']=(F/'manifest.sha256').read_bytes()==(m.PAY/'manifest.sha256').read_bytes()
out['manifest_checks']=subprocess.run(['sha256sum','-c','--strict','--quiet','manifest.sha256'],cwd=m.PAY).returncode==0
out['manifest_entries']=len((m.PAY/'manifest.sha256').read_text().splitlines())
out['archived_compressed_streams_match']={f'chain{k}.{suffix}':gzip.decompress((E/f'chain{k}.{suffix}.gz').read_bytes())==(A/f'chain{k}.{suffix}').read_bytes() for k in [1,2] for suffix in ['log','trace.jsonl']}
oldpay=m.HERE/'payload_v6p2'
out['data_and_starts']={}
for sc in ['R00','P11']:
 out['data_and_starts'][sc]={'data_identical':(oldpay/'data'/f'{sc}.json').read_bytes()==(m.PAY/'data'/f'{sc}.json').read_bytes(), 'starts_identical':[(m.PAY/'inits'/sc/f'chain{k}.json').read_bytes()==(oldpay/'inits'/sc/f'chain{k}.json').read_bytes() for k in range(1,5)]}
out['model_identical']=(oldpay/'model_v6.stan').read_bytes()==(m.PAY/'model_v6.stan').read_bytes()
out['permitted_fits']=(m.PAY/'fits.txt').read_text().split()
env=lambda p:dict(line.split('=',1) for line in p.read_text().splitlines() if line and not line.startswith('#'))
oe,ne=env(oldpay/'run.env'),env(m.PAY/'run.env')
out['settings_deltas']={key:[oe.get(key),ne.get(key)] for key in oe.keys()|ne.keys() if oe.get(key)!=ne.get(key)}
res=m.diagnose(A,'P11',write=False)
out['diagnostics_exact']=res==json.loads((E/'diagnostics.json').read_text())
out['diagnostics']=res
pref=m.prefix_compare(A,B,O/'prefix_comparison.json')
out['prefix_exact']=pref==json.loads((E/'prefix_comparison.json').read_text())
out['prefix']=pref
out['cluster_preflight']={}
for f in sorted((F/'build').glob('point_*.csv')):
 actual=pd.read_csv(f,comment='#').to_numpy(float)
 ref=pd.read_csv(m.PAY/'preflight'/('ref_'+f.name),comment='#').to_numpy(float)
 err=np.max(np.abs(actual-ref)/np.maximum(1,np.abs(ref)))
 out['cluster_preflight'][f.name]={'max_scaled_error':float(err),'pass':bool(err<=1e-6)}
out['warmup_rejections']=[dict(chain=k,transition=e['transition'],cause=e['cause']) for k,c in enumerate(res['chains'],1) for e in c['rejection_events']]
out['independent_bfmi']=[]
out['sampling_energy']=[]
for k in [1,2]:
 df=pd.read_csv(A/f'chain{k}.csv',comment='#')
 out['independent_bfmi'].append(float(np.sum(np.diff(df.energy__.to_numpy())**2)/np.sum((df.energy__-df.energy__.mean())**2)))
 for e in m.read_trace(A/f'chain{k}.trace.jsonl'):
  if e.get('type')!='divergence' or e['phase']!='sampling':continue
  metric=np.array(e['inv_metric']);rec={'chain':k,'transition':e['transition'],'H0':e['H0'],'H_raw':e['H_raw']}
  for name in ['initial','previous','failing']:
   x=e[name];T=0.5*float(np.array(x['p'])@(metric*np.array(x['p'])))
   rec[name]={'V':x['V'],'T':T,'H':T+x['V'],'H_minus_H0':T+x['V']-e['H0'],'sigma':float(np.exp(x['q'][33]))}
  rec['last_leaf_increment']=rec['failing']['H']-rec['previous']['H']
  out['sampling_energy'].append(rec)
out['accounting']=[ln.strip() for ln in (E/'accounting.txt').read_text().splitlines() if any(t in ln for t in ['Job Id:','resources_used.','Exit_status'])]
out['diagnostic_allocated_coreh']=(28*60+23)*4/3600+(1*3600+54*60+44)*2/3600
out['prior_tranche_coreh']=(28*60+38+62*60+13+19*60+10+115*60)*4/3600
out['tranche_allocated_coreh']=out['diagnostic_allocated_coreh']+out['prior_tranche_coreh']
out['remaining_ceiling_coreh']=53+1/3-out['tranche_allocated_coreh']
(O/'replay.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['diagnostics','accounting']},indent=2),flush=True)

# Re-evaluate the 44 captured previous/failing states under each tolerance.
# Use the existing executable explicitly; never call auto-building helpers.
exe=R/'scratch/q012-pilot/trace_build/model_v6'
assert exe.is_file() and h(exe)=='cc48ac6793db8244f3f06705e8366ce0c0e1503bce9e3e279e59b2e8f7d7a086'
old=pathlib.Path('data/q012-pilot/payload_v6p/data/P11.json');new=pathlib.Path('data/q012-pilot/payload_v6d/data/P11.json')
dn,do=json.loads(new.read_text()),json.loads(old.read_text())
ft=dict(old_data=str(old),old_data_sha256=h(old),new_data=str(new),data_fields_differing=sorted(k for k in dn if dn[k]!=do[k]),binary_sha256=h(exe),states=[])
reproduce=[]
for f in sorted(A.glob('chain*.trace.jsonl')):
 for e in m.read_trace(f):
  if e.get('type')!='divergence' or not e.get('captured'):continue
  for which in ['previous','failing']:
   q=np.array(e[which]['q']);lo,go,eo=m.lp_grad(exe,q,old,O/'lp-work');ln,gn,en=m.lp_grad(exe,q,new,O/'lp-work')
   row=dict(chain=e['chain'],transition=e['transition'],phase=e['phase'],state=which,new_data=('rejected: '+en[22:110]) if en else 'finite',old_data=('rejected: '+eo[22:110]) if eo else 'finite')
   if not eo and not en:row['identical_lp_grad']=bool(lo==ln and np.array_equal(go,gn))
   ft['states'].append(row)
   reproduce.append({'chain':e['chain'],'transition':e['transition'],'state':which,'recorded_finite':bool(np.isfinite(e[which]['V'])),'new_rejection':en,'V_identical':None if en else -ln==e[which]['V'],'gradient_identical':None if en else bool(np.array_equal(-gn,np.array(e[which]['grad_V'])))})
(O/'ftol_replay.json').write_text(json.dumps(ft,indent=2)+'\n')
summary={'ftol_exact':ft==json.loads((E/'ftol_1e-11_at_captured_states.json').read_text()),'finite_both_identical':sum(s.get('identical_lp_grad',False) for s in ft['states']),'rejected_both':sum(s['old_data'].startswith('rejected') and s['new_data'].startswith('rejected') for s in ft['states']),'newly_accepted':sum(s['old_data'].startswith('rejected') and s['new_data']=='finite' for s in ft['states']),'recorded_states':reproduce}
(O/'state_replay.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='recorded_states'},indent=2),flush=True)

# Bounded amendment closure, 21 October 2026

Scope: read-only assessment of cd1f8d9 against Codex's 20 October Q-038/Q-015/Q-017/Q-023/Q-031 review. No source search, fit, empirical feasibility certification, tracked edit or board post. HEAD inspected: 3d432f0; subsequent two commits concern Q-012 only. Working tree initially clean.

## Decision

Accept the response as conceptual amendment acceptance. It does not close Q-038's replacement contract, synthetic gates, or empirical readiness. No blocking scientific disagreement remains in the accepted amendments. Explicitly named corrections, withdrawals and replacement gates supersede the preceding draft statements; preserving those earlier statements is an audit trail, not evidence that Claude still endorses them.

## Implemented conceptual corrections

- Q-038: README 218–235 explicitly withholds fit acceptance, withdraws the zero observed-score detection-null park rule, separates observation prediction and latent biological recovery, includes true-death synthetic positive controls and uncertain empirical D/membership, and selects the Fisher biological conditional-set story.
- Q-038: README 236–251 labels retrospective cohort membership, reserves prospective risk-set choice for the next contract, restricts scaling to training data, distinguishes forecast from retrospective transport, calls for masking of histories/traits/scaling/smoothing and separates known/new-clade targets; five events are acknowledged.
- Q-038: README 252–281 requires attribute aggregation/ambiguity export, corrects unit sensitivity and occupancy-vs-taxonomy validation, excludes body size pending actual specimen provenance, scopes archive ascertainment, corrects age/coordinates/recency/observed-loss and detection-replicate interpretation, and identifies six class-event cases. Register 2669–2678 propagates the main restrictions.
- Q-015: literature note 94–118 narrows to occupied calcification-temperature response, corrects 40% attenuation, retains depth/season/proxy rivals, requires a pre-survival-landmark response window and restricted risk set, and demotes the arbitrary series count to a source-access screen. Register 964–968 propagates target/landmark corrections.
- Q-017: literature note 150–181 distinguishes eventual from finite-window identities, requires matched likelihoods and primary methods reading, withdraws two-list sufficiency, preserves the exact heterogeneity counterexample, upgrades Duncan's generic bridge occupancy, notes the closed-fauna problem and prioritises an analytic/likelihood note. Register 1112–1116 propagates core corrections.
- Q-023: combined literature note 162–178 fixes the excess-log-depletion counterfactual and common rate scale, permits offsets/>100% shares, orders matched Frasnian/end-Triassic design before extraction, and predefines baseline/boundary/lag sensitivity. Register 1514–1516 propagates design-first ordering.
- Q-031: combined literature note 180–203 withdraws the equid/ectotherm comparator, separates mammal and ectotherm arms, denies plasticity identification from within-lineage change, corrects four positive warming values/six events, rejects row-level pseudo-replication, replaces the arbitrary eight-series gate with independent-contrast support and holds prior occupancy until SI access. Register 2165–2170 propagates comparator/event/gate repairs.

## What remains open

The Q-038 README itself enumerates the outstanding deliverable at 283–290: one replacement target/observation/fold contract; deterministic prefix-invariance and detection-null examples; explicit transition/exposure likelihood; attribute-ambiguity export. The directory still contains only the original support script and six TSVs plus README. Requirements such as target choice, permitted outcome-adjudication information, actual masking, unseen levels, recovery tolerances and specimen dating must become concrete there before a small recovery probe is earned. This amendment commit changed documentation only.

Q-015's one-event support audit, Q-017's finite-window likelihood note and resolving-information audit, Q-023's matched design, and Q-031's independent-contrast support table remain future work. Acceptance does not certify novelty, adequate empirical support or power.

## Minor editorial residues, not reopening amendments

- Q-038 README 254 uses "conflicting" labels where the reviewed finding was multiple labels/unresolved mappings, including nomenclatural differences. Avoid interpreting 108/12 as demonstrated biological taxonomy contradictions.
- STATUS 132 and 933–943/967–968 still speak of Claude's amendment as next; these are stale coordination text after cd1f8d9, although the substantive replacement contract truly remains pending.
- Register 2154–2157 still says the Q-031 kill criterion is "very probably clear". The authoritative newer amendment in its linked literature note 201–203 correctly keeps occupancy provisional until the published SI is read. Carry the provisional wording into any current ranking; the amendment is accepted without treating unread SI as absence of an analysis.
- Older Q-038 zero-gain/size/cohort and Q-015/017/031 gate statements are explicitly superseded by adjacent amendment sections; they are not grounds to reject closure of conceptual acceptance.

Next owner: Claude, Q-038 replacement contract first, within the existing two-task limit. Parent handles Q-012 independently.

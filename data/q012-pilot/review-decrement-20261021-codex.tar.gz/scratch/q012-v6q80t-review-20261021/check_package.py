"""Read-only package audit plus isolated metadata mutations; no sampler run."""
import hashlib
import importlib.util
import json
import math
import pathlib
import shutil
import tarfile

ROOT = pathlib.Path.cwd()
HERE = ROOT / 'data/q012-pilot'
OUT = ROOT / 'scratch/q012-v6q80t-review-20261021'
PAY = HERE / 'payload_v6q80t'
OLD = HERE / 'payload_v6q80'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())

manifest = {}
for line in (PAY/'manifest.sha256').read_text().splitlines():
    h, name = line.split(maxsplit=1)
    manifest[name] = sha(PAY/name) == h
assert len(manifest) == 31 and all(manifest.values())
metadata = read(PAY/'manifest.json')
assert metadata['manifest_sha256'] == sha(PAY/'manifest.sha256')
assert metadata['pilot_json_sha256'] == sha(HERE/'pilot.json')
oldfiles = {str(p.relative_to(OLD)) for p in OLD.rglob('*') if p.is_file()}
newfiles = {str(p.relative_to(PAY)) for p in PAY.rglob('*') if p.is_file()}
assert oldfiles == newfiles
changed = sorted(n for n in oldfiles if (OLD/n).read_bytes() != (PAY/n).read_bytes())
refcsv = sorted(n for n in changed if n.startswith('preflight/ref_') and n.endswith('.csv'))
assert len(refcsv)==4
data_lines = lambda p: [x for x in p.read_text().splitlines() if x and not x.startswith('#')]
for n in refcsv:
    assert data_lines(OLD/n)==data_lines(PAY/n)
assert [n for n in changed if n not in refcsv] == ['manifest.json','manifest.sha256','pbs/fit.pbs','pbs/fit.sh','run.env'], changed
env = lambda p: dict(line.split('=',1) for line in p.read_text().splitlines() if line and not line.startswith('#'))
oe, ne = env(OLD/'run.env'), env(PAY/'run.env')
envdiff = {k:[oe.get(k),ne.get(k)] for k in oe.keys()|ne.keys() if oe.get(k)!=ne.get(k)}
assert envdiff == {'TERM_BUFFER':[None,'500']}
for s in ('P11','R00'):
    assert (PAY/'data'/f'{s}.json').read_bytes() == (OLD/'data'/f'{s}.json').read_bytes()
    for k in range(1,5):
        assert (PAY/'inits'/s/f'chain{k}.json').read_bytes()==(OLD/'inits'/s/f'chain{k}.json').read_bytes()
assert (PAY/'fits.txt').read_text().strip()=='P11'

bank = read(HERE/'order_preflight_v6q80t.json')
prior = read(HERE/'order_preflight_v6q80t_step_criterion.json')
assert bank['all_pass'] is True and prior['all_pass'] is False
assert prior['normaliser_bank']['amended_P11_49']['unresolved']==['9707']
assert bank['normaliser_bank']['amended_P11_49']['states']==49
assert bank['normaliser_bank']['R00_v6_49']['states']==49
points = bank['normaliser_points']
assert len(points)==64
for name,g in points.items():
    err = [v for k,v in g.items() if k.startswith('d_') and k.endswith('_err')]
    assert g['pass'] is True and math.isfinite(g['log_err']) and g['log_err']<=1e-4
    assert all(math.isfinite(v) and v<=1e-3 for v in err)
    assert g['local']['qualified'] is True
    if g['fixed']['qualified']: assert g['cross_check']['converged'] is True
unqualified=[k for k,g in points.items() if not g['fixed']['qualified']]
assert len(unqualified)==7
assert bank['normaliser_bank']['points']['max_log_err'] == max(g['log_err'] for g in points.values())
for k in ('inputs','reused_binary','controls','order_binding','ad_vs_fd_captured','expanded_domain_comparison'):
    assert bank[k]['ok'] is True
rec=HERE/bank['reused_binary']['receipt']
assert sha(rec)==bank['reused_binary']['receipt_sha256']==ne['REUSE_BUILD_RECEIPT_SHA256']
assert pathlib.Path(bank['binary']).is_file()
assert sha(pathlib.Path(bank['binary']))==bank['binary_sha256']
bank_source_hashes = {}
for record,cache,scenario in [
    ('P11-amended-20261018-v6p2','fetch-20261018-v6p2','P11'),
    ('R00-v6-20261017-v6r00','fetch-20261017-v6r00','R00')]:
    for line in (HERE/'results'/record/'chain_files.sha256').read_text().splitlines():
        expected,name=line.split(maxsplit=1)
        path=ROOT/'scratch/q012-pilot'/cache/'runs'/scenario/'attempt1'/name
        assert sha(path)==expected,(record,name)
        bank_source_hashes[str(path.relative_to(ROOT))]=expected
stress=ROOT/'scratch/q012-capture-review-codex/inputs/fixed_48_stress_states.json'
assert read(stress)['source_sha256']==bank['stress_source']['source_sha256']
with tarfile.open(HERE/'review-capture-20261019-codex.tar.gz') as tar:
    assert tar.extractfile('inputs/fixed_48_stress_states.json').read()==stress.read_bytes()
bank_source_hashes[str(stress.relative_to(ROOT))]=sha(stress)

spec=importlib.util.spec_from_file_location('pilot_review',HERE/'pilot.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
fixture=ROOT/'scratch/q012-pilot/selftest'
good=fixture/'runs/FX/attempt1'
fe=env(fixture/'run.env'); rc=m._receipt(good/'receipt.txt')
br=m._receipt(fixture/'build/receipt.txt')
br['manifest_sha256']=rc['manifest_sha256'] # same historical fixture reseal handling as selftest
grammar=m.rejection_grammar(PAY/'model_v6.stan',fixture/'data/FX.json')
def qualify(attempt,e=fe):
    return m.qualify(attempt,'FX',e,rc['manifest_sha256'],br,grammar)
tests={'good':qualify(good),
       'wrong_expected_buffer':qualify(good,dict(fe,TERM_BUFFER='50')),
       'omitted_expected_buffer':qualify(good,{k:v for k,v in fe.items() if k!='TERM_BUFFER'})}
assert tests['good']==[]
for name in ('wrong_expected_buffer','omitted_expected_buffer'):
    assert any('term_buffer' in v for v in tests[name])
# Independently mutate actual recorded outputs while retaining the expected 500.
for name,member,old,new in [
    ('csv_buffer_50','chain1.csv','#       term_buffer = 500','#       term_buffer = 50 (Default)'),
    ('csv_buffer_absent','chain1.csv','#       term_buffer = 500\n',''),
    ('log_buffer_50','chain1.log','      term_buffer = 500','      term_buffer = 50 (Default)'),
    ('log_buffer_absent','chain1.log','      term_buffer = 500\n','')]:
    dest=OUT/'fixtures'/name/'attempt1'
    shutil.copytree(good,dest,dirs_exist_ok=True)
    p=dest/member; txt=p.read_text(); assert old in txt,(name,old)
    p.write_text(txt.replace(old,new,1))
    tests[name]=qualify(dest)
    assert tests[name] and any('term_buffer' in x or 'header' in x for x in tests[name])

# Historical result keeps its own 50-buffer grammar; no requalification under 500.
oldenv=env(HERE/'payload_v6p2/run.env')
oldresult=ROOT/'scratch/q012-pilot/fetch-20261018-v6p2/runs/P11/attempt1'
for k in range(1,5):
    assert m.csv_meta(oldresult/f'chain{k}.csv')['term_buffer'].startswith('50')
    header=m.expected_header(oldenv,'P11',k,f'runs/P11/attempt1/chain{k}.csv')
    assert '      term_buffer = 50 (Default)' in header

selftest=read(HERE/'selftest.json')
assert selftest['all_pass'] is True
dispatch=read(HERE/'dispatch_test_v6q80t.json')
assert dispatch['all_pass'] is True
output=dict(manifest_sha256=sha(PAY/'manifest.sha256'),manifest_files_checked=len(manifest),
            payload_changed_files=changed,run_env_changes=envdiff,
            model_patch_data_starts_preflight_numeric_unchanged=True,
            preflight_csv_only_headers_changed=refcsv,
            normaliser_bank=bank['normaliser_bank'],fixed_disqualified=unqualified,
            bank_checks='Recomputed 64 saved point decisions and read two 49-state bank summaries; no full-bank numerical rerun.',
            reused_receipt_hash=sha(rec),local_binary_hash=bank['binary_sha256'],
            bank_source_hashes=bank_source_hashes,
            stored_selftest_pass=True,stored_dispatch_pass=True,qualification_replay=tests,
            historical_default50_metadata_and_header_pass=True,
            reviewed_inputs={str(p.relative_to(ROOT)):sha(p) for p in [HERE/'pilot.py',HERE/'pilot.json',HERE/'selftest.json',HERE/'order_preflight_v6q80t.json',HERE/'order_preflight_v6q80t_step_criterion.json']})
(OUT/'package_checks.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k not in ('qualification_replay','reviewed_inputs','normaliser_bank','bank_source_hashes')},indent=2))

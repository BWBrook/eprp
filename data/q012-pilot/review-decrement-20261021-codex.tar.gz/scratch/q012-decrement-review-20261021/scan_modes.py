"""All declared bank modes/stencils only: no integration, AGH, AD, pool or fit."""
from check import *

def bank():
    jobs=[]
    for name,sub,sc in [('P11','fetch-20261018-v6p2','P11'),('R00','fetch-20261017-v6r00','R00')]:
        dat=json.loads((M.PAY/'data'/f'{sc}.json').read_text())
        path=ROOT/'scratch/q012-pilot'/sub/'runs'/sc/'attempt1'
        frame=pd.concat([pd.read_csv(path/f'chain{k}.csv',comment='#') for k in range(1,5)],ignore_index=True)
        sel=list(dict.fromkeys([int(i) for i in frame.nlargest(6,'sigma').index]+[int(frame.kappa_b.abs().idxmax()),int(frame.rho.idxmin()),int(frame.rho.idxmax())]+[int(i) for i in np.linspace(0,len(frame)-1,40).astype(int)]))
        assert len(sel)==49
        jobs += [(f'{name}_{i}',dat,M.P.draw_to_params(frame.iloc[i],dat['N']),()) for i in sel]
    D={sc:json.loads((M.PAY/'data'/f'{sc}.json').read_text()) for sc in ['P11','R00']}
    for sc in D:
        for k in range(1,5):jobs.append((f'start_{sc}_{k}',D[sc],M.w_to_eps(json.loads((M.PAY/'inits'/sc/f'chain{k}.json').read_text())),()))
    s=json.loads((M.PAY/'inits/P11/chain1.json').read_text())
    for sg in [.01,.001]:
        qq=dict(s,sigma=sg,w=[x/s['sigma']**.2*sg**.2 for x in s['w']]);jobs.append((f'small_{sg}',D['P11'],M.w_to_eps(qq),()))
    stress=json.loads((ROOT/'scratch/q012-capture-review-codex/inputs/fixed_48_stress_states.json').read_text())
    for nm,qq in stress['states'].items():jobs.append((nm,D['P11'],M.w_to_eps(qq),()))
    for k in [1,2]:
        e=next(x for x in M.read_trace(ROOT/f'scratch/q012-pilot/fetch-20261019-v6d/runs/P11/attempt1/chain{k}.trace.jsonl') if x.get('type')=='divergence' and x['phase']=='sampling')
        for st in ['initial','previous','failing']:
            qq=M.constrain(e[st]['q'],D['P11']['N']);jobs.append((f'triad{k}_{st}',D['P11'],qq,('log_k','log_h0_1')))
    assert len(jobs)==162
    return jobs

def scan(dat,qq):
    A=M.P.cohort_A(dat,qq);b0=math.exp(qq['log_b0']);s,r,k=qq['sigma'],qq['rho'],qq['kappa_b']
    ts=[([A[i-1]],[b0*(dat['c']-dat['o'][i-1])]) for i in dat['c1_lin']]
    ts += [([A[ip-1],A[idd-1]],[b0*(dat['c']-dat['o'][i-1]) for i in (ip,idd)]) for ip,idd in zip(dat['c2_par'],dat['c2_dau'])]
    rows=[]
    for aa,bb in ts:
        a,b=np.array(aa),np.array(bb);nd=len(a);y=np.zeros(nd)
        V=np.array([[1/s**2]]) if nd==1 else np.linalg.inv(s*s*np.array([[1,r],[r,1]]))
        min_dec=math.inf;invalid=[]
        for it in range(200):
            ep=a*np.exp(y-s*s/2);eb=b*np.exp(k*(y-s*s/2));P=V+np.diag(ep+k*k*eb)
            g=-V@y-ep-k*eb;st=np.linalg.solve(P,g);dec=float(g@st);y+=st
            if not (np.all(np.isfinite(g)) and np.all(np.isfinite(st)) and np.all(np.isfinite(P)) and math.isfinite(dec) and dec>=0):invalid.append(it+1)
            min_dec=min(min_dec,dec)
            if max(abs(st))<1e-14 or dec<=1e-20:break
        ep=a*np.exp(y-s*s/2);eb=b*np.exp(k*(y-s*s/2));T=np.linalg.cholesky(np.linalg.inv(V+np.diag(ep+k*k*eb)))
        rows.append(dict(it=it+1,dec2=dec,min_dec2=min_dec,invalid_iterations=invalid,step=float(max(abs(st))),decrement_branch=bool(max(abs(st))>=1e-14),finite_curvature=bool(np.all(np.isfinite(T)))))
    return rows

jobs=bank();records={};tot=0
for name,dat,qq,extra in jobs:
    states={'base':qq}
    for ax in M._axes(dat,extra):
        h=M._steps(qq)[ax]
        for sign in [-1,1]:states[f'{ax}{sign:+d}']=dict(qq,**{ax:qq[ax]+sign*h})
    records[name]={nm:scan(dat,qj) for nm,qj in states.items()};tot+=len(states)
rows=[x for s in records.values() for v in s.values() for x in v]
res=dict(bank_states=len(jobs),base_and_stencil_evaluations=tot,cohort_mode_solves=len(rows),invalid_decrements=sum(bool(x['invalid_iterations']) for x in rows),nonfinite_curvature=sum(not x['finite_curvature'] for x in rows),exhausted=sum(x['it']==200 for x in rows),decrement_only_stops=sum(x['decrement_branch'] for x in rows),minimum_dec2=min(x['min_dec2'] for x in rows),maximum_iterations=max(x['it'] for x in rows),records=records)
(OUT/'all_bank_mode_diagnostics.json').write_text(json.dumps(res,indent=2)+'\n')
print({k:v for k,v in res.items() if k!='records'})

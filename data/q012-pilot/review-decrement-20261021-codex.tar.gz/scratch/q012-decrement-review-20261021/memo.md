# Q-012 Newton-decrement review

21 October 2026. Independent bounded review of the `local_reference` stopping
amendment in `data/q012-pilot/pilot.py`, at checkout `3d432f0`.

**Decision: the squared-decrement criterion and candidate admission are
numerically defensible.** The old step rule fails because of floating-point
cancellation near rho=1. It is not identifying an inaccurate normaliser at
the disputed row. Preserve the failed step-only bank and identify the changed
reference criterion prospectively. No new sampler adjustment is warranted by
this event.

## Mathematics

For log-integrand gradient g and positive negative-Hessian P, the Newton
increment is delta=P^-1 g and the squared Newton decrement is
lambda^2=g^T P^-1 g. The quadratic model predicts a log-integrand gain of
**lambda^2/2**, not lambda^2. Correct that inline annotation. The decrement
is invariant under nonsingular affine coordinate changes in exact arithmetic;
the implementation and its floating-point errors are not. The local-mode
integration is still integration of the original integrand under a coordinate
change, so it retains the separate resolution and domain qualification.

At a squared decrement of 1e-20, the local predicted remaining objective gain
is 5e-21. This is a local quadratic interpretation, not a global integration
error certificate. The unchanged integration checks supply the relevant
finite-state evidence.

The implementation should explicitly require `isfinite(dec2) and dec2 >= 0`
before either stopping branch accepts a solve, and should reject nonfinite
gradient, step and curvature. A negative decrement is incompatible with a
valid positive-definite quadratic solve; accepting it via `dec2 <= 1e-20`
would be logically wrong. This is a small fail-closed correctness improvement,
with direct mode-only evidence that the actual bank encountered no such case.
It should not
be presented as a newly observed numerical failure or a reason for another
tuning programme. The present row/stencil has finite, positive decrements and
positive curvature throughout.

## Direct reconstruction of row 9707

The original amended-P11 CSVs have 8,000 retained sampling rows each, with
warmup excluded; the concatenated zero-based index 9707 is chain 2 row 1707.
Parameters are sigma=1.0808045,
rho=.99998221, kappa_b=1.1316354 and log_b0=-4.7486598. There are four singleton
cohorts and one pair. We evaluated the base and all six domain-safe
sigma/rho/kappa_b finite-difference perturbations used by `gate_point`.

The pair Hessian condition number is about 90,534 at the base and reaches
181,068.54 at rho+h. The original 1e-14 step criterion exhausts 200 iterations
at the base and five of the six perturbations, with final maximum steps from
1.93e-13 to 6.34e-13. The remaining kappa_b+h solve passes at iteration 20.

The amended rule passes the pair at iteration 4 in all seven cases, with
positive squared decrements between 6.38e-25 and 4.77e-24. Against independent
70-digit Decimal Newton solves using exact two-dimensional matrix algebra,
the largest coordinate error after stopping is 9.79e-13. The largest squared
curvature distance to the high-precision mode is 1.02e-24. At the base the
returned pair mode is [-.23650569893497894,-.2365048553421345]; the Decimal
mode rounded to doubles is [-.23650569893571965,-.23650485534287521]. The
stall is far below a meaningful integration error scale.

## Independent integration check

`check.py` also integrates in independent standard-Gaussian eigen-coordinates,
using sum/difference directions. This avoids explicit correlated precision
quadratics and their cancellation, and solves modes in the well-conditioned
Gaussian coordinates. It shares the upstream cohort-A calculation and model,
but not `local_reference`'s mode solver, covariance inversion, or precision
quadratic. Singleton/pair integrals use Simpson integration in 64-row chunks.

The stable reference passes the unchanged 1e-6/1e-5 convergence tolerances:
800 versus 1,600 intervals on [-12,12], and 1,600 on [-12,12] versus [-16,16].
Maximum absolute derivative change is 3.75e-11; maximum value change is
2.45e-15. Its expanded result is:

| Quantity | Stable reference | Current local minus stable | Q80 minus stable |
| --- | ---: | ---: | ---: |
| log normaliser | -1.1340117003984789 | 3.82e-13 | -4.22e-15 |
| sigma derivative | .47698271540941306 | -4.97e-9 | 2.22e-12 |
| kappa_b derivative | -.023438888692162152 | 9.87e-10 | 7.77e-12 |
| rho derivative | .04811454813354163 | -9.61e-8 | 4.99e-11 |

The current local reference's rho derivative has more roundoff than the
stable calculation, amplified by its small finite-difference step. It is
still more than 100 times inside the reference derivative-convergence
tolerance and over 10,000 times inside the Q80 derivative-accuracy tolerance.
The unchanged Q80 approximation is accurate at this reconstructed state.

## Scope and retained evidence

The preserved `order_preflight_v6q80t_step_criterion.json` reports exactly one
unresolved row, 9707, and `all_pass=false`. The amended
`order_preflight_v6q80t.json` reports all 162 checks converged/passed with
`all_pass=true`. I inspected these records; I did not rerun the full bank.
The bank summary maxima are unchanged apart from numerical rounding. The
parent separately handles actual-Stan AD/bindings, payload/manifest,
qualification and archival checks.

After that check, the parent requested a cheap full-bank **mode-only** scan.
`scan_modes.py` reconstructs the same 49+49+8+2+48+6 state allocation and all
the original derivative axes. Its 162 states imply 1,158 base/stencil
evaluations and 5,790 individual cohort mode solves. Every iterate has finite
gradient, step and curvature and a finite nonnegative decrement; every final
curvature is finite. There are zero exhausted solves, 2,307 solves use the
decrement branch before satisfying the 1e-14 step branch, and the maximum
iteration count is 12. The smallest observed decrement is zero. Thus the
proposed explicit invalid-decrement guard would change **no admission** in
the existing bank. With a finite SPD Hessian, negative decrement is impossible
in exact arithmetic; the guard protects against future nonfinite arithmetic,
loss of positive definiteness, or sufficiently extreme ill-conditioning,
rather than repairing a demonstrated acceptance failure in this candidate.

This scan performs no quadrature, actual-Stan calls or AD tests and is not a
second full numerical-bank replay.

All new work is confined to this ignored scratch directory: `check.py`,
`state9707.json`, `mode_results.json`, `results.json`, `run.log`,
`scan_modes.py`, `all_bank_mode_diagnostics.json`, and `scan_modes.log`.
Reproduce
with the existing interpreter:

    /home/bwbrook/.cache/uv/environments-v2/pilot-0220b97637f825e7/bin/python scratch/q012-decrement-review-20261021/check.py

The script pins numerical libraries to one CPU through environment variables.
No tracked edits, correspondence writes, remote work, compilation, sampler
fits, full-bank replay or process pool were used. Complete: bounded numerical
review. Provisional: wider untested states remain outside the finite-bank
claim. Next owner: parent Codex integrates this with package review.

21 October 2026, 11:27 AEDT (Australia/Hobart).

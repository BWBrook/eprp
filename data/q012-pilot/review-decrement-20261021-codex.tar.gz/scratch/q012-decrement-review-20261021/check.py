"""Bounded independent review of row 9707; single CPU, no fits/Stan/pool."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k]='1'
import decimal, importlib.util, json, math, pathlib, sys
import numpy as np
import pandas as pd

ROOT=pathlib.Path('/home/bwbrook/git/eprp')
OUT=ROOT/'scratch/q012-decrement-review-20261021'
sp=importlib.util.spec_from_file_location('pilot',ROOT/'data/q012-pilot/pilot.py')
M=importlib.util.module_from_spec(sp);sp.loader.exec_module(M)
d=json.loads((M.PAY/'data/P11.json').read_text())
df=pd.read_csv(ROOT/'scratch/q012-pilot/fetch-20261018-v6p2/runs/P11/attempt1/chain2.csv',comment='#')
# Original amended CSVs retain 8,000 sampling rows, with warmup excluded: concat9707 is chain2 row1707.
q=M.P.draw_to_params(df.iloc[1707],d['N'])
(OUT/'state9707.json').write_text(json.dumps(q,indent=2)+'\n')
decimal.getcontext().prec=70
D=lambda x:decimal.Decimal(str(x))

def terms(q):
    A=M.P.cohort_A(d,q);b0=math.exp(q['log_b0'])
    ts=[([A[i-1]],[b0*(d['c']-d['o'][i-1])]) for i in d['c1_lin']]
    ts += [([A[ip-1],A[idd-1]],[b0*(d['c']-d['o'][i-1]) for i in (ip,idd)]) for ip,idd in zip(d['c2_par'],d['c2_dau'])]
    return ts

def decimal_mode(aa,bb,q):
    s,r,k=D(q['sigma']),D(q['rho']),D(q['kappa_b']);n=len(aa)
    a,b=list(map(D,aa)),list(map(D,bb));y=[D(0)]*n
    if n==1:V=[[1/s**2]]
    else:
        v=1/(s*s*(1-r*r));V=[[v,-r*v],[-r*v,v]]
    for it in range(100):
        ep=[a[i]*(y[i]-s*s/2).exp() for i in range(n)]
        eb=[b[i]*(k*(y[i]-s*s/2)).exp() for i in range(n)]
        g=[-sum(V[i][j]*y[j] for j in range(n))-ep[i]-k*eb[i] for i in range(n)]
        P=[[V[i][j]+(ep[i]+k*k*eb[i] if i==j else 0) for j in range(n)] for i in range(n)]
        if n==1:step=[g[0]/P[0][0]]
        else:
            det=P[0][0]*P[1][1]-P[0][1]*P[1][0]
            step=[(g[0]*P[1][1]-g[1]*P[0][1])/det,(g[1]*P[0][0]-g[0]*P[1][0])/det]
        y=[yi+si for yi,si in zip(y,step)]
        if max(map(abs,step))<D('1e-60'):break
    return np.array(list(map(float,y)))

def double_mode(aa,bb,q,stop):
    s,r,k=q['sigma'],q['rho'],q['kappa_b'];n=len(aa);a,b=np.array(aa),np.array(bb)
    V=np.array([[1/s**2]]) if n==1 else np.linalg.inv(s*s*np.array([[1,r],[r,1]]))
    y=np.zeros(n);tr=[]
    for it in range(200):
        ep=a*np.exp(y-s*s/2);eb=b*np.exp(k*(y-s*s/2))
        P=V+np.diag(ep+k*k*eb);g=-V@y-ep-k*eb;step=np.linalg.solve(P,g);dec=float(g@step)
        y+=step;tr.append(dict(it=it+1,step=float(max(abs(step))),dec2=dec,y=y.tolist()))
        if max(abs(step))<1e-14 or (stop=='decrement' and dec<=1e-20):break
    yh=decimal_mode(aa,bb,q)
    err=y-yh
    return dict(iterations=it+1,step=tr[-1]['step'],dec2=dec,y=y.tolist(),decimal_y=yh.tolist(),error_max=float(max(abs(err))),
                quadratic_distance=float(err@P@err),condition=float(np.linalg.cond(P)),tail=tr[-5:]),y

def stable_reference(q,n=1600,L=16):
    """Local integration in Gaussian eigen-coordinates; no dense precision quadratic/cancellation."""
    s,r,k=q['sigma'],q['rho'],q['kappa_b'];e=np.linspace(-L,L,n+1)
    w=np.ones(n+1);w[1:-1:2]=4;w[2:-1:2]=2;lw=np.log(w*(2*L)/(3*n));ans=0.
    for aa,bb in terms(q):
        a,b=np.array(aa),np.array(bb);nd=len(a)
        if nd==1:B=np.array([[s]])
        else:B=s/np.sqrt(2)*np.array([[np.sqrt(1+r),np.sqrt(1-r)],[np.sqrt(1+r),-np.sqrt(1-r)]])
        # Solve using stable precision of independent standard Gaussian coordinates.
        z=np.zeros(nd)
        for it in range(100):
            x=B@z;ep=a*np.exp(x-s*s/2);eb=b*np.exp(k*(x-s*s/2))
            g=-z-B.T@(ep+k*eb);P=np.eye(nd)+B.T@np.diag(ep+k*k*eb)@B
            st=np.linalg.solve(P,g);z+=st
            if float(g@st)<=1e-26:break
        T=np.linalg.cholesky(np.linalg.inv(P))
        def obj(Z):
            X=B@Z
            return -np.sum(a[:,None]*np.exp(X-s*s/2)+b[:,None]*np.exp(k*(X-s*s/2)),axis=0)-np.sum(Z*Z,axis=0)/2-nd*math.log(2*math.pi)/2
        if nd==1:
            Z=z[:,None]+T@e[None,:]
            ans+=math.log(T[0,0])+M._lse(lw+obj(Z))
        else:
            logs=[]
            for i in range(0,n+1,64):
                E1,E2=np.meshgrid(e[i:i+64],e,indexing='ij');E=np.array([E1.ravel(),E2.ravel()])
                Z=z[:,None]+T@E
                logs.append(M._lse((lw[i:i+64,None]+lw[None,:]+obj(Z).reshape(E1.shape)).ravel()))
            ans+=np.log(np.linalg.det(T))+M._lse(np.array(logs))
    return ans

def main():
    states={'base':q}
    for axis in ('sigma','rho','kappa_b'):
        h=M._steps(q)[axis]
        for sign in (-1,1):states[f'{axis}{sign:+d}']=dict(q,**{axis:q[axis]+sign*h})
    modes={}
    for name,qq in states.items():
        modes[name]=[]
        for aa,bb in terms(qq):
            old,_=double_mode(aa,bb,qq,'step');new,_=double_mode(aa,bb,qq,'decrement')
            modes[name].append(dict(a=list(map(float,aa)),b=bb,step_only=old,decrement=new))
    result=dict(parameters={k:q[k] for k in ('sigma','rho','kappa_b','log_b0')},modes=modes)
    (OUT/'mode_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print('mode maximum condition',max(x['decrement']['condition'] for xs in modes.values() for x in xs),flush=True)
    print('mode stalled',[(k,i,x['step_only']['step'],x['step_only']['dec2']) for k,xs in modes.items() for i,x in enumerate(xs) if x['step_only']['iterations']==200],flush=True)
    print('max new error',max(x['decrement']['error_max'] for xs in modes.values() for x in xs),flush=True)
    refs={}
    for name,f in [('original',lambda qq:M.local_reference(d,qq,1600,16)),('stable_n800L12',lambda qq:stable_reference(qq,800,12)),
                   ('stable_n1600L12',lambda qq:stable_reference(qq,1600,12)),('stable_n1600L16',lambda qq:stable_reference(qq,1600,16))]:
        refs[name]=M._values(d,q,f);print(name,refs[name],flush=True)
        result['references']=refs;(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    result['reference_differences']={k:{axis:v[axis]-refs['stable_n1600L16'][axis] for axis in v} for k,v in refs.items()}
    result['agh']=M._values(d,q,lambda qq:M.P.log_norm_agh(d,qq,M.P.cohort_A(d,qq)))
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print('diffs',result['reference_differences'],flush=True)
    print('agh',result['agh'],flush=True)

if __name__=='__main__':main()

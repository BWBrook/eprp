# Q012 decrement and amendment review, 21 October 2026

The governing parent note is ideas/2026-10-21-q012-decrement-and-amendment-closure-codex.md.
This archive holds independent mode/integral and mode-only-bank scripts/results,
a package/metadata qualification replay, and the backlog amendment closure memo.
Scripts retain original scratch-relative paths. Use an isolated reviewed checkout
3d432f0 with the original preserved inputs at their recorded paths. The numerical
script's ROOT currently names /home/bwbrook/git/eprp; change only this root for an
isolated relocated replay. The current package candidate must remain v6q80t.

Commands with the pinned Python environment (versions in environment.txt):

    python scratch/q012-decrement-review-20261021/check.py
    python scratch/q012-decrement-review-20261021/scan_modes.py
    python scratch/q012-v6q80t-review-20261021/check_package.py

check.py: reconstructed index9707,70-digit Decimal modes, independent Gaussian
coordinate Simpson integrals and all three finite-difference axes. scan_modes.py:
all162 state/stencil mode solves only, no quadrature or Stan calls.
check_package.py:31member hashes, payload differences, frozen input checks,
saved gate decisions, and local qualification of preserved good/altered metadata.
It does not launch a sampler or replay the complete selftest or quadrature bank.

The small preserved selftest fixture is included to reproduce metadata mutations.
The original CSV/trace banks and binaries are not duplicated. Their hashes and
paths are in package_checks.json and additional-input-hashes.json. Review scripts
reuse the original prototype cohort-A calculation; their independence is bounded,
not an independent implementation of the entire model. The stored high-precision
mode comparison treats the cohort terms computed in doubles as its inputs.

All internal member hashes (except the manifest itself) are in manifest-sha256.json.
Hash checks establish integrity, not scientific validity.

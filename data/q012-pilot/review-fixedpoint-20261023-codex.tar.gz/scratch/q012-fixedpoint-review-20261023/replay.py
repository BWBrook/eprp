"""Read-only receipt reassembly; no numerical evaluations."""
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "data/q012-pilot"
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("fp", SRC / "p11_fixedpoint.py")
F = importlib.util.module_from_spec(spec)
spec.loader.exec_module(F)
raw = gzip.open(SRC / "p11_fixedpoint_run.jsonl.gz", "rb").read()
(OUT / "receipts.jsonl").write_bytes(raw)
rs = [json.loads(l) for l in raw.splitlines()]
expected = [F._key(t) for t in F.tasks()]
assert len(rs) == len(expected) == len(set(r["key"] for r in rs)) == 660
assert set(expected) == {r["key"] for r in rs}
assert not any("skipped" in r or "unresolved" in r for r in rs)
F.RESULTS, F.SUMMARY = OUT / "receipts.jsonl", OUT / "reassembled.json"
with contextlib.redirect_stdout(io.StringIO()):
    F.assemble()
saved = json.loads((SRC / "p11_fixedpoint_results.json").read_text())
new = json.loads(F.SUMMARY.read_text())
assert saved == new
rows = new["rows"]
fc = json.loads((SRC / "fisher_tree_check.json").read_text())
assert set(fc) == set(F.load_bank())
assert all(set(r["trees"]) == set(F.TREES) for r in fc.values())
manifest = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in [
    SRC / n for n in ("p11_fixedpoint.py", "p11_fixedpoint.md", "p11_fixedpoint_bank.json",
        "p11_fixedpoint_run.jsonl.gz", "p11_fixedpoint_results.json", "p11_fixedpoint_benchmark.json",
        "p11_fixedpoint_calibration_macmini.json", "p11_fixedpoint_fixtures.json", "fisher_tree.py",
        "fisher_tree_check.json", "fisher_gradient_probe.py", "fisher_gradient_probe.json",
        "collapsed_oracle.py", "pilot.py", "payload_v6q80t/model_v6.stan", "payload_v6q80t/data/P11.json")
]}
out = dict(exact_reassembly=True, record_count=len(rs), tasks=Counter(r["kind"] for r in rs),
    status_counts=new["status_counts"], r2_counts=new["r2_counts"], cost=new["cost"],
    raw_untracked_matches=raw == (SRC / "p11_fixedpoint_run.jsonl").read_bytes(),
    maxima={k: [max(r[k][i] for r in rows) for i in range(2)] for k in ("self_resolution", "self_domain", "R1_chain")},
    R1_big_value=max(r["R1_big_value"] for r in rows), R1_big_deriv=max(r["R1_big_deriv"] for r in rows),
    R2_qualified_max=[max(r["chain_vs_R2"][i] for r in rows if r["R2_qualified"]) for i in range(2)],
    I1=max(r["I1"] for r in rows), I2=max(abs(r["I2"]["selection_minus_ref"]) for r in rows),
    q80_max=max(abs(r["I2"]["selection_minus_q80"]) for r in rows),
    primary_value_seconds=[min(r["candidate_seconds"]["primary"]["value"] for r in rows), max(r["candidate_seconds"]["primary"]["value"] for r in rows)],
    primary_FD_seconds=[min(r["candidate_seconds"]["primary"]["gradient"] for r in rows), max(r["candidate_seconds"]["primary"]["gradient"] for r in rows)],
    fisher_seconds=[min(r["fisher_seconds_total"] for r in fc.values()), max(r["fisher_seconds_total"] for r in fc.values())],
    fisher_max_value_difference=max(t["value_minus_batch"] for r in fc.values() for t in r["trees"].values()),
    fisher_max_grad_difference=max(r["max_abs_grad_diff"] for r in fc.values()),
    fisher_nine=[k for k,r in fc.items() if r["max_abs_grad_diff"] <= 6.7e-7], hashes=manifest)
(OUT / "replay.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps({k:v for k,v in out.items() if k != "hashes"}, indent=2))

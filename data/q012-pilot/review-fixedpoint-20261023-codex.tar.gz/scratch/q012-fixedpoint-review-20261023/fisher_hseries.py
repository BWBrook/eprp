"""One coordinate, one big-tree state; bounded local derivative probe."""
import os
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[key] = "1"
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
import importlib.util
import json
import time
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("ft", ROOT / "data/q012-pilot/fisher_tree.py")
FT = importlib.util.module_from_spec(spec)
spec.loader.exec_module(FT)
F, O = FT.F, FT.O
name = "holdout_c4f_sigma15"
p = F.load_bank()[name]
u = O.p_to_u(p)
j = O.NAMES.index("kappa")
t0 = time.perf_counter()
v, g = FT.FisherTree(p, F.TREES[F.BIG], F.COH).gradient()
series = []
for h in (2e-4, 1e-4, 5e-5):
    e = np.zeros(35); e[j] = h
    plus = F.trees_log(O.u_to_p(u + e), only={F.BIG})[F.BIG]
    minus = F.trees_log(O.u_to_p(u - e), only={F.BIG})[F.BIG]
    fd = (plus - minus) / (2 * h)
    series.append(dict(h=h, plus=plus, minus=minus, fd=fd, fd_minus_fisher=fd - g[j]))
out = dict(point=name, tree=F.BIG, coordinate=O.NAMES[j], numerator_value=v,
    fisher=float(g[j]), series=series, ratios=[series[i]["fd_minus_fisher"] / series[i+1]["fd_minus_fisher"] for i in range(2)],
    richardson_minus_fisher=[(4 * series[i+1]["fd"] - series[i]["fd"]) / 3 - g[j] for i in range(2)],
    seconds=time.perf_counter()-t0, numpy=np.__version__, pinned_cpu=list(os.sched_getaffinity(0)))
Path(__file__).with_name("fisher_hseries.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))

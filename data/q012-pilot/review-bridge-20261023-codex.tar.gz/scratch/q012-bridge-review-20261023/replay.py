"""Bridge receipt/target audit, with no numerator integrations."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k] = '1'
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from unittest.mock import patch
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / 'data/q012-pilot'
OUT = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location('bridge', HERE / 'p11_bridge.py')
B = importlib.util.module_from_spec(s); s.loader.exec_module(B)
R = json.loads((HERE / 'p11_bridge_results.json').read_text())
assert set(R['points']) == set(B.POINTS)
assert R['tolerances'] == B.TOL
sources = {f: hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in R['sources']}
assert sources == R['sources']
arch = B.archived(); bank = B.F.load_bank()
out = dict(sources_match=True, coordinates=B.NAMES, points={}, declared_all_pass=R['all_pass'])
for name,r in R['points'].items():
    p = bank[name]; u = B.O.p_to_u(p)
    a = arch[name]
    vectors = {k: np.array(r[k]) for k in ('grad_full','grad_numerator_fisher','grad_logpi_fd','grad_prior_jac','B1_signed')}
    assert all(x.shape == (35,) and np.all(np.isfinite(x)) for x in vectors.values())
    pj = B.prior_jac_grad(u)
    assert np.array_equal(pj,vectors['grad_prior_jac'])
    prior_value_residual=r['prior_jac']-B.prior_jac(u)
    assert abs(prior_value_residual)<1e-12
    value_residual=r['value']-(r['log_numerator']-r['log_pi']+r['prior_jac'])
    assert abs(value_residual)<3e-13
    g = vectors['grad_numerator_fisher'] - vectors['grad_logpi_fd'] + pj
    assert np.array_equal(g, vectors['grad_full'])
    archived_g = np.sum([a['grad'][k] for k in a['per_tree']], axis=0) - np.array(a['log_pi_grad']) + pj
    assert np.array_equal(g-archived_g, vectors['B1_signed'])
    assert float(np.max(np.abs(g-archived_g))) == r['B1_max_abs']
    glp,_ = B.fd_logpi(u)
    assert np.max(np.abs(glp - vectors['grad_logpi_fd'])) < 1e-10
    # Direct separate normalizer components, not a second whole numerator.
    d,A = B.F.D,B.F.P.cohort_A(B.F.D,p)
    singles = [float(B.F.P.QD.log_pi_1d(p['sigma'], A[i-1], math.exp(p['log_b0'])*(d['c']-d['o'][i-1]),p['kappa_b'],np.array(d['gh_t']),np.array(d['gh_w']))) for i in [1,3,4,6]]
    pair = float(B.F.P.QD.log_pi_2d(p['sigma'],p['rho'],A[1], math.exp(p['log_b0'])*(d['c']-d['o'][1]),A[4],math.exp(p['log_b0'])*(d['c']-d['o'][4]),p['kappa_b'],np.array(d['gh_t']),np.array(d['gh_w'])))
    assert sum(singles) + pair == r['log_pi']
    d1=np.zeros(35);d1[B.IX['tau']]=1;d1[B.Z]=-u[B.Z];d1/=np.linalg.norm(d1)
    d2=np.zeros(35);d2[[B.IX['sigma'],B.IX['rho'],B.IX['kappa']]]=1;d2/=np.linalg.norm(d2)
    for k,dd in [('d1_tau_zrw_ridge',d1),('d2_sigma_rho_kappa',d2)]:
        q=r['B3'][k]
        assert (4*q['fd_5e4']-q['fd_1e3'])/3 == q['richardson']
        assert abs(float(g@dd)-q['predicted'])<1e-12
        assert abs(q['richardson']-q['predicted']) == q['abs_err']
    # A stable independent expression of the constrained-coordinate Jacobian.
    ij=B.IX
    stable_logjac=u[ij['tau']]+u[ij['sigma']]-np.logaddexp(0,-u[ij['rho']])-np.logaddexp(0,u[ij['rho']])
    original_logjac=math.log(p['tau'])+math.log(p['sigma'])+math.log(p['rho'])+math.log1p(-p['rho'])
    rr=u[ij['rho']];hh=1e-5
    stable_rho_jac=lambda x: -np.logaddexp(0,-x)-np.logaddexp(0,x)
    stable_rho_fd=(stable_rho_jac(rr+hh)-stable_rho_jac(rr-hh))/(2*hh)
    out['points'][name]=dict(B1_exact=True,value_assembly_residual=value_residual,prior_value_residual=prior_value_residual,B1_bad_coordinates={B.NAMES[j]:float(x) for j,x in enumerate(vectors['B1_signed']) if abs(x)>B.TOL['B1']},
        fresh_logpi_maxdiff=float(np.max(np.abs(glp-vectors['grad_logpi_fd']))),
        singleton_normalizers=singles,joint_normalizer=pair,normalizer_sum=sum(singles)+pair,
        stable_minus_direct_logjac=float(stable_logjac-original_logjac),
        stable_rho_jac_fd_minus_analytic=float(stable_rho_fd-pj[ij['rho']]),
        complete_gradient_seconds=r['seconds']['fisher']['primary']+r['seconds']['fd_logpi'])
with patch.object(B.F.P.QD,'log_pi_1d',return_value=2.0) as f1, patch.object(B.F.P.QD,'log_pi_2d',return_value=19.0) as f2:
    test=B.F.log_pi_p11(bank['central0'])
    assert (test,f1.call_count,f2.call_count)==(27.0,4,1)
out['normalizer_multiplicity_sentinel']=[test,f1.call_count,f2.call_count]
with patch.object(B.F,'trees_log',return_value={'one':100.0}), patch.object(B.F,'log_pi_p11',return_value=27.0):
    u=B.O.p_to_u(bank['central0']); assert B.full_value(u)==73.0+B.prior_jac(u)
out['denominator_minus_sign_sentinel']=True
(OUT/'replay.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

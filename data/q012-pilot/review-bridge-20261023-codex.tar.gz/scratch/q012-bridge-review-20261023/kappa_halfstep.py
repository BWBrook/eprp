"""Two new numerator values only; one CPU; target sole B1 failed coordinate."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k]='1'
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
import importlib.util
import json
import time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('bridge',ROOT/'data/q012-pilot/p11_bridge.py')
B=importlib.util.module_from_spec(s);s.loader.exec_module(B)
R=json.loads((ROOT/'data/q012-pilot/p11_bridge_results.json').read_text())
name='holdout_c4f_sigma15';p=B.F.load_bank()[name];u=B.O.p_to_u(p);r=R['points'][name]
j=B.IX['kappa'];fisher=r['grad_numerator_fisher'][j]
a=B.archived()[name];old=sum(a['grad'][k][j] for k in a['per_tree'])
h=5e-5;e=np.zeros(35);e[j]=h;t0=time.perf_counter()
plus=B.F.trees_log(B.O.u_to_p(u+e));minus=B.F.trees_log(B.O.u_to_p(u-e))
fd=(sum(plus.values())-sum(minus.values()))/(2*h)
rich=(4*fd-old)/3
out=dict(point=name,coordinate='kappa',plus=plus,minus=minus,h=h,old_fd_h1e4=old,new_fd=fd,fisher=fisher,
    old_fd_minus_fisher=old-fisher,new_fd_minus_fisher=fd-fisher,
    gap_ratio=(old-fisher)/(fd-fisher),richardson=rich,richardson_minus_fisher=rich-fisher,
    seconds=time.perf_counter()-t0,numpy=np.__version__,pinned_cpu=list(os.sched_getaffinity(0)))
Path(__file__).with_name('kappa_halfstep.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

from pathlib import Path
import json,hashlib,re
import numpy as np,pandas as pd
R=Path.cwd();O=R/'scratch/q012-ruling-20261020';W=R/'scratch/q012-pilot/q80_projection/warm';B=R/'scratch/q012-pilot/fetch-20261018-v6p2/runs/P11/attempt1';E=R/'data/q012-pilot/projection_v6q80'
def load(p):
 lines=p.read_text().splitlines();idx=next(i for i,l in enumerate(lines)if l.startswith('# Diagonal elements'));metric=np.array([float(v)for v in lines[idx+1][2:].split(',')]);step=float(next(l.split('=')[1]for l in lines if l.startswith('# Step size =')));return pd.read_csv(p,comment='#'),metric,step,lines
out={'hashes':{},'chains':[]};old_cost=[]
for line in (E/'warm_chain_files.sha256').read_text().splitlines():
 h,name=line.split(maxsplit=1);p=W/name.strip();out['hashes'][name.strip()]=hashlib.sha256(p.read_bytes()).hexdigest()==h
for k in range(1,5):
 a,ma,ha,la=load(B/f'chain{k}.csv');b,mb,hb,lb=load(W/f'chain{k}.csv');assert len(a)==8000 and len(b)==200 and len(ma)==len(mb)==54
 eff=hb/ha*np.sqrt(mb/ma);names=list(a.columns[7:7+54]);qidx=[28,26,33]
 t=lambda lines,label:float(next(re.search(r'([0-9.]+) seconds',l).group(1)for l in lines if f'seconds ({label})'in l))
 old_cost.append(t(la,'Sampling')/a.n_leapfrog__.sum());r={'chain':k,'old_step':ha,'new_step':hb,'step_ratio':hb/ha,'effective_coordinate_step_ratio_min_median_max':[float(x)for x in (eff.min(),np.median(eff),eff.max())],'kappa_logk_logsigma_effective_ratios':eff[qidx].tolist(),'new_accept':float(b.accept_stat__.mean()),'old_accept':float(a.accept_stat__.mean()),'new_leap':float(b.n_leapfrog__.mean()),'new_div':int(b.divergent__.sum()),'new_warmup_s':t(lb,'Warm-up'),'new_sample_s':t(lb,'Sampling'),'new_metric':mb.tolist(),'old_metric':ma.tolist(),'configuration': [l for l in lb if re.match(r'#\s*(delta|init_buffer|term_buffer|window|gamma|kappa|t0|num_warmup|num_samples|stepsize_jitter) =',l)]};out['chains'].append(r)
known=json.loads((R/'scratch/q012-p11-capture-review-20261019/mechanism-agent/results.json').read_text())
for ev in known['events']:
 r=out['chains'][ev['chain']-1];checks={}
 for state in ['previous','failing']:
  hess=np.array(ev['states'][state]['curvature_blocks'][-1]['potential_Hessian']);idx=[28,26,33];newm=np.array(r['new_metric'])[idx];mat=np.sqrt(newm[:,None])*hess*np.sqrt(newm[None,:]);newlam=np.linalg.eigvalsh((mat+mat.T)/2)[-1];checks[state]={'old_hsqrt_largest_block_eigenvalue':ev['states'][state]['curvature_blocks'][-1]['h_sqrt_largest_weighted_eigenvalue'],'new_hsqrt_largest_block_eigenvalue':r['new_step']*float(np.sqrt(max(0,newlam)))}
 r['same_Q64_Hessian_block_new_metric_proxy']=checks
cost=np.mean(old_cost);out['kunanyi_Q64_s_per_leap']=float(cost);out['projection_replay']={}
for ratio in [1.5,1.6]:
 out['projection_replay'][str(ratio)]=[]
 for r in out['chains']:
  lp=r['new_sample_s']/(200*r['new_leap']);warm=r['new_warmup_s']*cost*ratio/lp/3600;samp=6000*r['new_leap']*cost*ratio/3600;out['projection_replay'][str(ratio)].append({'chain':r['chain'],'warmup_h':warm,'sampling_h':samp,'total_h':warm+samp})
def windows(term):
 w=25;nxt=75+w-1;out=[];start=75
 for count in range(2000):
  if count==nxt and count!=2000:
   out.append({'last_transition':count+1,'first_transition':start+1,'length':count-start+1});start=count+1
   if nxt==2000-term-1:continue
   w*=2;nxt=count+w
   if nxt!=2000-term-1 and nxt+2*w>=2000-term:nxt=2000-term-1
 return out
out['metric_windows']={str(t):windows(t)for t in [50,500]}
(O/'adaptation_replay.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'hashes':out['hashes'],'chains':[{k:v for k,v in r.items()if k not in ['new_metric','old_metric']}for r in out['chains']],'projection':out['projection_replay']},indent=2))

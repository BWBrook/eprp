# Independent reference ruling, 20 October 2026

**Ruling:** the three v6q80 stress failures at sigma=0.001, log-h0 offset=10 are false failures induced by a truncated fixed-innovation reference. A prospective reference-selection repair is justified; do not change Q80 or the 1e-4 log / 1e-3 derivative gates. The existing failed preflight remains an authentic record of the old rule.

## Direct observations

Inspected `data/q012-prototype/quadrature.py`, `data/q012-prototype/prototype.py`, `data/q012-pilot/pilot.py`, `order_preflight_v6q80.json`, `order_reference_diagnosis_v6q80.json`, `order_local_reference_whatif_v6q80.json` and the captured-state source. Current `reference_convergence` tests resolution on a fixed [-12,12] standard-innovation square, not domain coverage. `gate_point` consequently chooses a numerically stable but truncated reference. Its local fallback already tests resolution and domain, but is bypassed at those three states.

Ran `audit.py` in this directory with the existing pinned pilot Python, `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1`. No model compilation, fitting, remote work or tracked-file changes. Numerical execution took 38.43 seconds. Peak array allocation is bounded by 32-row chunks. Full results are in `results.json`; output is in `stdout.txt`.

The independent reference directly integrates the Gaussian innovations. It calls neither AGH, its mode solver, QD's integrand/reference, nor the local reference. It shares the existing cohort-A preparation, the mathematically specified survival expression and the existing finite-difference stencil. The three disputed states plus an ordinary stress state and the captured chain-2 preceding state were tested on five derivative axes: sigma, kappa_b, rho, log_k, log_h0_1.

| State | Expanded-domain log normalizer | old box minus expanded | max Q80 derivative error |
| --- | ---: | ---: | ---: |
| sigma .001, h10, kb -1.5 | -36278.68316836872 | -.01972943278 | 7.28e-8 |
| sigma .001, h10, kb 0 | -36278.680750880936 | -.01973377790 | 3.64e-8 |
| sigma .001, h10, kb +1.5 | -36278.67836293453 | -.01973798776 | 3.64e-8 |
| sigma .001, h5, kb 0 | -245.57233914139383 | 2.84e-14 | 2.84e-10 |
| captured c2 previous, sigma 3.57109087 | -1.409273265410972 | 2.16e-12 | .000178781844 |

Expanded fixed references compare n800/n1600 on [-24,24], then n1600 on [-48,48]. Every comparison passes the pre-existing reference tolerances 1e-6 value and 1e-5 derivatives. At the three disputed states the largest expanded-reference derivative change is 7.28e-8; local versus independent fixed-reference discrepancy is at most 1.46e-11 in log value and 3.64e-8 in derivatives. The original small box biases derivative estimates by approximately 763 on these states despite resolution stability. The old box at n800 is deliberately included only to demonstrate truncation; the original archived n1600/n3200 evidence remains untouched.

At the captured previous state, the largest local versus independent-reference derivative discrepancy is 2.66e-10. Q80 retains the previously reported log error 4.35035343e-5 and maximum derivative error .000178781844; this is inside the unchanged gates. Agreement with higher Q is not used as truth.

## Repair recommendation and scientific limits

Simplest change: require BOTH fixed-reference resolution and domain convergence before using it; otherwise use the already available local reference only after BOTH its resolution and domain checks. A local-primary policy is also defensible, provided the fixed-reference cross-check is qualified by its own resolution AND domain convergence, and any unexplained disagreement is unresolved rather than silently passed. Changing the order of two valid references is less important than validating both truncation and discretization.

Use matched spacing when enlarging domains, e.g. fixed (n1600,L12), (n3200,L12), (n3200,L24). This separates domain enlargement from loss of grid resolution. Local (n800,L12), (n1600,L12), (n1600,L16) is already a valid pair of convergence comparisons; increasing n with L is preferable for a stricter audit. All value and finite-difference derivative evaluations must be subjected to the checks. A domain comparison at the unperturbed value alone is insufficient. Preserve per-reference outcomes and diagnostics; a failed or unresolved reference is not a quadrature pass. The reference tolerances remain tighter than the scientific accuracy gates.

The local integrand is strictly log-concave: its negative Hessian is the positive Gaussian precision plus nonnegative exponential survival curvature, including for negative kappa_b because its curvature contains kappa_b squared. Thus there are no rival local modes or hidden mixture components to cover. Newton centering is a coordinate transformation, not an assumption that the integrand is Gaussian: Simpson evaluates the full original integrand and Jacobian. Nevertheless local and AGH share mode/algebra; retain the independent raw-innovation check above, and require finite solver outputs and an explicitly converged mode (the current local loop silently proceeds after 200 steps). A valid raw-innovation domain test is useful independent protection against a shared transformation defect.

Optional stronger tail criterion: in raw innovations z, the log integrand f is 1-strongly concave. At any anchor a with gradient g, f(z) <= f(a)+||g||^2/2-||z-a-g||^2/2. Gaussian tail probabilities outside the integration box therefore provide an upper bound on omitted mass, divided by the computed integral for a relative bound. This is an alternative when simple domain enlargement remains ambiguous; it is not needed to settle the observed three-state defect. Resolution/domain agreement is empirical numerical evidence, not a global analytic error certificate.

Before a long attempt, Claude should rerun the repaired prospective rule on the full required bank: both 49-state fit banks, eight starts, two small-sigma controls, all 48 fixed stress states and both complete captured triads, preserving the extra log_k/log_h0_1 axes at triads. Preserve original failures and label new outputs as a prospective reference-rule amendment. The existing 64-state local what-if is useful supporting evidence; it is not a complete repaired-rule qualification for the two 49-state banks. Any state still unresolved holds the attempt. This audit does not authorize runtime changes or establish global Q80 accuracy, posterior support, mechanism or identifiability.

Completed: independent diagnosis and five-state/five-axis numerical audit. Next: parent integrates the ruling; Claude owns the prospective code and full-bank replay.

2026-10-20, Australia/Hobart (AEDT).

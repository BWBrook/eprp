"""Bounded independent fixed-innovation domain audit; no AGH or mode solver in reference.
Run with OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 existing pilot Python, from repo root.
"""
import importlib.util, json, math, pathlib, time
import numpy as np
from scipy.special import logsumexp

ROOT = pathlib.Path.cwd()
OUT = ROOT / 'scratch/q012-ruling-20261020/reference-agent'
spec = importlib.util.spec_from_file_location('pilot', ROOT/'data/q012-pilot/pilot.py')
M = importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
P = M.P
d = json.loads((ROOT/'data/q012-pilot/payload_v6q80/data/P11.json').read_text())
stress = json.loads((ROOT/'scratch/q012-capture-review-codex/inputs/fixed_48_stress_states.json').read_text())['states']

def fixed(q,n,L):
    """Direct quadrature of independent standard Gaussian innovations, 32-row chunks.
    Separate implementation of integrand, normal densities, weights; no use of QD.
    """
    e = np.linspace(-L,L,n+1)
    w = np.ones(n+1); w[1:-1:2]=4; w[2:-1:2]=2
    lw = np.log(w*(2*L)/(3*n))
    sig=q['sigma']; kb=q['kappa_b']; rho=q['rho']; A=P.cohort_A(d,q)
    B=np.exp(q['log_b0'])*(d['c']-np.asarray(d['o']))
    def surv(x,i):
        return -A[i]*np.exp(x-sig*sig/2)-B[i]*np.exp(kb*(x-sig*sig/2))
    val=0.
    for i in d['c1_lin']:
        val+=logsumexp(lw+surv(sig*e,i-1)-e*e/2-math.log(2*math.pi)/2)
    for i,j in zip(d['c2_par'],d['c2_dau']):
        chunks=[]
        for start in range(0,n+1,32):
            x=e[start:start+32,None]; y=e[None,:]
            f=surv(sig*x,i-1)+surv(sig*(rho*x+math.sqrt(1-rho*rho)*y),j-1)
            chunks.append(logsumexp(lw[start:start+32,None]+lw[None,:]+f-(x*x+y*y)/2-math.log(2*math.pi)))
        val+=logsumexp(chunks)
    return float(val)

points={nm:M.w_to_eps(stress[nm]) for nm in ('grid-s0.001-h10.0-kb-1.5','grid-s0.001-h10.0-kb0.0','grid-s0.001-h10.0-kb1.5','grid-s0.001-h5.0-kb0.0')}
ev=next(e for e in M.read_trace(ROOT/'scratch/q012-pilot/fetch-20261019-v6d/runs/P11/attempt1/chain2.trace.jsonl') if e.get('type')=='divergence' and e['phase']=='sampling')
points['capture_c2_previous']=M.constrain(ev['previous']['q'],d['N'])
out={'kind':'independent raw-innovation Simpson audit; fixed domain; no mode solver or AGH in reference', 'states':{},'C1':d['C1'],'C2':d['C2']}
t0=time.monotonic()
for nm,q in points.items():
    row={'sigma':q['sigma'],'rho':q['rho'],'kappa_b':q['kappa_b'],'refs':{}}
    extra=('log_k','log_h0_1')
    # n/L ratios keep domain doubling from reducing resolution.
    settings=[(400,12),(800,12),(800,24),(1600,24),(1600,48)]
    for n,L in settings:
        v=M._values(d,q,lambda qq:fixed(qq,n,L),extra)
        row['refs'][f'n{n}_L{L}']=v
    row['local_n800_L12']=M._values(d,q,lambda qq:M.local_reference(d,qq,800,12),extra)
    row['local_n1600_L16']=M._values(d,q,lambda qq:M.local_reference(d,qq,1600,16),extra)
    row['agh80']=M._values(d,q,lambda qq:P.log_norm_agh(d,qq,P.cohort_A(d,qq)),extra)
    best=row['refs']['n1600_L48']
    row['expanded_resolution']=M._converged(row['refs']['n800_L24'],row['refs']['n1600_L24'])
    row['expanded_domain']=M._converged(row['refs']['n1600_L24'],best)
    row['local_resolution_and_domain']=M._converged(row['local_n800_L12'],row['local_n1600_L16'])
    row['local_minus_fixed']={k:row['local_n1600_L16'][k]-best[k] for k in best}
    row['agh80_minus_fixed']={k:row['agh80'][k]-best[k] for k in best}
    out['states'][nm]=row
    out['elapsed_seconds']=time.monotonic()-t0
    (OUT/'results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(nm,json.dumps({k:row[k] for k in ('expanded_resolution','expanded_domain','local_resolution_and_domain','local_minus_fixed','agh80_minus_fixed')}),flush=True)

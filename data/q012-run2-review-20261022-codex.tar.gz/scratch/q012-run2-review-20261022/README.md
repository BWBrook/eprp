# Q-012 run-2 adjudication receipts

Sources are pinned to commit 89308904c1acffc63253e3b48a034d4a2c71b6da.
`source_manifest.json` records original paths and hashes. `audit.md` is the
independent delta audit; the parent decision is in the dated repository note.
The parent selected `holdout_9707_sigma8` as the narrow-kernel control for the
next batch (the audit initially proposed `high_rho_9707`). No new batch has run.

Run `python3 recount.py` within this extracted folder, or pass its absolute
path from any working directory. It uses only Python's standard library,
checks source hashes, all 45 row decisions and all 30 post-hoc selection
qualification flags, and writes `recount_results.json`. Replay into a temporary
copy to preserve the original receipt. `replay_receipt.json` records a standalone
replay with byte-identical output. No scientific integration is run.

The analytic Gaussian-envelope proposal is in the parent review and audit.
It is an available domain diagnostic, not a certification of numerical
quadrature or a required new research method. The selection transfer to T3
uses the unit-daughter identity and stored evaluator differences; it is not a
new T3 integration. Cross-host equality remains reported by Claude because
only one host result is archived here.

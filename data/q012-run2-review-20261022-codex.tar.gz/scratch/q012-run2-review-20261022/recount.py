"""Metadata/arithmetic-only review of pinned run-2 output; no oracle import."""
from collections import Counter
from pathlib import Path
import hashlib,json,math
OUT=Path(__file__).resolve().parent
for receipt in json.loads((OUT/'source_manifest.json').read_text()):
    assert hashlib.sha256((OUT/receipt['local']).read_bytes()).hexdigest()==receipt['sha256']
r=json.loads((OUT/'collapsed_oracle_results_run2.json').read_text())
p=json.loads((OUT/'oracle_posthoc/selection_vs_qualified_reference.json').read_text())
t=r['tolerances'];rows=r['rows'];assert len(rows)==45
assert len({(x['point'],x['forest']) for x in rows})==45
by={(x['point'],x['forest']):x for x in rows}
recounts=[]
for x in rows:
 c=x['checks']
 ev=all(c[k]['value']<=t['self_value'] and c[k]['deriv']<=t['self_deriv'] for k in ['eval_self_resolution','eval_self_domain'])
 ref=all(c[k]['value']<=t['self_value'] and c[k]['deriv']<=t['self_deriv'] for k in ['ref_resolution','ref_domain'])
 acc=c['eval_vs_ref']['value']<=t['value'] and c['eval_vs_ref']['deriv']<=t['deriv']
 ids=x['I1_unit_log_numerator']<=t['unit'] and abs(x['I2_selection_minus_ref'])<=t['selection']
 status='pass' if ref and ev and acc and ids else ('unresolved (reference not qualified)' if not ref and ev and ids else 'fail')
 for field,v in [('status',status),('reference_qualified',ref),('evaluator_converged',ev),('accuracy_pass',acc),('identities_pass',ids)]:
  assert x[field]==v,(x['point'],x['forest'],field)
 causes=[]
 for k in ['ref_resolution','ref_domain']:
  for j,tol in [('value',t['self_value']),('deriv',t['self_deriv'])]:
   if c[k][j]>tol:causes.append(k+'.'+j)
 if not ids:causes.append('I2_selection')
 if not acc:causes.append('accuracy_vs_unqualified_reference')
 recounts.append(dict(point=x['point'],forest=x['forest'],status=status,causes=causes,
                      reference_domain=c['ref_domain'],I2_selection=x['I2_selection_minus_ref']))
gk=[]
for x in rows:
 if 'quad_reference_minus_ref' in x:
  delta=x['quad_reference_minus_ref']-(x['log_numerator_eval']-x['log_numerator_ref'])
  gk.append(dict(point=x['point'],forest=x['forest'],quad_minus_eval_reconstructed=delta,
                 recorded_quad_minus_ref=x['quad_reference_minus_ref']))
selection=[]
assert set(p)==set(r['points'])
for name,post in p.items():
 assert set(post)=={'T1_root','T2_pair'}
 for check in post.values():
  assert check['qualified']==(abs(check['ref_res'])<=1e-6 and abs(check['ref_dom'])<=1e-6)
  assert check['qualified']
for name,post in p.items():
 x2=by[name,'T2_pair'];x3=by[name,'T3_root_two_daughters']
 assert x2['log_pi_q80']==x3['log_pi_q80']
 ev3_minus_ev2=x3['I2_selection_minus_q80']-x2['I2_selection_minus_q80']
 s2=post['T2_pair'];qual=abs(s2['ref_res'])<=1e-6 and abs(s2['ref_dom'])<=1e-6
 assert qual==s2['qualified']
 selection.append(dict(point=name,T2_reference_qualified=qual,eval_T3_minus_T2=ev3_minus_ev2,
                       reconstructed_T3_minus_qualified_pair_reference=ev3_minus_ev2+s2['eval_minus_qualified_ref'],
                       T2_minus_qualified_pair_reference=s2['eval_minus_qualified_ref']))
def leaves(obj,prefix=''):
 if isinstance(obj,dict):
  for k,v in obj.items():yield from leaves(v,prefix+'/'+k)
 elif isinstance(obj,list):
  for k,v in enumerate(obj):yield from leaves(v,prefix+'/'+str(k))
 elif isinstance(obj,(int,float)) and not isinstance(obj,bool):yield prefix,obj
def scalar_leaves(obj,prefix=''):
 if isinstance(obj,dict):
  for k,v in obj.items():yield from scalar_leaves(v,prefix+'/'+k)
 elif isinstance(obj,list):
  for k,v in enumerate(obj):yield from scalar_leaves(v,prefix+'/'+str(k))
 else:yield prefix,obj
allnum=list(leaves(r))
scientific=[(k,v) for k,v in allnum if '/seconds/' not in k and not k.endswith('/maxrss_kb') and k!='/wall_seconds']
result=dict(commit='89308904c1acffc63253e3b48a034d4a2c71b6da',counts=dict(Counter(x['status'] for x in recounts)),
            decomposition_pass=all(v<=t['decomposition'] for v in r['decomposition_abs_err'].values()),
            all45_rows=recounts,problem_points=sorted({x['point'] for x in recounts if x['status']!='pass'}),
            max_eval_self={j:max(x['checks'][k][j] for x in rows for k in ['eval_self_resolution','eval_self_domain']) for j in ['value','deriv']},
            gk_reconstructed=gk,max_abs_gk_minus_eval=max(abs(x['quad_minus_eval_reconstructed']) for x in gk),
            selection_transfer=selection,max_abs_T3_selection_transfer=max(abs(x['reconstructed_T3_minus_qualified_pair_reference']) for x in selection),
            numeric_leaf_counts=dict(total=len(allnum),excluding_timing_memory=len(scientific)),
            scalar_leaf_count_excluding_timing_memory=sum('/seconds/' not in k and not k.endswith('/maxrss_kb') and k!='/wall_seconds' for k,v in scalar_leaves(r)),
            failed_accuracy_count=sum(not x['accuracy_pass'] for x in rows),
            timing_ranges={f:{k:[min(x['seconds']['evaluator'][k] for x in rows if x['forest']==f),max(x['seconds']['evaluator'][k] for x in rows if x['forest']==f)] for k in ['primary_seconds','resolution_seconds','domain_seconds']} for f in sorted({x['forest'] for x in rows})})
(OUT/'recount_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['all45_rows','gk_reconstructed','selection_transfer']},indent=2))
for x in selection:
 if x['point'] in ['stress_s3_r09_kbm15','c4_previous']:print('I2 transfer',x)

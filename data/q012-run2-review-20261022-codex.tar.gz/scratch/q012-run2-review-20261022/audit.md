# Q-012 run-2 delta audit

Codex, 22 October 2026. Sources pinned to
`89308904c1acffc63253e3b48a034d4a2c71b6da`; exact paths and SHA-256 values
are in `source_manifest.json`. This audit reads only the new run-2 report,
JSON/log and selection post-hoc files, with the pool-only `a9419ee` delta.
`recount.py` performs JSON/arithmetic checks; no oracle import, fit, full replay
or remote process. All 45 derived decisions and causes are retained in
`recount_results.json`.

**Recommendation to parent:** permit a finite reference-only repair, not
acceptance of the evaluator as fully validated or promotion to P11. The new
evidence closes the four selection-identity discrepancies post hoc, including
T3, but leaves full-factor reference qualification at twelve rows unresolved.

## Frozen result and exact repair scope

Every stored status and boolean reproduces: **33 pass, 4 fail, 8 unresolved**;
decomposition passes. Evaluator self-resolution/domain maxima are 3.553e-15
in values and 1.421e-10 in derivatives. Every one of the twelve nonpassing
rows fails the reference's domain qualification. Five additionally exceed
the evaluator/reference derivative-accuracy gate, against those unqualified
references; these do not establish evaluator error or evaluator accuracy.

The exact six points, each in **T2 and T3**, are:

| Point | Frozen result per forest | Reference domain failure |
|---|---|---|
| `stress_s3_r09_kbm15` | fail: I2 | value and derivative |
| `c4_previous` | fail: I2 | derivative |
| `c1_failing` | unresolved | value and derivative |
| `holdout_c1f_sigma6` | unresolved | derivative |
| `holdout_c1f_sigma20` | unresolved | value and derivative |
| `holdout_c4f_sigma15` | unresolved | value and derivative |

All reference resolution checks pass. Maximum reference domain changes are
4.767e-5 in value and 9.814e-3 in derivatives. All T1 rows and both narrow
high-rho hold-outs (sigma 5 and 8) pass. Thus “six points with sigma >=3”
must denote the named set above, not every tested point with sigma >=3.

“Every remaining row has a reference-side qualification failure” is supported.
“The repairs fixed the evaluator” should be limited to its disclosed
self-convergence failures and the checked independent comparisons. Accuracy
in the remaining full-factor cases is still undecided. Applying the post-hoc
I2 corrections would yield **33 pass and 12 reference-unresolved**, not 45
passes; retain the original frozen labels unchanged as the historical record.

## What the new corroboration establishes

**Selection, including T3:** all 30 T1/T2 post-hoc reference qualification
flags reproduce from the recorded value-resolution/domain changes. T3's
selection integral equals the T2 pair integral analytically: daughter 7 has
unit factor and its conditional Gaussian integrates to one. The actual T3
selection evaluator can also be checked without rerunning it. T2 and T3
record the same Q80 normaliser, so subtracting their
`I2_selection_minus_q80` gives their evaluator difference. Adding the
post-hoc qualified T2 residual gives T3 minus the qualified pair reference.
At the two failed points this is −8.88e-16 (stress) and −1.42e-14
(c4_previous); across all fifteen points it is at most 2.559e-8.
Consequently the four I2 failures are corroborated as errors of the original
selection tensor reference. This conclusion uses the analytic unit-daughter
identity and the actual stored T3 evaluation, not an unperformed T3 post-hoc
run. I2 has a value gate; no derivative qualification is claimed for this check.

**Adaptive values:** the JSON stores `quad_reference_minus_ref`, not a direct
Gauss–Kronrod/evaluator subtraction. Reconstructing
`(quad−ref)−(eval−ref)` over all 30 T1/T2 rows gives a maximum **2.132e-14**
at `holdout_c1f_sigma20`, T1. The reported 1.4e-14 bound needs this small
correction; the numerical conclusion is unchanged. This is strong value
agreement, subject to the existing unresolved adaptive-domain/error evidence.
It does not supply derivative evidence, nor any T3 adaptive reference.

**Cross-host replication:** the archived JSON and log document the laptop
wall time 10,819.89 s. No second-host output, comparison receipt or host-bound
source/environment receipt is included in the permitted new delta. There
are exactly **1,639 scalar leaves after excluding timings and RSS**, consistent
with the reported comparison count (these include strings and booleans).
The claimed bitwise comparison and 4,239 s deep-server time remain Claude's
reported observations, not independently verified by this audit. Archive the
second output and the comparison/filter rule to close that evidence gap.
The pool change alters scheduling only, not individual task mathematics;
that supports the plausibility of replication, not a substitute for its receipt.

## Bounded reference repair

Keep the candidate evaluator, factors, forests, points and gates fixed. Repair
only the missing reference: T2 derivatives and T3 values/derivatives at the
six named points, with central0 and high_rho_9707 as shared controls. Retain
adaptive errors/warnings and qualify the domain for every plus/minus
finite-difference evaluation. An adaptive rule inside an unqualified finite
box is insufficient. Use independent integration code, not the evaluator's
level-set/sinh routines. The tiny star topology allows two independent leaf
integrals at each root abscissa, avoiding a wasteful unconstrained triple nest;
shared analytic factorisation must remain disclosed.

The parent's proposed Gaussian-envelope bound is mathematically valid.
In innovation coordinates, `h(e)=−||e||²/2−d log(2π)/2+sum logF_i((Ae)_i)`
has `−Hessian(h)>=I` because all exposure coefficients are nonnegative and
each local log factor is concave. For any finite anchor a and g=grad h(a),

`h(e) <= h(a)+||g||²/2−||e−(a+g)||²/2`.

Writing `C=exp(h(a)+||g||²/2)*(2π)^(d/2)`, the omitted integral outside
`a+g ±R` is at most `C*d*erfc(R/sqrt(2))`. This applies to both full and
selection factors for the tested interior sigma/rho states, without requiring
an exact mode. A poor anchor makes the bound loose, rather than invalid.
Evaluate in log space and allow numerical slack in h/g if claiming a strict
certificate. Dividing by a genuine interior lower bound certifies relative
tail error; dividing by an integral minus a QUADPACK error *estimate* gives
numerical qualification, rather than a rigorous mathematical lower bound.

With difference step 1e-4, per-logvalue uncertainty <=1e-11 contributes at
most 1e-7 to a central-difference derivative, below the 1e-5 reference gate.
Still check integration refinement and finite-difference stability. Six
points × two forests × 71 evaluations requires **852 reference calls per
accuracy configuration**, before controls or refinements; adding the two
controls gives 1,136. The existing rows retain only maximum derivative
discrepancies and the single worst-coordinate evaluator/reference pair,
**not the full 35-coordinate gradient vectors**. Thus “reference-only repair”
means an unchanged evaluator algorithm, not zero candidate computation:
comparison against the repaired reference needs 70 candidate perturbation
calls per row (840 for twelve rows), or 852 including repeated base values,
before controls. Save both complete gradient vectors and every plus/minus
value, numerical-error and domain-qualification receipt in the next output.
The output contains no adaptive-reference timings, so
a defensible wall-time forecast is unavailable. Time a bounded worst-case
T2/T3 evaluation and perturbation before releasing the finite batch. Do not
repeat the full 45-row oracle, and stop this reference repair at its declared
result rather than adding another sampling or grid-search ladder.

**Next owner: parent Codex** for the decision and Claude handoff. No tracked
file, board, scientific target, raw result or prior review receipt was changed.

"""Exact small calculations; no simulation, external dependencies or fitted inputs."""
import json
from math import exp, expm1, log, log1p, sqrt


def p_zero(n, survival):
    return exp(n * log1p(-survival)) if survival < 1 else 0.0


def death_quantile(n, mu, p):
    return -log(-expm1(log(p) / n)) / mu


def pgf(z, b, d, t):
    """One ancestor, continuous-time linear birth-death PGF, stable forms."""
    if b == 0:
        return 1 + exp(-d*t)*(z-1)
    if b == d:
        return 1 - (1-z)/(1+b*t*(1-z))
    if b > d:
        e = exp(-(b-d)*t)
        return (d*(1-z)-e*(d-b*z))/(b*(1-z)-e*(d-b*z))
    e = exp((b-d)*t)
    return (d-b*z-e*d*(1-z))/(d-b*z-e*b*(1-z))


def bd_world(b, d, horizon, n=100000, duration=5):
    z = pgf(0, 1, .2, horizon-duration)
    return pgf(z,b,d,duration)**n


def stage_step(qj, qa, sa, sj, f):
    # Larvae are produced at the beginning of the interval, independently
    # of the parent's subsequent survival; Poisson(f) settle at its end.
    # Existing juveniles and adults face the postlarval hazard this interval;
    # new settlers face it in their following juvenile-to-adult interval.
    return 1-sj+sj*qa, (1-sa+sa*qa)*exp(f*(qj-1))


def stage_world(f, mu, horizon, n=100000, duration=5):
    qj = qa = 0.
    for _ in range(horizon-duration):
        qj,qa = stage_step(qj,qa,exp(-.2),exp(-.2),1)
    for _ in range(duration):
        qj,qa = stage_step(qj,qa,exp(-mu),exp(-mu),f)
    return qa**n


def wilson(k,n):
    z=1.959963984540054
    p=k/n; den=1+z*z/n
    mid=(p+z*z/(2*n))/den
    half=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return mid-half, mid+half

out={"death_only":[],"birth_death_worlds":{},"two_stage_worlds":{}}
for n,mu in [(100000,1),(100000000000,.2)]:
    out['death_only'].append(dict(n=n,mu=mu,Dstar=log(n)/mu,
      quantiles={str(p):death_quantile(n,mu,p) for p in [.025,.5,.975]},
      expected_5=n*exp(-mu*5),p_zero_5=p_zero(n,exp(-mu*5))))
for horizon in [5,100,1000]:
    out['birth_death_worlds'][horizon]={name:bd_world(b,d,horizon) for name,b,d in
       [('11',0,3),('01',1,3),('10',0,.2),('00',1,.2),('base',1,.2)]}
    out['two_stage_worlds'][horizon]={name:stage_world(f,mu,horizon) for name,f,mu in
       [('11',0,3),('01',1,3),('10',0,.2),('00',1,.2),('base',1,.2)]}
a=17/28;b=14/23;l1,u1=wilson(17,28);l2,u2=wilson(14,23)
out['table']=dict(difference=a-b,newcombe95=[a-b-sqrt((a-l1)**2+(u2-b)**2),a-b+sqrt((u1-a)**2+(b-l2)**2)])
# Truth table: both stresses required for extinction, neither alone sufficient.
out['logical_factorial']=dict(Y11=1,Y01=0,Y10=0,Y00=0,base=0,RL=1,RP=1,I=1)
assert abs(out['two_stage_worlds'][5]['11']-out['birth_death_worlds'][5]['11'])<1e-10
assert out['two_stage_worlds'][100]['01'] < .1 < out['two_stage_worlds'][100]['11']
print(json.dumps(out,indent=2,sort_keys=True))

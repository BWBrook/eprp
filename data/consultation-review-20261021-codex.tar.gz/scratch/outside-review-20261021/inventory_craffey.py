"""Inspect the unchanged publisher archive; do not execute source code."""
import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import zipfile

p=Path.cwd()/'scratch/outside-review-20261021'
raw=(p/'craffey_figshare_50814311.zip').read_bytes()
assert hashlib.md5(raw).hexdigest()=='81ca58c1a6aad3e6d047a1db374a81b6'
assert hashlib.sha256(raw).hexdigest()=='a436577b0ea196c4bf110e9b938b1f78030e0e1f934ec73a010ef7f65b0c43ff'
z=zipfile.ZipFile(io.BytesIO(raw))
names=[n for n in z.namelist() if not n.endswith('/') and not n.startswith('__MACOSX/')]
rows=list(csv.DictReader(io.StringIO(z.read('Data and Code/Data/Craffey et al 2024 Occurrence Data.csv').decode('latin-1'))))
rec={'files':len(names),'rows':len(rows),'columns':list(rows[0]),
     'decoding':'latin-1 byte-preserving read for ASCII field inventory; no raw changes','fields':{}}
for k in ('T.bin','zone','reference','localbed','collection_no'):
    v=collections.Counter(r.get(k,'COLUMN ABSENT') for r in rows)
    rec['fields'][k]={'distinct':len(v),'most_common':v.most_common(6)}
rec['entirely_blank_data_row_indices_1based']=[i for i,r in enumerate(rows,1) if all(v in ('',None) for v in r.values())]
rec['missing_only_data_row_indices_1based']=[i for i,r in enumerate(rows,1) if all(v in ('',None,'NA') for v in r.values())]
rec['nonblank_rows']=len(rows)-len(rec['entirely_blank_data_row_indices_1based'])
(p/'craffey_summary.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({'rows':len(rows),'missing_only_rows':rec['missing_only_data_row_indices_1based'],
                  'bioturbation':rec['fields']['T.bin'],'empty_bed_labels':sum(r['localbed']=='' for r in rows)}))

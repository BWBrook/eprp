import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

import numpy as np

root = Path.cwd()
out = root / 'scratch/outside-review-20261021'
path = root / 'data/q012-pilot/pilot.py'
spec = importlib.util.spec_from_file_location('pilot_check', path)
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
near = np.linalg.inv(1.0808045**2*np.array([[1,.99998221],[.99998221,1]]))
cases = {
    'valid_single': ([.5],[.2],np.array([[1/.81]]),.4,1.13),
    'valid_pair': ([.3,.4],[.1,.2],near,.5*1.0808045**2,1.13),
    'infinite_a': ([float('inf')],[.2],np.array([[1.]]),.4,1.13),
    'nan_b': ([.5],[float('nan')],np.array([[1.]]),.4,1.13),
    'overflow': ([.3,1e300],[.1,.2],near,-800.,1.13),
    'negative_decrement': ([.001],[0.],np.array([[-4.]]),.4,1.13),
    'singular': ([0.],[0.],np.array([[0.]]),.4,1.13),
    'stationary_invalid_curvature': ([0.],[0.],np.array([[-1.]]),.4,1.13),
}
result = {}
for name, args in cases.items():
    with np.errstate(all='ignore'):
        try:
            y, T = p._local_mode(*args)
            assert np.all(np.isfinite(y)) and np.all(np.isfinite(T))
            result[name] = 'accepted'
        except p.ReferenceUnresolved as e:
            result[name] = str(e)
assert all((v == 'accepted') == k.startswith('valid') for k,v in result.items())

# Re-evaluate the submitted R export with only its output directory redirected.
script = (root/'data/q038-predictor-contract/ambiguity.R').read_text()
redirected = script.replace('out <- "data/q038-predictor-contract"', 'out <- "scratch/outside-review-20261021"')
assert redirected != script
rscript = out/'ambiguity_replay.R'
rscript.write_text(redirected)
r = subprocess.run(['Rscript','--vanilla',str(rscript)],cwd=root,capture_output=True,text=True,check=True)
(out/'ambiguity_replay.log').write_text(r.stdout+r.stderr)
hashes = {}
for name in ('ambiguity.tsv','ambiguity_summary.tsv','name_homonyms.tsv'):
    actual=(out/name).read_bytes()
    expected=(root/'data/q038-predictor-contract'/name).read_bytes()
    assert actual == expected, name
    hashes[name]=hashlib.sha256(actual).hexdigest()

# No submitted cluster target/payload changed in the guard commit.
changed=subprocess.check_output(['git','diff','--name-only','3d432f0','0fefad2'],cwd=root,text=True).splitlines()
assert set(changed)=={'STATUS.md','ideas/2026-10-21-q012-decrement-and-amendment-closure-codex.md',
 'data/q012-pilot/review-decrement-20261021-codex.tar.gz','data/q012-pilot/README.md',
 'data/q012-pilot/pilot.py','data/q012-pilot/selftest.json'}
record={'mode_cases':result,'ambiguity_byte_replay':hashes,'guard_payload_unchanged':True,
        'selftest_record_all_pass':json.loads((root/'data/q012-pilot/selftest.json').read_text())['all_pass']}
(out/'operational_checks.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))

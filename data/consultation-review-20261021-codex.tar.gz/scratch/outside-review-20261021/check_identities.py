"""Independent exact identities for the bounded recruitment calculation."""
import contextlib
import importlib.util
import io
import json
import math
from pathlib import Path

root = Path.cwd()
spec=importlib.util.spec_from_file_location('recruitment_check',root/'scratch/recruitment-check-20261021/check.py')
m=importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(m)
errors=[]
for b,d in [(0,.2),(1,3),(1,.2),(1,1)]:
    for z in [0,.2,.8,1]:
        errors.append(abs(m.pgf(z,b,d,0)-z))
        errors.append(abs(m.pgf(1,b,d,2)-1))
        errors.append(abs(m.pgf(m.pgf(z,b,d,3),b,d,2)-m.pgf(z,b,d,5)))
for n,mu in [(10,1),(100000,1),(100000000000,.2)]:
    for p in [.025,.5,.975]:
        D=m.death_quantile(n,mu,p)
        errors.append(abs(math.exp(n*math.log1p(-math.exp(-mu*D)))-p))
for s in [.1,.5,.9]:
    errors.append(abs(m.stage_step(1,1,s,s,2)[0]-1))
    errors.append(abs(m.stage_step(1,1,s,s,2)[1]-1))
assert max(errors)<1e-12, max(errors)
actual=json.loads((root/'scratch/recruitment-check-20261021/results.json').read_text())
assert m.out==actual or json.loads(json.dumps(m.out))==actual
result={'identities':len(errors),'maximum_absolute_error':max(errors),'archived_results_match':True}
(root/'scratch/outside-review-20261021/recruitment_identity_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

# Joint consultation review evidence — 21 October 2026

This archive accompanies ideas/2026-10-21-outside-consultations-response-codex.md
and the two same-date recruitment/chronology notes. Paths are relative to the
EPRP repository root. Inputs are identified in input_manifest.json. Baseline
checkout is d702b99; original inputs and consultant documents remain unchanged.

Extract from the repository root with:

    tar -xzf data/consultation-review-20261021-codex.tar.gz

The contents are scratch paths only. Verify with:

    sha256sum -c scratch/outside-review-20261021/SHA256SUMS
    python3 scratch/recruitment-check-20261021/check.py
    python3 scratch/outside-review-20261021/check_identities.py
    python3 scratch/outside-review-20261021/inventory_craffey.py

These calculations use standard-library Python. The operational replay needs
R and the Python environment pinned in the PEP 723 header of
 data/q012-pilot/pilot.py. Run from the repository root:

    python scratch/outside-review-20261021/operational_check.py

It imports current pilot/prototype helpers, checks two valid and six invalid
modes, and runs the ambiguity exporter with its output directory redirected
to scratch. It does not run a fit or full selftest. It also checks the guard
commit's changed-path set against the declared baseline history. Use the review
commit's input files (hashes in input_manifest.json), not later unreviewed code.

## Source data and scope

Craffey et al. (2024), Data and Code ZIP file from Co-occurrence structure of
late Ediacaran communities and influence of emerging ecosystem engineers,
https://doi.org/10.6084/m9.figshare.27909116.v1, CC BY 4.0
(https://creativecommons.org/licenses/by/4.0/). The unmodified publisher ZIP
and its API licence metadata are retained here with attribution. Download:
https://ndownloader.figshare.com/files/50814311 . MD5 matches the publisher.
The Dryad metadata list a different-sized ZIP; those download attempts returned
401/403. Equivalence of their contents was not established.

The occurrence inventory uses a byte-preserving Latin-1 decoding for ASCII
fields, after UTF-8 failed. All 1,541 parsed rows are retained, including a final
record containing only NA trait placeholders. No biological absence coding,
record-level support, original analysis or semantic name normalization is
validated by this inventory. The raw ZIP remains unchanged.

Chronology PDFs/HTML stay in local scratch and are not included. Source IDs,
hashes, public metadata and the small workbook-target inspection record are
retained. Download the original files through the linked Figshare metadata
for deeper reproduction. No CONOP or age model was executed.

Exact mathematical results are logical counterexamples, not empirically
supported K-Pg parameter sets. Zeros in tiny probabilities can be floating-point
underflow. No novelty probability or workflow efficiency estimate is validated.

# 20 October 2026 review evidence

The governing parent review is ideas/2026-10-20-q038-and-prior-checks-review-codex.md.
Independent scratch memos precede that integration and do not override it.

Q038 input source: Dryad 10.5061/dryad.931zcrjqw; local input hashes are in
input-sha256.json and the earlier data/q038-monarrez-contract/README.md.
Q031 inputs: existing local S1.R and S1.RData from Zenodo
10.5281/zenodo.15096088, as reported in Claude's 20 October Q023/Q031 note.
No raw source files or full-text papers are included in this archive.
Replays require those inputs at the recorded paths. This archive pins the
locally inspected bytes; it is not a fresh source-retrieval audit.

Extract into an isolated copy of checkout 756bd2f with the inputs available.
Archive scratch paths preserve the scripts' original relative output paths.
From the repository root:

    Rscript --vanilla scratch/q038-review-20261020/replay.R
    python3 scratch/q038-review-20261020/audit.py
    Rscript --vanilla scratch/four-prior-review-20261020/count-q031.R
    python3 scratch/four-prior-review-20261020/counterexample.py

Q038 replay.R is the reviewed support.R with only its output directory changed.
Each of its six TSVs was compared byte-for-byte with the tracked support TSV.
replay-comparison.json reports the six comparisons; audit.json is the separate
Python audit. The parent rechecked bytes when packaging. Q031 loads data into
an isolated R environment and only counts rows; it never sources S1.R or fits
models. Q017 counterexample.py uses exact rational arithmetic and prints the
Poisson-thinning interpretation. All checks read raw sources unchanged.
The internal manifest hashes every member except itself. Internal hashes
verify archive integrity, not scientific validity.

"""Exact mean-cell and Poisson-thinning counterexample; no simulation/fit."""
import json
from fractions import Fraction as F

cells = {}
for a in (0, 1):
    for b in (0, 1):
        cells[f"{a}{b}"] = sum(
            500 * p**a * (1-p)**(1-a) * p**b * (1-p)**(1-b)
            for p in (F(1, 5), F(4, 5))
        )
N = (cells['11'] + cells['10']) * (cells['11'] + cells['01']) / cells['11']
p = cells['11'] / (cells['11'] + cells['10'])
homogeneous = {f"{a}{b}": N*p**a*(1-p)**(1-a)*p**b*(1-p)**(1-b)
               for a in (0, 1) for b in (0, 1)}
assert all(cells[k] == homogeneous[k] for k in ('11', '10', '01'))
assert cells['00'] == 340 and homogeneous['00'] == F(1280, 17)
print(json.dumps({"heterogeneous_mean_cells": {k: str(v) for k,v in cells.items()},
                  "homogeneous_population_mean": str(N),
                  "homogeneous_detection": str(p),
                  "homogeneous_mean_cells": {k: str(v) for k,v in homogeneous.items()},
                  "interpretation": "Fixed class sizes give matching observed means; independent Poisson class sizes (mean 500 each) and a homogeneous Poisson population (mean 12500/17) give exactly the same observed three independent Poisson cell laws, with different unseen means."}, indent=2))

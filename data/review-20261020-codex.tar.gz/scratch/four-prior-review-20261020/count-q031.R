# Read the existing deposit as data only; never source S1.R or refit a model.
e <- new.env()
load("scratch/q031-naetscher-zenodo/S1.RData", envir = e)
x <- e$combi_samp
z <- x[is.finite(x$lnRR) & !is.na(x$warming), ]
cat(R.version.string, "\n")
cat("total", nrow(x), "eligible", nrow(z), "zero", sum(z$warming == 0),
    "positive", sum(z$warming > 0), "\n")
print(table(z$warming))
crisis <- z[z$warming > 0, ]
event <- rep(NA_character_, nrow(crisis))
codes <- list(PT = c(51,52), TJ = c(58,59), Toarcian = c(61,62),
              OAE1a = 74, OAE2 = c(76,77), PETM = c(83,84))
for (nm in names(codes)) {
  hit <- crisis$stg_num1 %in% codes[[nm]] & crisis$stg_num2 %in% codes[[nm]]
  stopifnot(all(is.na(event[hit])))
  event[hit] <- nm
}
stopifnot(!anyNA(event), nrow(crisis) == 432)
print(table(event, crisis$warming))

import csv,json,math,hashlib
from pathlib import Path
from collections import defaultdict,Counter
root=Path('data/raw/monarrez2023')
rows=[]
with (root/'pbdb.cleaned.classes.csv').open() as f:
 for x in csv.DictReader(f):
  if x['class'] in ['Rhynchonellata','Bivalvia']: rows.append(x)
byid=defaultdict(list); byname=defaultdict(list)
for x in rows:
 byid[x['genus_no']].append(x);byname[x['genus']].append(x)
def nonmissing(s):return s not in ('','NA')
bases=sorted({float(x['max_ma']) for x in rows},reverse=True)
unit=[]
for key,rr in byid.items():
 stages=sorted({bases.index(float(x['max_ma']))+1 for x in rr})
 unit.append(dict(unit=key,cl=rr[0]['class'],stages=stages,first=stages[0],last=stages[-1],
   sizes=sorted({float(x['logvol']) for x in rr if nonmissing(x['logvol'])}),
   families=sorted({x['family'] for x in rr if nonmissing(x['family'])}),
   orders=sorted({x['order'] for x in rr if nonmissing(x['order'])})))
ev=[]
for cl in ['Rhynchonellata','Bivalvia']:
 for k in [7,21,38,45,68]:
  cohort=[u for u in unit if u['cl']==cl and u['first']<k<=u['last']]
  ev.append(dict(cl=cl,k=k,N=len(cohort),D=sum(u['last']==k for u in cohort),
   unrecorded_focal=sum(k not in u['stages'] for u in cohort),
   gaps_with_no_prev=sum(k-1 not in u['stages'] for u in cohort),
   focal_gaps=[u['unit'] for u in cohort if k not in u['stages']][:6]))
# No true hazard selectivity; p differs by a known predictor. Observed loss is death OR surviving but missing.
h=.2;p=[.2,.8];q=[h+(1-h)*(1-v) for v in p]
a=q[0]*(1-q[1]);b=(1-q[0])*q[1];victim_prob=a/(a+b)
gain=victim_prob*math.log(2*victim_prob)+(1-victim_prob)*math.log(2*(1-victim_prob))
result=dict(hashes={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['pbdb.cleaned.classes.csv','encounter_history_bs_gr_5class_Big5.Rdata','genus.sizes.ranges.cleaned.classes.csv']},
 rows=len(rows),duplicate_occurrence_numbers=sum(n-1 for n in Counter(x['occurrence_no'] for x in rows).values()),
 id_class_conflicts={k:sorted({x['class'] for x in v}) for k,v in byid.items() if len({x['class'] for x in v})>1},
 name_id_conflicts={k:sorted({x['genus_no'] for x in v}) for k,v in byname.items() if len({x['genus_no'] for x in v})>1},
 multi_size_units={cl:sum(len(u['sizes'])>1 for u in unit if u['cl']==cl) for cl in ['Rhynchonellata','Bivalvia']},
 multi_family_units={cl:sum(len(u['families'])>1 for u in unit if u['cl']==cl) for cl in ['Rhynchonellata','Bivalvia']},
 multi_order_units={cl:sum(len(u['orders'])>1 for u in unit if u['cl']==cl) for cl in ['Rhynchonellata','Bivalvia']},
 missing_fields={key:sum(not nonmissing(x[key]) for x in rows) for key in ['genus_no','collection_no','reference_no','paleolat','paleolng']},
 events=ev,genus_units=len(unit),unit_size_examples=[u for u in unit if len(u['sizes'])>1][:3],
 detection_null=dict(biological_hazard=h,detection=p,observed_loss=q,prob_low_detection_is_only_observed_loss_given_D1=victim_prob,optimal_observed_log_gain_nats=gain))
Path('scratch/q038-review-20261020/audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['unit_size_examples','name_id_conflicts','id_class_conflicts']},indent=2))

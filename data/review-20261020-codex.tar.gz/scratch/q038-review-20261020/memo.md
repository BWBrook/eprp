# Q-038 independent predictor-contract review

Reviewer: Codex subagent | 20 October 2026 | Target: `9bfba9d`.

**Recommendation: accept the reproduced support evidence and several predictor rules; require material amendments before accepting this as an empirical prediction contract.** This does not park Q-038 or reopen the published-coefficient/flag dispute. The next useful product is one corrected target/observation/split contract with deterministic counterexamples, not a fit or a broad literature sweep.

## Scope and verification

Read `AGENTS.md`, `README.md`, `STATUS.md`, `docs/evidence.md`, Q-038/Q-006 register entries, both earlier Q-038 audits, the new README/support.R/six TSVs, the Q-006 CMR scope/matching notes, the preserved source paper's relevant Methods (pp. 3–4), and the deposited README. No board actions, contact, tracked edits, fit, new download or remote compute.

`Rscript --vanilla scratch/q038-review-20261020/replay.R` copies the support script with only its output directory changed; all six TSVs reproduce byte-for-byte (`replay-comparison.json`), using R 4.6.1 and one CPU. The three raw SHA256s match the earlier contract. `python3 scratch/q038-review-20261020/audit.py` independently checks IDs, event cohorts, duplicate rows, trait multiplicity and an exact detection-only counterexample; results are in `audit.json`. Raw files were read unchanged. The R rebuild completed in approximately three minutes, without a fit.

## Material findings, ranked

### 1. BLOCKER: observed-last-appearance score and the proposed detection-null gate are different targets

Evidence: `data/q038-predictor-contract/README.md:128–129,159–191`; `ideas/register.md:2579–2581`.

The proposed outcome is the observed last appearance. Detection covariates can validly predict that outcome even when biological losses are uniform. Therefore requiring a correctly specified joint model to recover **no predictive gain** under detection-only selectivity is false if the score remains the observed victim-set score. Adding CJS/Pradel terminology does not reconcile these targets, and “same covariates enter both” does not establish identification.

Exact counterexample (`audit.json`): two known incoming genera have equal biological loss probability 0.2, but post-boundary detection probabilities 0.2 and 0.8. The probabilities of an observed terminal loss are 0.84 and 0.36. Conditional on one observed loss, the low-detection genus is the victim with probability **0.90323**, producing a legitimate expected observed-score gain of **0.37521 nats** over uniform loss. True biological selectivity is zero. This is a finite occasion counterexample, not a theorem about Q-006's full count experiment.

Minimal repair: separately declare (i) predictive performance for fossil observations and (ii) latent biological victim selectivity. For (ii), use the generator's true deaths in synthetic validation and require zero biological selectivity/no systematic biological gain under a detection-only null, while permitting nonzero observed-history gain. Specify how the observation likelihood and uncertainty in membership, death identities and D connect to the conditional score; do not treat inferred deaths as certain test labels. Predefine tolerances and a positive-control alternative. Failure of one candidate model earns repair or a support hold, not an automatic scientific kill from this incoherent zero-score condition.

### 2. MAJOR: the incoming cohort and its standardisation use future records

Evidence: `README.md:119–140`; `support.R:137–148` (especially `lad >= k`).

“First recorded before k and alive at k by range-through” is a retrospective cohort: alive membership is inferred using focal/later occurrences. Two histories with the same prefix, `1,0,0` versus `1,0,1`, have different membership at the middle stage. Prefix predictors do not make the membership prospective. Scaling over that cohort also uses future-selected membership. This can be a declared retrospective conditional target, but it cannot simultaneously be described as fully available before k.

This is consequential in the actual event tables. For Bivalvia at the Late Devonian, **29/65** incoming genera have no occurrence at k and enter only through a later record; Rhynchonellata at the end-Triassic has **18/63**. At K–Pg Bivalvia the count is **50/269**. These are not known living censuses (`audit.json`).

Repair: choose explicitly between a retrospective range-through conditional comparison and a forecast conditional on the pre-k record with latent membership. For the latter, freeze the observed prefix/risk-set rule and integrate survival/membership uncertainty, as the register already requires. Standardise using training data alone or a clearly permitted pre-k candidate cohort; held-out-cohort normalisation is possible only if that cohort is genuinely supplied at prediction time. Include zero variance and all-missing rules. Excluding within-stage originations is sensible for a pre-recorded-cohort target, but does not itself solve this selection.

### 3. MAJOR: event holdout does not yet specify what information is forbidden

Evidence: `README.md:168–174`; `ideas/register.md:2579–2586`.

Forward chaining is appropriate for a historical forecast. Leaving one event out while training on later background and other events answers retrospective event transport, which is also useful, but different. Genera recur across stages; post-event detections and survival histories may disclose the focal event's fate, especially for the proposed persistent frailty/history models. Removing only the focal row is insufficient. The register's new-clade versus known-clade target is absent from the new contract.

Repair: state both targets if wanted, with fold-specific masking of all forbidden outcomes, detection histories, trait construction and latent-state smoothing. For a forward forecast, fit/filter on the prefix only; test outcomes stay unavailable. For retrospective transport, state exactly which same-genus histories are allowed and do not call the result prospective prediction. Define known-genus/known-clade and new-clade evaluation separately, including unseen levels. Predeclare the allowed use of later data for test-label adjudication separately from training and prediction.

### 4. MAJOR: unit selection is sensible, but the merged unit's size/clade attributes have no resolved mapping

Evidence: `README.md:100–116,147–155`; `support.R:54–60`; earlier `data/q038-monarrez-contract/README.md:50–53`.

PBDB genus_no is the right primary key, and merging subgenera avoids calling a subgenus loss a genus extinction. But a single fixed deposited name's size is not automatically a single merged-genus size: **140 Bivalvia and 9 Rhynchonellata IDs** have multiple `logvol` values. `unit_table` silently takes the first nonmissing value. **108 Bivalvia IDs** have multiple nonempty order labels, and **12** multiple family labels. Some order differences are likely nomenclatural (e.g. Cardiida/Veneroida), so these are unresolved mappings, not 108 proven biological contradictions. The known/unknown booleans do not resolve them. The input also contains 1,212 repeated occurrence numbers across these two classes from the previously recognised joins; distinct collection/reference/range calculations tolerate many of these, raw occurrence counts do not.

Repair: preserve source taxon and subgenus IDs, report multiplicity, and declare a frozen taxonomy/aggregation rule before building model rows. Do not select first row as the scientific rule. In the primary incoming K–Pg Bivalvia cohort, authors' units give **313/87** N/D versus **269/78** after merging (44 more units, 9 more losses); “unit sensitivity is small” is not established before examining predictions. This is a sensitivity in event identity, not duplicate-observation counting.

### 5. MAJOR: size timing restriction is sound; proposed rescue and source description overreach

Evidence: `README.md:148–155`; deposited `data/raw/monarrez2023/README.md:52–56,67–80`; source Methods pp. 3–4, preserved `scratch/q038-independent-audit/paper.txt:178–204`.

Keep size out of the primary prospective predictors until measurement provenance is recovered. The source describes figured specimens and **maximum biovolume**, not a dated specimen per merged genus. The type species' stratigraphic age does not establish the age of the specimen(s) supplying a genus's maximum size, nor resolve merged subgenera. Post-event measurement may leak information; the sign of resulting bias is not determined without the actual specimen/aggregation mechanism. “Predictable sign” from a Lilliput example is too strong.

Also, the source prefilters to genera with body-size data and stage-resolved records (Methods pp. 3; deposited README). Dropping size as a predictor does not remove that sample ascertainment. Scope empirical claims to this size-annotated, stage-resolved two-class archive unless representativeness is separately established. No fresh PBDB extraction is needed for the immediate amendment.

## Smaller corrections and accepted rules

- **Accept** the independent event-boundary indices, recorded-stage fallback plus recency, zero-distance versus absent-coordinate distinction, genus-ID choice, and separate new-within-stage stratum. Carry recency in Myr as well as stages when interpreting time because stage widths differ.
- `README.md:122–125` proposes modelling within-stage originations with clade and size alone. Keep the stratum descriptive or explicitly retrospective; its within-k ascertainment and undated size do not supply a pre-k forecast.
- `README.md:143` has the Ma age subtraction reversed. With positive Ma, use first-record base minus evaluation age; at k's midpoint this is a nonnegative age proxy with interval uncertainty, not an exact origination age. Fix the before-k evaluation time explicitly.
- `support.R:70` calls `sum(loc)` a count of located occurrences; it is not a count of distinct located localities. The range calculation correctly deduplicates coordinates. Export separate counts of occurrences, collections and distinct coordinate pairs; define missing continuous-range encoding plus its indicator.
- `README.md:102–107` says “four cases” but lists **five** class-event cases. There is also no explicit reason for omitting end-Triassic Rhynchonellata (33 incoming losses), while including Bivalvia (29). All ten class-event contrasts remain useful with partial pooling/uncertainty; event replication is five, not ten independent events. Do not select “informative events” after looking at gains.
- The 56–58% statement reproduces for **observed** background losses. It does not establish that missingness is correlated with true biological hazard; detection and retrospective ascertainment can generate that pattern. Reference-level counts are useful but not independent replicate sampling by definition. Define sampling opportunities/effort and geographic/environmental clustering; carrying the same predictors into detection and hazard is a model assumption requiring recovery checks. The old Q-006 78% result is one separate species-level stage sample, not a measured universal constant for this archive.
- `README.md:39–40` overstates uniqueness in both files: mapping splits occurrences by name and filters duplicated encounter-history names, but does not establish unique PBDB IDs per name (`support.R:28–34`). Seven names retained in the successful mapping span multiple genus IDs in these two classes. The **3,424 occupancy matches are real**, but validate name-aggregated histories, not the new merged-genus taxonomy.
- Fisher's conditional set likelihood is a coherent default if independent biological Bernoulli loss odds are exp(eta): P(S | D) is proportional to exp(sum eta_i in S), normalised over all size-D subsets. Wallenius represents a different sequential weighted-without-replacement process. Choose a generative story before fitting; disagreement is a model sensitivity, not a reason to compare whichever gives higher score. A detection layer generally breaks a direct identification of observed loss odds with biological hazard odds.

## Evidence depth and next bounded action

Primary material inspected locally: the preserved paper's relevant Methods in the full primary text, [Monarrez et al. 2023](https://doi.org/10.1098/rsos.230795), pp. 3–4, from [NSF PDF](https://par.nsf.gov/servlets/purl/10514226); the deposited README and CSV/Rdata, [Dryad](https://doi.org/10.5061/dryad.931zcrjqw). This is deeper than the register's older abstract-only label for this source. Existing Q-006 source-depth limits remain: its nearest-prior map contains metadata/abstract and recalled statements, while its scope note distinguishes the relevant Liow–Nichols text from abstract-only older papers. No fresh claim that arbitrary joint detection/hazard mixtures are identified is supported. Novelty against Monarrez/Smits–Finnegan/Tikhonov is not newly adjudicated here. Earlier deposited-flag results and unresolved provenance of published coefficients stay closed at their stated scope.

**Next owner: Claude.** Deliver one amended target/observation/fold specification and a small deterministic audit, keeping these support outputs preserved: (1) prefix-invariance risk-set/scaling test; (2) the detection-only observed-versus-latent counterexample plus positive control; (3) explicit transition/detection exposure and conditional-on-D likelihood equations; (4) merged-ID size/clade ambiguity export and declared mapping policy. This is sufficient to decide whether a small synthetic recovery feasibility probe is earned. Do not fit empirical data or commission a general CMR engine yet. No Barry-only decision is required for these repairs.

Review evidence, Codex, 21 October 2026
Baseline bd84335825142c63a5ac0beb1bdb0c60af6509ad.

Extract relative to the EPRP repository root; all members are ignored scratch
paths. SHA256SUMS covers every other regular member. No raw source is changed.

Q012: review_checks.py performs saved-chain hash checks, exact leapfrog replay,
all-coordinate AD/FD and repaired Q80 gates at the two preceding endpoints.
requalify.py recomputes existing diagnostics. Detailed output is checks.json
and diagnostics_recomputed.json. These need the pinned uv script environment,
the existing local instrumented binary and fetched P11 chain CSVs at paths
in the scripts; the binary hash and raw chain hashes are in the receipts.
They do not run fits or build a new binary. Original files are identified by
data/q012-pilot/results/P11-v6q80t-20261021/{fetch_archive,chain_files}.sha256.
The new checks are post-hoc reviews, not amendments of the frozen screen.

Q038: from repository root, run python3 on independent_checks.py, or Rscript
--vanilla on replay_checks.R. The latter is the source check script with only
its output directory changed; R emits its three outputs in the scratch path.
No estimator is fit. The source occurrence archive is an existing dependency.

Paper ledger: python3 scratch/paper-ledger-review-20261021/audit.py reproduces
the parsing/count/path audit. The fifteen purposive human-readable source
passage checks are reported in the review, not claimed as machine validation.

The source_hashes.json file pins relevant current sources. STATUS and the
new review prose are deliberately outside that pre-review source snapshot.

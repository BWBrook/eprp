# /// script
# requires-python = ">=3.12"
# dependencies = ["numpy==2.1.3", "pandas==2.2.3", "cmdstanpy==1.2.4", "arviz==0.20.0", "matplotlib==3.9.2", "xarray==2024.9.0", "scipy==1.14.1"]
# ///
import importlib.util, pathlib, json, gzip, hashlib, math, time
import numpy as np
import pandas as pd
root=pathlib.Path('/home/bwbrook/git/eprp')
work=root/'scratch/q012-final-review-20261021'
spec=importlib.util.spec_from_file_location('pilot',root/'data/q012-pilot/pilot.py')
p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
resdir=root/'data/q012-pilot/results/P11-v6q80t-20261021'
attempt=root/'scratch/q012-pilot/fetch-20261021-v6q80t/runs/P11/attempt1'
datafile=root/'data/q012-pilot/payload_v6q80t/data/P11.json'
d=json.loads(datafile.read_text()); names=p.param_names(d['N'])
out={'baseline':'bd84335825142c63a5ac0beb1bdb0c60af6509ad','checks':{},'sampling_replays':[]}
for line in (resdir/'chain_files.sha256').read_text().splitlines():
 sha,name=line.split();out['checks'][name]=hashlib.sha256((attempt/name).read_bytes()).hexdigest()==sha
allrows=[pd.read_csv(attempt/f'chain{k}.csv',comment='#') for k in range(1,5)]
out['chains']=[{'n':len(df),'divergences':int(df.divergent__.sum()),'ebfmi':float(np.mean(np.diff(df.energy__)**2)/np.var(df.energy__)),'max_depth':int(df.treedepth__.max())} for df in allrows]
df=pd.concat(allrows,ignore_index=True); tail=df[df.sigma>2]
out['posterior_descriptive_unqualified']={'N':len(df),'tail_n':len(tail),'tail_fraction':len(tail)/len(df),'corr_sigma_eta':float(df.sigma.corr(df.eta)),'corr_sigma_logk':float(df.sigma.corr(df.log_k)), 'eta_quantiles':dict(zip(['median','q95'],np.quantile(df.eta,[.5,.95]))),'eta_tail_quantiles':dict(zip(['median','q95'],np.quantile(tail.eta,[.5,.95])))}
exe=root/'scratch/q012-pilot/trace_build/model_v6'
out['local_binary_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
for k in [1,4]:
 for e in p.read_trace(attempt/f'chain{k}.trace.jsonl'):
  if e.get('type')!='divergence' or e.get('phase')!='sampling':continue
  m=np.array(e['inv_metric']); st={key:{'q':np.array(e[key]['q']),'p':np.array(e[key]['p']),'V':e[key]['V'],'g':np.array(e[key]['grad_V'])} for key in ['initial','previous','failing']}
  prev=st['previous'];fl=st['failing']; H=lambda s:s['V']+.5*float(s['p']@(m*s['p']))
  r={'chain':k,'transition':e['transition'],'initial_H_error':H(st['initial'])-e['H0'],'previous_H_error':H(prev)-e['H0'],'full_H_error':H(fl)-e['H0'],'full_local_H_error':H(fl)-H(prev)}
  q1,p1,V1,g1,err=p.leapfrog(exe,datafile,work/f'lp_chain{k}',prev['q'],prev['p'],prev['g'],m,e['signed_epsilon'])
  r['full_replay']={'q_exact':np.array_equal(q1,fl['q']),'p_exact':np.array_equal(p1,fl['p']),'H_rel_error':abs(V1+.5*float(p1@(m*p1))-e['H_raw'])/abs(e['H_raw']),'rejection':err}
  q,pp,g=prev['q'],prev['p'],prev['g']; r['half_steps']=[]
  for j in [1,2]:
   q,pp,V,g,err=p.leapfrog(exe,datafile,work/f'lp_chain{k}',q,pp,g,m,e['signed_epsilon']/2)
   h=V+.5*float(pp@(m*pp));r['half_steps'].append({'H_error_from_initial':h-e['H0'],'H_error_from_previous':h-H(prev),'rejection':err})
  r['fd']={}
  for key in ['previous','failing']:
   u=st[key]['q'];lp,g,err=p.lp_grad(exe,u,datafile,work/f'lp_chain{k}'); checks={}
   for i,nm in enumerate(names):
    h=1e-6*max(1,abs(u[i]));up=u.copy();dn=u.copy();up[i]+=h;dn[i]-=h
    a,_,e1=p.lp_grad(exe,up,datafile,work/f'lp_chain{k}');b,_,e2=p.lp_grad(exe,dn,datafile,work/f'lp_chain{k}')
    checks[nm]={'scaled_error':abs(g[i]-(a-b)/(2*h))/max(1,abs(g[i]))} if not(e1 or e2) else {'rejection':e1 or e2}
   r['fd'][key]={'coordinate_checks':checks,'max_scaled_error':max(v.get('scaled_error',float('inf')) for v in checks.values())}
  print('Starting previous normaliser gate chain',k,flush=True)
  t=time.time();r['previous_normaliser_gate']=p.gate_point(d,p.constrain(prev['q'],d['N']),extra=('log_k',))
  r['previous_normaliser_seconds']=time.time()-t
  out['sampling_replays'].append(r)
  (work/'checks.json').write_text(json.dumps(out,indent=2,default=float)+'\n')
  print('Completed chain',k,'normaliser',r['previous_normaliser_gate'].get('pass'),'FD',[r['fd'][x]['max_scaled_error'] for x in ['previous','failing']],flush=True)
out['parameter_dimensions']={'before':len(names),'frailties':d['N'],'after_frailties':len(names)-d['N'],'after_frailties_and_25baseline':len(names)-d['N']-25}
(work/'checks.json').write_text(json.dumps(out,indent=2,default=float)+'\n')
print('DONE',out['posterior_descriptive_unqualified'],flush=True)

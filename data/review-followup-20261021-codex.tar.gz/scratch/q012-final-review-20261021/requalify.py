# /// script
# requires-python = ">=3.12,<3.13"
# dependencies = ["numpy==2.1.3", "pandas==2.2.3", "cmdstanpy==1.2.4", "arviz==0.20.0", "matplotlib==3.9.2", "xarray==2024.9.0", "scipy==1.14.1"]
# ///
import importlib.util,pathlib,json
root=pathlib.Path('/home/bwbrook/git/eprp');work=root/'scratch/q012-final-review-20261021'
s=importlib.util.spec_from_file_location('pilot',root/'data/q012-pilot/pilot.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
attempt=root/'scratch/q012-pilot/fetch-20261021-v6q80t/runs/P11/attempt1'
r=p.diagnose(attempt,'P11',write=False)
(work/'diagnostics_recomputed.json').write_text(json.dumps(r,indent=2)+'\n')
old=json.loads((root/'data/q012-pilot/results/P11-v6q80t-20261021/diagnostics.json').read_text())
print('qualified',r['qualified'],'capture',r['capture']['valid'],'screening',r['screening'],'precision',r['precision'])
print('identical_report_except_path',all(r[k]==old[k] for k in r if k!='attempt'))
a=(58+2*3600+56*60+55)*4/3600
print('allocated_corehours',a,'total',20.717777777777776+a,'remaining',53.3333333333333-20.717777777777776-a)

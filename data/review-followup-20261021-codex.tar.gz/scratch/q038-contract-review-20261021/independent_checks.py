from itertools import product, combinations
from math import prod, exp, log
from pathlib import Path

def hist_prob(y, phi, p):
    a,d=1.,0.
    for t,yt in enumerate(y,1):
        an=a*phi[t-1]; dn=d+a*(1-phi[t-1])
        a=an*(p[t] if yt else 1-p[t]); d=0. if yt else dn
    return a+d

def chi(l,C,phi,p):
    v=1.
    for t in range(C-1,l-1,-1):
        v=1-phi[t]+phi[t]*(1-p[t+1])*v
    return v

def closed_likelihood(y,phi,p):
    l=max(t for t,yt in enumerate(y) if yt)
    return prod(phi[:l])*prod(p[t] if y[t] else 1-p[t] for t in range(1,l+1))*chi(l,len(y)-1,phi,p)

phi=[.83,.72,.91,.58,.86,.79]; p=[1,.22,.71,.43,.81,.32,.63]
max_lerr=0.
for tail in product((0,1),repeat=6):
    y=(1,)+tail
    max_lerr=max(max_lerr,abs(hist_prob(tail,phi,p)-closed_likelihood(y,phi,p)))
# Enumerate latent states and post detections conditional on an observed prefix.
k=3 # zero-based stage index: event is stage 4
M=3
max_pierr=max_qerr=0.
for pref_tail in product((0,1),repeat=k-1):
    pre=(1,)+pref_tail; l=max(t for t,y in enumerate(pre) if y)
    den=hist_prob(pref_tail,phi[:k-1],p[:k])
    mass=alive_event=postrecord=0.
    # survival until death j or full survival j=7; alive at t iff t<j
    for j in range(1,8):
        z=[int(t<j) for t in range(7)]
        zp=prod(phi[:min(j-1,6)])*(1-phi[j-1] if j<7 else 1)
        yp=prod((p[t] if pre[t] else 1-p[t]) if z[t] else int(not pre[t]) for t in range(1,k))
        w=zp*yp
        mass+=w; alive_event+=w*z[k]
        postrecord+=w*(1-prod(1-p[t] if z[t] else 1 for t in range(k+1,k+M+1)))
    pi=prod(phi[l:k])*prod(1-p[t] for t in range(l+1,k))/chi(l,k-1,phi,p)
    Q=1-p[k+M]
    for t in range(k+M-1,k,-1): Q=(1-p[t])*(1-phi[t]+phi[t]*Q)
    q=1-pi*phi[k]*(1-Q)
    max_pierr=max(max_pierr,abs(pi-alive_event/mass))
    max_qerr=max(max_qerr,abs(q-(1-postrecord/mass)))
# Severity matching cannot go below absence from old death/detection.
pis=[.2,.4]; Qs=[.2,.2]; floor=sum(1-pi*(1-Q) for pi,Q in zip(pis,Qs)); D=1
# A non-risk genus never seen since stage1 still has an event-dependent CJS tail.
phia=[.9]*6; phib=phia.copy(); phib[3]=.2
oldtaila=hist_prob((0,0,0,0,0,0),phia,[1]+[.5]*6)
oldtailb=hist_prob((0,0,0,0,0,0),phib,[1]+[.5]*6)
# Conditioning must be after integration (joint mixture / marginal count probability).
def pset(qs,S): return prod(q if i in S else 1-q for i,q in enumerate(qs))
qsA=[.9,.8]; qsB=[.4,.1]; S={0};
num=.5*pset(qsA,S)+.5*pset(qsB,S)
den=.5*sum(pset(qsA,set(s)) for s in combinations(range(2),1))+.5*sum(pset(qsB,set(s)) for s in combinations(range(2),1))
proper=num/den
avgconditional=.5*pset(qsA,S)/sum(pset(qsA,set(s)) for s in combinations(range(2),1))+.5*pset(qsB,S)/sum(pset(qsB,set(s)) for s in combinations(range(2),1))
qavg=[.65,.45]; plug=pset(qavg,S)/sum(pset(qavg,set(s)) for s in combinations(range(2),1))
lines=[f'64-history max likelihood absolute error: {max_lerr:.3g}',f'4-prefix max membership absolute error: {max_pierr:.3g}',f'4-prefix max observed-loss absolute error: {max_qerr:.3g}',f'severity counterexample q-sum lower bound={floor:.8f} > D={D}; no alpha root',f'non-risk old genus full-history likelihood event phi .9: {oldtaila:.10f}; event phi .2: {oldtailb:.10f}',f'mixture P(S|D)={proper:.10f}; average conditional={avgconditional:.10f}; averaged-q conditional={plug:.10f}']
Path('scratch/q038-contract-review-20261021/independent_checks.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
assert max_lerr<1e-12 and max_pierr<1e-12 and max_qerr<1e-12

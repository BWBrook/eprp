import csv, collections, hashlib, json, re
from pathlib import Path
root = Path(__file__).resolve().parents[2]
p = root / 'papers/question-first/evidence/decision-changes-draft.tsv'
rows = list(csv.DictReader(p.open(), delimiter='\t', quoting=csv.QUOTE_NONE))
paths = sorted(set(m for row in rows for m in re.findall(r'(?<![\w/])((?:ideas|literature|data)/[^\s:;()]+\.(?:md|tsv)|STATUS\.md)', row['source'])))
selected = ['DC-012', 'DC-019', 'DC-030', 'DC-071', 'DC-075', 'DC-084', 'DC-094', 'DC-096', 'DC-107', 'DC-119', 'DC-134', 'DC-138', 'DC-159', 'DC-173', 'DC-180']
result = {'source_sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'rows': len(rows), 'unique_ids': len({r['id'] for r in rows}), 'ragged_rows': [r['id'] for r in rows if None in r or None in r.values()], 'referenced_repository_paths': len(paths), 'missing_paths': [x for x in paths if not (root / x).is_file()], 'counts': {c: dict(collections.Counter(r[c] for r in rows)) for c in ['evidence_type', 'changed_by', 'basis']}, 'cost_present': sum(bool(r['cost_if_stated']) for r in rows), 'purposive_source_checks': selected, 'scope': 'Mechanical count/path audit and fifteen purposively selected source passages; not validation of all rows or a random sample.'}
Path(__file__).with_name('audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))

# Codex review evidence, 22 October 2026

This archive accompanies the Q-012 oracle review, Q-038 v2 contract review and
three paper case-history checks. All computations are post-hoc review evidence.
The archive contains no full oracle run 2, new model fit or recovery campaign.

- `scratch/q012-oracle-review-20261022/`: pinned oracle sources, run-1 recount,
  decision-control counterexamples, independent scalar reference and selected
  trace-state receipts. Follow its local replay instructions. The scalar check
  does not qualify the two- or three-node trees.
- `scratch/q038-v2-review-20261022/`: pinned contract/check source, byte-identical
  base-R outputs and standard-library Python finite counterexamples. Run
  `python3 scratch/q038-v2-review-20261022/independent_checks.py` for the latter.
  The R replay redirects only `out` from the pinned source; run
  `Rscript --vanilla scratch/q038-v2-review-20261022/replay_checks_v2.R` from
  the extraction root. These are exact finite probability checks, not
  fitted-model calibration.
- `scratch/case-history-review-20261022/`: nine commit-pinned source excerpts,
  full-file hashes and exact line references for three correction/acceptance
  chains; ledger recount pinned to d566f53. No claim of all-row verification.

The machine-readable manifest gives SHA256 and byte size for every other
archived file. Source revisions and dependencies remain identified in the
individual receipts. Extract from a repository root to recover these paths,
or into a temporary directory for standalone Q-012/Python checks. Preserve
original receipts when making new replay outputs.

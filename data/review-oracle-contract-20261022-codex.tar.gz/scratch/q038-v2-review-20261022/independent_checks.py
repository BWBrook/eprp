"""Finite counterexamples to extending fixed-path checks to dynamic covariates.

No empirical fit. Python standard library only. First example uses exactly the
contract's reference-level Bernoulli mechanism and log-mean-reference predictor.
"""
from itertools import product
import json
from math import exp, log, prod, sqrt
from pathlib import Path

out = Path(__file__).parent

# Known prefix: one recorded stage, with one reference. Fix theta=.5*mean refs
# (gamma_d=1), E_k=2 and E_(k+1)=1. Stage-k data are unobserved at origin.
# Reference count 2 changes next mean to 1.5; count 0 or 1 keeps it at 1.
a = 1 - exp(-.5)
weights = [(1-a)**2, 2*a*(1-a), a*a]
next_theta = [.5, .5, .75]
q_post = sum(w * exp(-th) for w, th in zip(weights, next_theta))
q_correct = .2 + .8*q_post  # membership 1, event survival .8
q_frozen = .2 + .8*exp(-.5)
assert abs(sum(weights)-1) < 1e-15

# With epsilon=.5, a stage's emission depends on its outgoing survival.
# Censoring after stage k therefore retains event information via that emission.
p = .6
pe = 1 - sqrt(1-p)
emission = {str(phi): phi*p+(1-phi)*pe for phi in (.2, .9)}

# Shared future standardisation can couple genera even at fixed parameters.
# Two iid future binary occupancy marks; next risk-set sample z-scores are
# either (0,0) or (+/-1/sqrt(2),-/+1/sqrt(2)). A unit logistic slope gives:
joint = {}
for outcomes in product((0, 1), repeat=2):
    prob = 0
    for marks in product((0, 1), repeat=2):
        z = [0, 0] if marks[0] == marks[1] else [(1 if m else -1)/sqrt(2) for m in marks]
        q = [1/(1+exp(-zi)) for zi in z]
        prob += .25*prod(qi if yi else 1-qi for qi, yi in zip(q, outcomes))
    joint[''.join(map(str, outcomes))] = prob
assert abs(sum(joint.values())-1) < 1e-15
assert abs(joint['10']+joint['11']-.5) < 1e-15

# The proposed occupancy-mean null permits real family selectivity. Fixed family
# hazard effects +/-.5 and zero occupancy slope, conditional on one loss among
# two members, yield this correctly predictive gain over uniform sets.
p_family = 1/(1+exp(-1))
gain_family = (p_family*log(2*p_family)+(1-p_family)*log(2*(1-p_family)))/2

result = {
    'binomial_reference_path': {
        'reference_detection_probability_at_k': a,
        'stage_k_count_probabilities_0_1_2': weights,
        'theta_k_plus_1_by_count': next_theta,
        'q_O_integrating_unobserved_stage_k_counts': q_correct,
        'q_O_freezing_predictor_at_origin': q_frozen,
        'difference': q_frozen-q_correct,
    },
    'epsilon_half_boundary_emission_by_event_survival': emission,
    'shared_future_standardisation': {
        'joint_probabilities': joint,
        'marginal_loss_each': .5,
        'product_of_marginals_for_each_set': .25,
    },
    'zero_occupancy_slope_with_family_effects_plus_minus_half': {
        'conditional_high_loss_family_is_victim': p_family,
        'expected_B_gain_nats_per_genus': gain_family,
        'proposed_null_gain_limit': .02,
    },
}
text = json.dumps(result, indent=2)+'\n'
(out/'independent_checks.json').write_text(text)
print(text, end='')

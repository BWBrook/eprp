"""Self-contained bounded audit; run with Python + numpy 2.1.3/scipy 1.14.1.

All scientific inputs are verified archive-local snapshots. Git/fetch traces
are unnecessary. Results default beside this script; existing files are never
overwritten. Use --output PATH to choose a fresh receipt name.
"""
import argparse
import ast
import hashlib
import json
import math
from pathlib import Path
import resource
import time
import types
import numpy as np
from scipy import integrate, optimize

OUT = Path(__file__).resolve().parent
ROOT = next((p for p in OUT.parents if (p/'.git').exists()),None)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=OUT/'audit_results_replay_v2.json')
args=parser.parse_args()
destination=args.output.resolve()
if destination.exists():
    raise FileExistsError(f'Refusing to overwrite receipt: {destination}')
INPUTS=json.loads((OUT/'pinned_inputs.json').read_text())
BASE = '4a9b4bbf65c37e267def60a825d8b1a4c4f7ddfb'
def source(path, ref=BASE):
    item=INPUTS[path]
    assert item['commit'].startswith(ref),(path,ref,item['commit'])
    raw=(OUT/item['archive_file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==item['sha256'],path
    return raw.decode()
def extract(src, names, ns):
    tree = ast.parse(src)
    chosen = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in names]
    assert len(chosen) == len(names)
    exec(compile(ast.Module(body=chosen, type_ignores=[]), '<pinned AST>', 'exec'), ns)

t0 = time.time()
src = source('data/q012-pilot/collapsed_oracle.py', '8962871')
ns = dict(np=np, math=math, time=time, resource=resource, optimize=optimize, integrate=integrate)
names = ['p_to_u','u_to_p','coefs','logF','dlogF','d2logF','simpson_ab','sinh_simpson','level_bounds','lse',
         'Unresolved','forest_precision','joint_mode','leaf_message','evaluator','grad','task']
extract(src, names, ns)
proto = dict(np=np, math=math)
extract(source('data/q012-prototype/prototype.py'), ['log_h0_of','cohort_A','test_point'], proto)
ns['P'] = types.SimpleNamespace(**{k:proto[k] for k in ['log_h0_of','cohort_A']})
ns['D'] = json.loads(source('data/q012-pilot/payload_v6q80t/data/P11.json'))
ns['N'] = ns['D']['N']
ns['NAMES'] = ['log_h0_1'] + [f'z_rw.{j}' for j in range(1,25)] + ['tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']
ns['FORESTS'] = {'T1_root':[(1,None)]}
ns['COHORT'] = {'T1_root':{1}}
ns['LOG2PI'], ns['H_FD'] = math.log(2*math.pi), 1e-4
ns['TOL'] = dict(value=1e-4,deriv=1e-3,self_value=1e-6,self_deriv=1e-5,unit=1e-8,selection=1e-6)

# Exact decision-control counterexamples, no numerical integrations performed.
fake = ns.copy()
extract(src, ['task'], fake)
fake.update(evaluator=lambda *a:0., ref_box=lambda *a:(np.zeros(1),np.ones(1),-np.ones(1),np.ones(1)), reference=lambda *a:0., log_pi_q80=lambda *a:0.,
            quad_reference=lambda *a:.01)
pe = proto['test_point'](ns['D'],0)
ignored_gk = fake['task'](('injected_GK_disagreement', pe, 'T1_root'))
def fail_eval(*args):
    raise ns['Unresolved']('injected evaluator mode failure')
fake['evaluator'] = fail_eval
misclassified = fake['task'](('injected_evaluator_failure', pe, 'T1_root'))

# Concave Gaussian: axis section widths do not bound projected mass.
a, delta = 1e6, 50.
axis_width = math.sqrt(2*delta/(1+a))
marginal_sd = math.sqrt((1+a)/(1+2*a))
gaussian = dict(precision='I + 1e6 * ones((2,2))', delta=delta, axis_halfwidth=axis_width,
               marginal_sd=marginal_sd, box_mass_upper_bound=math.erf(axis_width/(math.sqrt(2)*marginal_sd)))

# Independent scalar quadrature: its own scalar optimiser and tangent tail bounds,
# no evaluator level_bounds/sinh grid/mode. Shared local factors are explicitly declared.
def scalar_ref(p):
    cf = ns['coefs'](p,[1],{1})[0]
    sig, kb, kap = p['sigma'], p['kappa_b'], p['kappa']
    def g(x):
        with np.errstate(over='ignore',invalid='ignore'):
            return float(-x*x/(2*sig*sig)-math.log(sig)-.5*math.log(2*math.pi)+ns['logF'](cf,x,.5*sig*sig,kb,kap))
    def dg(x):
        return float(-x/(sig*sig)+ns['dlogF'](cf,x,.5*sig*sig,kb,kap))
    r=optimize.minimize_scalar(lambda x:-g(x), bounds=(-500,500), method='bounded', options={'xatol':1e-11})
    m, gm = r.x, g(r.x)
    lo, hi = m-sig, m+sig
    while g(lo)>gm-70: lo=m-2*(m-lo)
    while g(hi)>gm-70: hi=m+2*(hi-m)
    val, err = integrate.quad(lambda x:math.exp(g(x)-gm),lo,hi,points=[m],epsabs=0,epsrel=2e-12,limit=200)
    bound=(math.exp(g(lo)-gm)/abs(dg(lo))+math.exp(g(hi)-gm)/abs(dg(hi)))/val
    return gm+math.log(val), err/val, bound

points = {'central0':pe}
selected_q_sha256 = {}
receipts=json.loads((OUT/'selected_trace_states.json').read_text())
original=json.loads((OUT/'audit_results.json').read_text())
assert {r['point'] for r in receipts}=={'c1_failing','c4_previous'}
for r in receipts:
    qhash=hashlib.sha256(json.dumps(r['q'],separators=(',',':')).encode()).hexdigest()
    assert qhash==r['q_json_sha256']==original['selected_trace_q_sha256'][r['point']]
    points[r['point']]=ns['u_to_p'](r['q'][:35])
    selected_q_sha256[r['point']]=qhash
checks=[]
for name,p in points.items():
    u=ns['p_to_u'](p)
    ev, eg=ns['grad'](lambda v:ns['evaluator'](ns['u_to_p'](v),'T1_root'),u)
    rv, rg=ns['grad'](lambda v:scalar_ref(ns['u_to_p'](v))[0],u)
    _, qe, tb=scalar_ref(p)
    checks.append(dict(point=name,value_error=abs(ev-rv),max_deriv_error=float(np.max(abs(eg-rg))),
                       quad_relative_error=qe, relative_tangent_tail_bound=tb,
                       log_numerator=ev))
refinements = {}
u=ns['p_to_u'](points['c1_failing'])
for coord in ['sigma','kappa_b','log_k']:
    j=ns['NAMES'].index(coord)
    vals=[]
    for step in [1e-4,5e-5]:
        e=np.zeros(35);e[j]=step
        vals.append((scalar_ref(ns['u_to_p'](u+e))[0]-scalar_ref(ns['u_to_p'](u-e))[0])/(2*step))
    refinements[coord]=dict(h=vals[0],half_h=vals[1],difference=abs(vals[1]-vals[0]))
run1=json.loads((OUT/'run1_9ebc27c.json').read_text())
recount={s:sum(r['status']==s for r in run1['rows']) for s in {r['status'] for r in run1['rows']}}
result=dict(baseline=BASE,implementation='8962871211034c165f20bd3bc7adf49a588a1b52',
            repo_root_detected=str(ROOT) if ROOT is not None else None,
            input_receipts_sha256={p:hashlib.sha256((OUT/p).read_bytes()).hexdigest() for p in ['pinned_inputs.json','selected_trace_states.json','run1_9ebc27c.json']},
            ignored_gk_check={k:ignored_gk[k] for k in ['status','reference_qualified','quad_reference_minus_ref']},
            evaluator_exception_check=misclassified,gaussian_axis_section=gaussian,scalar_checks=checks,
            selected_trace_q_sha256=selected_q_sha256, fd_refinement_c1_failing=refinements,
            run1_recount=recount,wall_seconds=time.time()-t0,maxrss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
for key in ['ignored_gk_check','gaussian_axis_section','scalar_checks','selected_trace_q_sha256','fd_refinement_c1_failing','run1_recount']:
    assert result[key]==original[key],f'Replay changed {key}'
assert {k:v for k,v in misclassified.items() if k!='maxrss_kb'}=={k:v for k,v in original['evaluator_exception_check'].items() if k!='maxrss_kb'}
with destination.open('x') as stream:
    stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

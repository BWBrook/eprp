# Q-012 bounded review replay

This directory is a self-contained snapshot of the bounded scalar/decision
audit, not a replay of the full oracle. The original run receipts remain
`audit_initial_trace_dependent.py` and `audit_results.json`. The revised
`audit.py` was executed once from `/tmp`; its separate receipt is
`audit_results_replay_v2.json`. Scientific fields reproduced exactly.

From any working directory, use the script's extracted absolute path and a
fresh output filename, for example:

```sh
uv run --python 3.12 --with numpy==2.1.3 --with scipy==1.14.1 /absolute/extracted/path/audit.py --output /tmp/q012-oracle-new-replay.json
```

The script refuses to overwrite a receipt. Input/output defaults resolve
relative to the script, not the current working directory. Git root detection
is optional provenance and does not load inputs. No Git executable or checkout,
fetch trace, sampler, remote resource or unarchived data is required.

`pinned_inputs.json` binds oracle, prototype and P11 snapshot files to their
original repository paths, exact commits and SHA-256 values. The script
verifies those hashes before extracting the relevant functions with Python's
AST. The frozen run-1 JSON is used only for recounting the recorded statuses.

`selected_trace_states.json` contains the two full q vectors used by the
scalar checks. Each record retains the exact fetched source path, chain,
transition, state name, line number, exact source-line hash, canonical vector
hash, and source-file hash recorded in the committed chain manifest. The
source-file hash is explicitly labelled as manifest-derived; the large trace
files are not included. The vectors' hashes match the original audit receipt
and are verified during replay. The source lines/trajectories are unnecessary
because the audit consumes only the selected q vectors.

The local original-run script remains for provenance; use `audit.py` for
reproduction. The full-oracle source snapshots are evidence inputs and are
never launched by the bounded replay.

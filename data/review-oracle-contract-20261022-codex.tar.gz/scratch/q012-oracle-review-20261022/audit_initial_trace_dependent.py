"""Bounded audit: AST decision checks; scalar T1 checks only, no full oracle."""
import ast
import hashlib
import json
import math
from pathlib import Path
import resource
import subprocess
import time
import types
import numpy as np
from scipy import integrate, optimize

ROOT = Path('/home/bwbrook/git/eprp')
OUT = ROOT / 'scratch/q012-oracle-review-20261022'
BASE = '4a9b4bbf65c37e267def60a825d8b1a4c4f7ddfb'
def source(path, ref=BASE):
    return subprocess.check_output(['git', 'show', f'{ref}:{path}'], cwd=ROOT, text=True)
def extract(src, names, ns):
    tree = ast.parse(src)
    chosen = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in names]
    assert len(chosen) == len(names)
    exec(compile(ast.Module(body=chosen, type_ignores=[]), '<pinned AST>', 'exec'), ns)

t0 = time.time()
src = source('data/q012-pilot/collapsed_oracle.py', '8962871')
ns = dict(np=np, math=math, time=time, resource=resource, optimize=optimize, integrate=integrate)
names = ['p_to_u','u_to_p','coefs','logF','dlogF','d2logF','simpson_ab','sinh_simpson','level_bounds','lse',
         'Unresolved','forest_precision','joint_mode','leaf_message','evaluator','grad','task']
extract(src, names, ns)
proto = dict(np=np, math=math)
extract(source('data/q012-prototype/prototype.py'), ['log_h0_of','cohort_A','test_point'], proto)
ns['P'] = types.SimpleNamespace(**{k:proto[k] for k in ['log_h0_of','cohort_A']})
ns['D'] = json.loads(source('data/q012-pilot/payload_v6q80t/data/P11.json'))
ns['N'] = ns['D']['N']
ns['NAMES'] = ['log_h0_1'] + [f'z_rw.{j}' for j in range(1,25)] + ['tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']
ns['FORESTS'] = {'T1_root':[(1,None)]}
ns['COHORT'] = {'T1_root':{1}}
ns['LOG2PI'], ns['H_FD'] = math.log(2*math.pi), 1e-4
ns['TOL'] = dict(value=1e-4,deriv=1e-3,self_value=1e-6,self_deriv=1e-5,unit=1e-8,selection=1e-6)

# Exact decision-control counterexamples, no numerical integrations performed.
fake = ns.copy()
extract(src, ['task'], fake)
fake.update(evaluator=lambda *a:0., ref_box=lambda *a:(np.zeros(1),np.ones(1),-np.ones(1),np.ones(1)), reference=lambda *a:0., log_pi_q80=lambda *a:0.,
            quad_reference=lambda *a:.01)
pe = proto['test_point'](ns['D'],0)
ignored_gk = fake['task'](('injected_GK_disagreement', pe, 'T1_root'))
def fail_eval(*args):
    raise ns['Unresolved']('injected evaluator mode failure')
fake['evaluator'] = fail_eval
misclassified = fake['task'](('injected_evaluator_failure', pe, 'T1_root'))

# Concave Gaussian: axis section widths do not bound projected mass.
a, delta = 1e6, 50.
axis_width = math.sqrt(2*delta/(1+a))
marginal_sd = math.sqrt((1+a)/(1+2*a))
gaussian = dict(precision='I + 1e6 * ones((2,2))', delta=delta, axis_halfwidth=axis_width,
               marginal_sd=marginal_sd, box_mass_upper_bound=math.erf(axis_width/(math.sqrt(2)*marginal_sd)))

# Independent scalar quadrature: its own scalar optimiser and tangent tail bounds,
# no evaluator level_bounds/sinh grid/mode. Shared local factors are explicitly declared.
def scalar_ref(p):
    cf = ns['coefs'](p,[1],{1})[0]
    sig, kb, kap = p['sigma'], p['kappa_b'], p['kappa']
    def g(x):
        with np.errstate(over='ignore',invalid='ignore'):
            return float(-x*x/(2*sig*sig)-math.log(sig)-.5*math.log(2*math.pi)+ns['logF'](cf,x,.5*sig*sig,kb,kap))
    def dg(x):
        return float(-x/(sig*sig)+ns['dlogF'](cf,x,.5*sig*sig,kb,kap))
    r=optimize.minimize_scalar(lambda x:-g(x), bounds=(-500,500), method='bounded', options={'xatol':1e-11})
    m, gm = r.x, g(r.x)
    lo, hi = m-sig, m+sig
    while g(lo)>gm-70: lo=m-2*(m-lo)
    while g(hi)>gm-70: hi=m+2*(hi-m)
    val, err = integrate.quad(lambda x:math.exp(g(x)-gm),lo,hi,points=[m],epsabs=0,epsrel=2e-12,limit=200)
    bound=(math.exp(g(lo)-gm)/abs(dg(lo))+math.exp(g(hi)-gm)/abs(dg(hi)))/val
    return gm+math.log(val), err/val, bound

points = {'central0':pe}
selected_q_sha256 = {}
for ch,tr in [(1,2779),(4,2843)]:
    path=ROOT / f'scratch/q012-pilot/fetch-20261021-v6q80t/runs/P11/attempt1/chain{ch}.trace.jsonl'
    with path.open() as stream:
        for line in stream:
            r=json.loads(line)
            if r.get('type')=='divergence' and r['transition']==tr:
                key='failing' if ch==1 else 'previous'
                points[f'c{ch}_{key}']=ns['u_to_p'](r[key]['q'][:35])
                selected_q_sha256[f'c{ch}_{key}'] = hashlib.sha256(json.dumps(r[key]['q'],separators=(',',':')).encode()).hexdigest()
                break
checks=[]
for name,p in points.items():
    u=ns['p_to_u'](p)
    ev, eg=ns['grad'](lambda v:ns['evaluator'](ns['u_to_p'](v),'T1_root'),u)
    rv, rg=ns['grad'](lambda v:scalar_ref(ns['u_to_p'](v))[0],u)
    _, qe, tb=scalar_ref(p)
    checks.append(dict(point=name,value_error=abs(ev-rv),max_deriv_error=float(np.max(abs(eg-rg))),
                       quad_relative_error=qe, relative_tangent_tail_bound=tb,
                       log_numerator=ev))
refinements = {}
u=ns['p_to_u'](points['c1_failing'])
for coord in ['sigma','kappa_b','log_k']:
    j=ns['NAMES'].index(coord)
    vals=[]
    for step in [1e-4,5e-5]:
        e=np.zeros(35);e[j]=step
        vals.append((scalar_ref(ns['u_to_p'](u+e))[0]-scalar_ref(ns['u_to_p'](u-e))[0])/(2*step))
    refinements[coord]=dict(h=vals[0],half_h=vals[1],difference=abs(vals[1]-vals[0]))
run1=json.loads((OUT/'run1_9ebc27c.json').read_text())
recount={s:sum(r['status']==s for r in run1['rows']) for s in {r['status'] for r in run1['rows']}}
result=dict(baseline=BASE,implementation='8962871211034c165f20bd3bc7adf49a588a1b52',
            ignored_gk_check={k:ignored_gk[k] for k in ['status','reference_qualified','quad_reference_minus_ref']},
            evaluator_exception_check=misclassified,gaussian_axis_section=gaussian,scalar_checks=checks,
            selected_trace_q_sha256=selected_q_sha256, fd_refinement_c1_failing=refinements,
            run1_recount=recount,wall_seconds=time.time()-t0,maxrss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
(OUT/'audit_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

# Run-3 / v3 review evidence, 22 October 2026

Pinned source receipts, scripts and outputs accompany the three dated Codex
reviews. Q-012 audit.py reconstructs existing receipts and exercises small
control fixtures; it does not run the scientific batch. One separately
identified base-control diagnostic probe was run and its original script,
exact output, full QUADPACK diagnostics and frozen replay dependencies are
preserved. NumPy 2.1.3 and SciPy 1.14.1 were used. No gradient sweep or remote
job was launched by Codex.

Q-038 replay_oracle.R reproduces the tracked v3 TSV; independent_checks.R
supplies the conditional-likelihood and first-count counterexamples. Run from
the extraction root to retain the relative output-directory convention.
Paper receipts contain the five-file pinned amendment diff and source hashes.

Use temporary copies for replays to preserve original receipts. The manifest
hashes every other archived file. Parent decisions are in the dated repository
reviews; raw frozen results remain distinct from prospective amendments.

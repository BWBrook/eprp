# Independent finite checks; extract the actual pinned O7 function without
# rerunning the Monte Carlo oracle. No fitting or full simulation.
base <- "scratch/q038-v3-review-20261022"
env <- new.env(parent = globalenv())
for (expr in parse(file.path(base, "marked_history_oracle_pinned.R"))) {
  if (is.call(expr) && identical(expr[[1]], as.name("<-")) &&
      is.call(expr[[3]]) && identical(expr[[3]][[1]], as.name("function"))) eval(expr, env)
}

# Correct conditional law: include the first emission in the numerator as
# well as dividing by its probability. Death during final included stage C
# remains relevant when epsilon < 1.
correct_cut <- function(y, f, C, phi, p, eps) {
  pe <- 1 - (1 - p)^eps
  mass <- 0
  for (d in f:(C + 1)) {
    survive <- if (d > f) prod(phi[f:(d-1)]) else 1
    pr <- survive * if (d <= C) 1 - phi[d] else 1
    em <- 1
    for (t in f:C) {
      pt <- if (t > d) 0 else if (t == d && d <= C) pe[t] else p[t]
      em <- em * if (y[t] == 1) pt else 1 - pt
    }
    mass <- mass + pr * em
  }
  mass/(phi[f]*p[f]+(1-phi[f])*pe[f])
}

p <- c(.6, .5, .6, .5, .6)
ph <- function(v) { x <- rep(.8, 4); x[3] <- v; x }
H <- as.matrix(expand.grid(0:1, 0:1))
y <- c(1, 0, 1, 0, 1)
r <- list()
for (eps in c(1, .5)) {
  r[[paste0("actual_O7_total_eps",eps)]] <- sum(apply(H,1,function(z) env$lik_eps_cut(c(1,z),1,3,ph(.5),p,eps)))
  r[[paste0("correct_total_eps",eps)]] <- sum(apply(H,1,function(z) correct_cut(c(1,z),1,3,ph(.5),p,eps)))
  r[[paste0("correct_cut_at_k_range_eps",eps)]] <- diff(range(sapply(c(.2,.5,.9),function(v) correct_cut(y,1,3,ph(v),p,eps))))
  r[[paste0("correct_cut_before_k_range_eps",eps)]] <- diff(range(sapply(c(.2,.5,.9),function(v) correct_cut(y,1,2,ph(v),p,eps))))
}

# Conditioning on a positive first count and on its observed exact value are
# different for epsilon < 1. Both must follow from the same marked kernel.
theta <- .4; E <- 2; phi <- .7
a <- 1 - exp(-theta); ae <- 1 - exp(-.5*theta)
for (cc in 1:2) r[[paste0("epshalf_survival_given_first_count_",cc)]] <-
  phi*dbinom(cc,E,a)/(phi*dbinom(cc,E,a)+(1-phi)*dbinom(cc,E,ae))
r$epshalf_survival_given_first_positive <- phi*(1-(1-a)^E)/(phi*(1-(1-a)^E)+(1-phi)*(1-(1-ae)^E))

# Binary presence likelihood replicated for each possible positive mark is
# not a normalised count law. The fitter can use the v3 binomial kernel
# directly, retaining the same latent alive/dead forward marginalisation.
r$binary_as_marked_total <- 1-phi+phi*dbinom(0,E,a)+2*phi*(1-dbinom(0,E,a))
r$binomial_marked_total <- 1-phi+phi*sum(dbinom(0:E,E,a))

v <- data.frame(name=names(r),value=unlist(r),row.names=NULL)
write.table(v,file.path(base,"independent_checks.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
print(v,row.names=FALSE,digits=12)

"""One authorised base-reference diagnostic; no candidate/gradient evaluations."""
import ast,csv,gzip,hashlib,json,math,resource,time,types,warnings
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import integrate,optimize,special
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
t0=time.perf_counter()
names=['log_h0_1']+[f'z_rw.{j}' for j in range(1,25)]+['tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']
def extract(source,funcs,ns):
 tree=ast.parse(source);body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in funcs]
 assert len(body)==len(funcs)
 exec(compile(ast.Module(body=body,type_ignores=[]),'<pinned AST>','exec'),ns)
prior=ROOT/'scratch/q012-oracle-review-20261022'
proto=dict(np=np,math=math)
extract((prior/'prototype_4a9b4bb.py').read_text(),['log_h0_of','cohort_A','draw_to_params'],proto)
D=json.loads((prior/'P11_4a9b4bb.json').read_text())
o=dict(np=np,math=math,NAMES=names,N=D['N'],D=D,
       P=types.SimpleNamespace(**{k:proto[k] for k in ['log_h0_of','cohort_A']}))
extract((prior/'collapsed_oracle_8962871.py').read_text(),['p_to_u','u_to_p','coefs','logF'],o)
o['FORESTS']={'T3_root_two_daughters':[(2,None),(5,0),(7,0)]}
o['COHORT']={'T3_root_two_daughters':{2,5}}
bank=ROOT/'scratch/q012-pilot/fetch-20261018-v6p2/runs/P11/attempt1/chain2.csv'
row=pd.read_csv(bank,comment='#',nrows=1708).iloc[1707]
p=proto['draw_to_params'](row,D['N']);p['sigma']=8.
p=o['u_to_p'](o['p_to_u'](p))
point_receipt=dict(source_path=str(bank),data_row_zero_based=1707,source_sha256=hashlib.sha256(bank.read_bytes()).hexdigest(),
                   override_sigma=8.,roundtrip='p_to_u then u_to_p, as run_task',parameters=p,
                   dependency_sha256={f:hashlib.sha256((prior/f).read_bytes()).hexdigest() for f in ['prototype_4a9b4bb.py','P11_4a9b4bb.json','collapsed_oracle_8962871.py']})
(OUT/'quad_probe_point.json').write_text(json.dumps(point_receipt,indent=2)+'\n')
calls=[]
orig_quad=integrate.quad
def capturing_quad(f,*a,**kw):
 nonlocal_values={name:cell.cell_contents for name,cell in zip(f.__code__.co_freevars,f.__closure__ or [])}
 lf=nonlocal_values.get('logf');role='outer' if getattr(lf,'__name__',None)=='Hroot' else 'inner'
 result=orig_quad(f,*a,**kw)
 calls.append(dict(role=role,return_tuple_length=len(result),value=result[0],error=result[1],
                   estimated_relative_error=result[1]/result[0],neval=result[2]['neval'],epsrel=kw.get('epsrel'),
                   message=result[3] if len(result)>3 else None))
 return result
wrapped=types.SimpleNamespace(quad=capturing_quad,IntegrationWarning=integrate.IntegrationWarning)
ns=dict(np=np,math=math,time=time,warnings=warnings,integrate=wrapped,optimize=optimize,special=special,
        O=types.SimpleNamespace(**o),LOG2PI=math.log(2*math.pi),
        REF_SETTINGS={'primary':(1e-13,1e-12,0.),'tightened':(1.2e-14,1e-13,4.)},
        TOL=dict(ref_rel=1e-11,tail_rel=1e-14))
extract((OUT/'inputs/collapsed_oracle_refrepair.py').read_text(),['RefFail','_quad','envelope_integral','reference_value'],ns)
# Exactly one scientific reference call; all other work is metadata/fixtures.
value,receipt=ns['reference_value'](p,'T3_root_two_daughters','primary')
old=None
for line in gzip.open(OUT/'inputs/collapsed_oracle_run3_cells.jsonl.gz','rt'):
 r=json.loads(line)
 if r['key']=='holdout_9707_sigma8|T3_root_two_daughters|reference|primary|-1|0':old=r;break
assert old is not None
messages=[r for r in calls if r['message']]
result=dict(kind='one authorised reference-value diagnostic only',value=value,receipt=receipt,
            original_record=old,value_exactly_reproduced=value==old['value'],receipt_exactly_reproduced=receipt==old['receipt'],
            quad_calls=len(calls),quad_calls_with_returned_message=len(messages),messages_by_text={m:sum(r['message']==m for r in calls) for m in sorted({r['message'] for r in messages})},
            message_roles={role:sum(r['role']==role for r in messages) for role in ['inner','outer']},
            wall_seconds=time.perf_counter()-t0,maxrss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            numerical_versions=dict(numpy=np.__version__,pandas=pd.__version__))
(OUT/'quad_probe_calls.json').write_text(json.dumps(calls,indent=2)+'\n')
(OUT/'quad_probe_result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['receipt','original_record']},indent=2))

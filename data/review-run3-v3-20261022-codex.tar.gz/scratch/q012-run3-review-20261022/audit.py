"""Receipt reconstruction and tiny control fixtures only; no oracle evaluations."""
import ast
from collections import Counter
import gzip,hashlib,inspect,json,math
from pathlib import Path
import types,warnings
import numpy as np
from scipy import integrate

OUT=Path(__file__).resolve().parent
INP=OUT/'inputs'
for r in json.loads((OUT/'source_manifest.json').read_text()):
    assert hashlib.sha256((OUT/r['local']).read_bytes()).hexdigest()==r['sha256']
src=(INP/'collapsed_oracle_refrepair.py').read_text()
tree=ast.parse(src)
selected=['_quad','_stage','tasks','key','adjudicate_cell','all_pass','fixtures']
constants=['POINTS','FORESTS','EVAL_SETTINGS','REF_SETTINGS','H','TOL']
ns=dict(np=np,math=math,json=json,warnings=warnings,integrate=integrate)
chosen=[n for n in tree.body if (isinstance(n,ast.FunctionDef) and n.name in selected) or
        (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constants for t in n.targets))]
exec(compile(ast.Module(body=chosen,type_ignores=[]),'<pinned AST>','exec'),ns)
fixtures=ns['fixtures']();assert fixtures['all_ok']
records=[json.loads(s) for s in gzip.decompress((INP/'collapsed_oracle_run3_cells.jsonl.gz').read_bytes()).decode().splitlines() if s]
keys=[r['key'] for r in records];assert len(records)==4560 and len(set(keys))==len(keys)
expected={ns['key'](t) for t in ns['tasks']()};assert set(keys)==expected
by={r['key']:r for r in records}
assert all(r['ok'] for r in records)
NAMES=['log_h0_1']+[f'z_rw.{j}' for j in range(1,25)]+['tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']
run2=json.loads((INP/'collapsed_oracle_results_run2.json').read_text())
r2={(r['point'],r['forest']):r for r in run2['rows']}
post=json.loads((INP/'oracle_posthoc/selection_vs_qualified_reference.json').read_text())
raw=json.loads((INP/'collapsed_oracle_results_run3.json').read_text())
reconstructed=[];qualification=[];propagation=[]
for pt in ns['POINTS']:
 for fo in ns['FORESTS']:
  def get(kind,setting,j=-1,sign=0):return by[ns['key']((pt,fo,kind,setting,j,sign))]
  ev={}
  for setting in ns['EVAL_SETTINGS']:
   base=get('evaluator',setting)
   g=np.array([(get('evaluator',setting,j,1)['value']-get('evaluator',setting,j,-1)['value'])/(2*ns['H']) for j in range(35)])
   ev[setting]=(True,None,base['value'],g)
  base=get('reference','primary');tight=get('reference','tightened')
  refs=[get('reference','primary',j,s) for j in range(35) for s in [-1,1]]+[base,tight]
  for rec in refs:
   rc=rec['receipt'];outer=rc['outer'];inner=rc['inner'];k=1 if fo=='T2_pair' else 2
   total=outer['rel_err']+outer['tail_rel']+k*(inner['max_inner_rel']+inner['max_inner_tail'])
   q=total<=1e-11 and not rc['warnings'] and outer['tail_rel']<=1e-14 and inner['max_inner_tail']<=1e-14
   assert rec['total_rel']==rc['total_rel']==total
   assert q==rec['qualified']==rc['qualified']
   qualification.append(dict(key=rec['key'],qualified=q,total_rel=total,inner_rel=inner['max_inner_rel'],outer_rel=outer['rel_err'],
                             inner_above_requested_epsrel=inner['max_inner_rel']>ns['REF_SETTINGS'][rec['setting']][0],
                             warnings=rc['warnings'],inner_tail=inner['max_inner_tail'],outer_tail=outer['tail_rel']))
  rg=np.array([(get('reference','primary',j,1)['value']-get('reference','primary',j,-1)['value'])/(2*ns['H']) for j in range(35)])
  ref=(True,None,base['value'],rg,all(r['qualified'] for r in refs),tight['value']-base['value'])
  i2=post[pt]['T2_pair'];ids=dict(I1=r2[pt,fo]['I1_unit_log_numerator']<=1e-8,I2=abs(i2['eval_minus_qualified_ref'])<=1e-6 and i2['qualified'])
  cell=dict(evaluator=ev,reference=ref,identities=ids)
  status=ns['adjudicate_cell'](cell)
  out=dict(point=pt,forest=fo,run2_frozen_status=r2[pt,fo]['status'],amended_status=status,
           evaluator_value=ev['primary'][2],reference_value=ref[2],evaluator_gradient=ev['primary'][3].tolist(),reference_gradient=rg.tolist(),
           reference_all_values_qualified=ref[4],reference_tightened_change=ref[5])
  dg=np.abs(ev['primary'][3]-rg)
  out.update(value_abs_diff=abs(ev['primary'][2]-ref[2]),max_derivative_abs_diff=float(dg.max()),worst_coordinate=NAMES[int(dg.argmax())])
  for setting in ['resolution','domain']:
   out['evaluator_self_'+setting]=dict(value=abs(ev[setting][2]-ev['primary'][2]),deriv=float(np.max(abs(ev[setting][3]-ev['primary'][3]))))
  # Error estimates treated numerically, not as formal interval certificates.
  fd_unc=[]
  for j in range(35):
   ep,em=(get('reference','primary',j,s)['total_rel'] for s in [1,-1])
   fd_unc.append((-math.log1p(-ep)-math.log1p(-em))/(2*ns['H']))
  propagation.append(dict(point=pt,forest=fo,max_estimated_FD_uncertainty=max(fd_unc),
                          max_value_relative_error=max(r['total_rel'] for r in refs),unqualified_values=sum(not r['qualified'] for r in refs)))
  reconstructed.append(out)
assert reconstructed==raw['cells']
counts=dict(Counter(c['amended_status'] for c in reconstructed));assert counts==raw['amended_status_counts']
assert raw['all_pass']==ns['all_pass']([c['amended_status'] for c in reconstructed],run2['decomposition_pass'])
assert raw['missing_tasks']==0 and raw['decomposition_pass']==run2['decomposition_pass']

# Show that SciPy's actual full_output non-success message disappears in _quad.
origquad=integrate.quad
def restricted(*a,**kw):
 kw['limit']=2
 return origquad(*a,**kw)
tiny=types.SimpleNamespace(quad=restricted,IntegrationWarning=integrate.IntegrationWarning)
ns['integrate']=tiny
with warnings.catch_warnings(record=True) as caught:
 warnings.simplefilter('always')
 direct=restricted(lambda x:abs(x-.123456789),-1.,1.,points=[0.],epsabs=0,epsrel=1e-13,full_output=1)
 got=ns['_quad'](lambda x:abs(x-.123456789),-1.,1.,0.,1e-13)
quad_fixture=dict(scipy_return_tuple_length=len(direct),scipy_message=direct[3],python_warning_count=len(caught),
                  pinned_quad_reports_warnings=got[3],returned_relative_error=direct[1]/direct[0])
assert len(direct)>3 and not got[3]
quad_source=inspect.getsource(integrate.quad)
(OUT/'scipy_quad_full_output_excerpt.txt').write_text('\n'.join(line for line in quad_source.splitlines() if 'full_output' in line or 'warning' in line or 'message' in line)+'\n')

# Reproduce the now-archived host comparison and the committed hash receipt.
lraw=(INP/'collapsed_oracle_results_run2.json').read_bytes();draw=(INP/'collapsed_oracle_results_run2_deepserver.json').read_bytes()
receipt=json.loads((INP/'collapsed_oracle_run2_replication_receipt.json').read_text())
assert hashlib.sha256(lraw).hexdigest()==receipt['laptop_sha256']
assert hashlib.sha256(draw).hexdigest()==receipt['deepserver_sha256']
def flatten(x,p=''):
 if isinstance(x,dict):
  for k,v in x.items():yield from flatten(v,p+'/'+k)
 elif isinstance(x,list):
  for k,v in enumerate(x):yield from flatten(v,p+'/'+str(k))
 else:
  if '/seconds/' not in p and not p.endswith('/maxrss_kb') and p!='/wall_seconds':yield p,x
lf=dict(flatten(json.loads(lraw)));df=dict(flatten(json.loads(draw)))
assert len(lf)==1639 and set(lf)==set(df)
assert all(type(lf[k])==type(df[k]) and (lf[k].hex()==df[k].hex() if isinstance(lf[k],float) else lf[k]==df[k]) for k in lf)

summary=dict(source_commit='7269c5ec29f2e0f057bab2088d1941d532e1d29e',tasks=len(records),unique_tasks=len(keys),fixtures=fixtures,
             all16_cells_exactly_reconstructed=True,status_counts=counts,qualified_reference_values=sum(x['qualified'] for x in qualification),
             unqualified_reference_values=sum(not x['qualified'] for x in qualification),
             inner_rel_above_requested_count=sum(x['inner_above_requested_epsrel'] for x in qualification),
             cells_with_inner_rel_above_requested=sorted({r['key'].split('|')[0]+'|'+r['key'].split('|')[1] for r in qualification if r['inner_above_requested_epsrel']}),
             max_value_difference=max(c['value_abs_diff'] for c in reconstructed),max_derivative_difference=max(c['max_derivative_abs_diff'] for c in reconstructed),
             max_tail=max(max(x['inner_tail'],x['outer_tail']) for x in qualification),propagation=propagation,
             quad_status_fixture=quad_fixture,run2_replication=dict(compared_scalars=len(lf),differing=0,hashes_match=True))
(OUT/'audit_results.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'reference_qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
(OUT/'reconstructed_cells.json').write_text(json.dumps(reconstructed,indent=2)+'\n')
print(json.dumps(summary,indent=2))

"""Run-4 metadata reconstruction and supplied tiny fixtures; no candidate/batch run."""
import ast,gzip,hashlib,json,math,types,warnings
from collections import Counter
from pathlib import Path
import numpy as np
from scipy import integrate,optimize,special
OUT=Path(__file__).resolve().parent;INP=OUT/'inputs'
for receipt in json.loads((OUT/'source_manifest.json').read_text()):
 assert hashlib.sha256((OUT/receipt['local']).read_bytes()).hexdigest()==receipt['sha256']
def extract(src,names,ns):
 t=ast.parse(src);nodes=[n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
 assert len(nodes)==len(names)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'<pinned AST>','exec'),ns)
points=['stress_s3_r09_kbm15','c4_previous','c1_failing','holdout_c1f_sigma6','holdout_c1f_sigma20','holdout_c4f_sigma15','central0','holdout_9707_sigma8']
forests=['T2_pair','T3_root_two_daughters']
names=['log_h0_1']+[f'z_rw.{j}' for j in range(1,25)]+['tau','log_k','log_lambda0','kappa','log_b0','kappa_b','beta','gamma','sigma','rho']
tol=dict(value=1e-4,deriv=1e-3,self_value=1e-6,self_deriv=1e-5,tightened=1e-10,ref_disagreement=1e-6)
r1=dict(np=np,TOL=tol)
extract((INP/'collapsed_oracle_refrepair.py').read_text(),['adjudicate_cell','all_pass','key'],r1)
R1=types.SimpleNamespace(POINTS=points,FORESTS=forests,key=r1['key'],H=1e-4,
 EVAL_SETTINGS={'primary':(200,200,50.),'resolution':(400,400,50.),'domain':(200,200,70.)},
 adjudicate_cell=r1['adjudicate_cell'],all_pass=r1['all_pass'])
v2=dict(np=np,math=math,warnings=warnings,integrate=integrate,optimize=optimize,special=special,json=json,
 R1=R1,LOG2PI=math.log(2*math.pi),VERSION='refv2',SETTINGS={'primary':(1e-12,1e-11,0.),'tightened':(2e-13,2e-12,4.)},
 BUDGET=1e-10,TAIL=1e-14,TIGHT=1e-10,key=R1.key)
extract((INP/'collapsed_oracle_refrepair_v2.py').read_text(),['RefFail','_quad','envelope_integral','reference_value','tasks','fixtures'],v2)
raw4=json.loads((INP/'collapsed_oracle_results_run4.json').read_text())
refs=[json.loads(x) for x in gzip.decompress((INP/'collapsed_oracle_run4_reference.jsonl.gz').read_bytes()).decode().splitlines() if x]
keys=[r['key'] for r in refs];assert len(refs)==len(set(keys))==1152
assert set(keys)=={R1.key(t) for t in v2['tasks']()}
assert all(r['ok'] for r in refs)
by={r['key']:r for r in refs}
evrecords=[json.loads(s) for s in gzip.decompress((INP/'collapsed_oracle_run3_cells.jsonl.gz').read_bytes()).decode().splitlines() if s]
evby={r['key']:r for r in evrecords if r['kind']=='evaluator'}
run2=json.loads((INP/'collapsed_oracle_results_run2.json').read_text());r2={(r['point'],r['forest']):r for r in run2['rows']}
post=json.loads((INP/'oracle_posthoc/selection_vs_qualified_reference.json').read_text())
qualification=[]
for r in refs:
 rc=r['receipt'];inn=rc['inner'];outer=rc['outer'];k=1 if r['forest']=='T2_pair' else 2
 total=outer['rel_err']+outer['tail_rel']+k*(inn['max_inner_rel']+inn['max_inner_tail'])
 qualified=total<=1e-10 and not outer['diagnostics'] and inn['inner_diagnostic_calls']==0 and outer['tail_rel']<=1e-14 and inn['max_inner_tail']<=1e-14
 assert total==r['total_rel']==rc['total_rel']
 assert qualified==r['qualified']==rc['qualified']
 qualification.append(dict(key=r['key'],qualified=qualified,total_rel=total,
  inner_diagnostic_calls=inn['inner_diagnostic_calls'],outer_diagnostics=outer['diagnostics'],
  diagnostics=rc['diagnostics'],max_tail=max(outer['tail_rel'],inn['max_inner_tail'])))
cells=[];control=[];prop=[]
for pt in points:
 for fo in forests:
  def erec(st,j=-1,s=0):return evby[R1.key((pt,fo,'evaluator',st,j,s))]
  def rec(st,j=-1,s=0):return by[R1.key(('refv2',pt,fo,'reference',st,j,s))]
  ev={st:(True,None,erec(st)['value'],np.array([(erec(st,j,1)['value']-erec(st,j,-1)['value'])/(2e-4) for j in range(35)])) for st in R1.EVAL_SETTINGS}
  base,tight=rec('primary'),rec('tightened');allr=[base,tight]+[rec('primary',j,s) for j in range(35) for s in [-1,1]]
  rg=np.array([(rec('primary',j,1)['value']-rec('primary',j,-1)['value'])/(2e-4) for j in range(35)])
  ref=(True,None,base['value'],rg,all(r['qualified'] for r in allr),tight['value']-base['value'])
  q=r2[pt,fo];i2=post[pt]['T2_pair']
  cell=dict(evaluator=ev,reference=ref,identities=dict(I1=q['I1_unit_log_numerator']<=1e-8,I2=abs(i2['eval_minus_qualified_ref'])<=1e-6 and i2['qualified']))
  status=R1.adjudicate_cell(cell);dg=abs(ev['primary'][3]-rg)
  out=dict(point=pt,forest=fo,run2_frozen_status=q['status'],status_run4=status,
   reference_values_with_diagnostics=sum(bool(x['receipt']['diagnostics']) for x in allr),max_total_rel=max(x['total_rel'] for x in allr),reference_tightened_change=ref[5],
   value_abs_diff=abs(ev['primary'][2]-ref[2]),max_derivative_abs_diff=float(dg.max()),worst_coordinate=names[int(dg.argmax())],reference_gradient=rg.tolist())
  cells.append(out)
  errors=[(-math.log1p(-rec('primary',j,1)['total_rel'])-math.log1p(-rec('primary',j,-1)['total_rel']))/(2e-4) for j in range(35)]
  prop.append(dict(point=pt,forest=fo,max_estimated_FD_uncertainty=max(errors)))
  if pt=='holdout_9707_sigma8':
   w=names.index(q['worst_derivative_coordinate'])
   assert q['log_numerator_eval']==ev['primary'][2]
   assert q['derivative_eval_at_worst']==ev['primary'][3][w]
   control.append(dict(forest=fo,run2_status=q['status'],run2_reference_qualified=q['reference_qualified'],
    run2_checks=q['checks'],run2_I1=q['I1_unit_log_numerator'],run2_I2=q['I2_selection_minus_ref'],
    primary_value_matches_run3=True,saved_worst_coordinate_derivative_matches_run3=True,
    run3_self_checks={st:dict(value=abs(ev[st][2]-ev['primary'][2]),deriv=float(np.max(abs(ev[st][3]-ev['primary'][3])))) for st in ['resolution','domain']},
    run4_adaptive_value_difference=out['value_abs_diff'],run4_adaptive_max_derivative_difference=out['max_derivative_abs_diff']))
assert cells==raw4['cells']
counts=dict(Counter(c['status_run4'] for c in cells));assert counts==raw4['status_counts']
assert raw4['missing_cells']==0 and raw4['decomposition_pass']==run2['decomposition_pass']
assert raw4['all_pass']==R1.all_pass([c['status_run4'] for c in cells],run2['decomposition_pass'])

# Run only the supplied five small fixtures. Provide central0 directly rather
# than loading all ignored fetch traces. This makes two tiny reference calls.
proto=dict(np=np,math=math)
extract((INP/'prototype_4a9b4bb.py').read_text(),['log_h0_of','cohort_A','test_point'],proto)
D=json.loads((INP/'P11_4a9b4bb.json').read_text())
on=dict(np=np,math=math,N=D['N'],D=D,P=types.SimpleNamespace(log_h0_of=proto['log_h0_of'],cohort_A=proto['cohort_A']))
extract((INP/'collapsed_oracle_8962871.py').read_text(),['coefs','logF'],on)
v2['O']=types.SimpleNamespace(FORESTS={'T2_pair':[(2,None),(5,0)]},COHORT={'T2_pair':{2,5}},
 coefs=on['coefs'],logF=on['logF'],points=lambda:{'central0':proto['test_point'](D,0)})
fixtures=v2['fixtures']();assert fixtures['all_ok']
result=dict(result_commit='b6be66540770d1051c3afbbcf96e844c6b5f91f4',task_count=len(refs),all16_cells_reconstructed_exactly=True,
 status_counts=counts,qualified_values=sum(r['qualified'] for r in refs),unqualified_values=sum(not r['qualified'] for r in refs),
 maximum_estimated_relative_error=max(r['total_rel'] for r in refs),maximum_tail=max(x['max_tail'] for x in qualification),
 outer_diagnostic_values=sum(bool(x['outer_diagnostics']) for x in qualification),
 diagnostics_by_cell={pt+'|'+fo:sum(bool(r['receipt']['diagnostics']) for r in refs if r['point']==pt and r['forest']==fo) for pt in points for fo in forests},
 max_pass_value_difference=max(c['value_abs_diff'] for c in cells if c['status_run4']=='pass'),
 max_pass_derivative_difference=max(c['max_derivative_abs_diff'] for c in cells if c['status_run4']=='pass'),
 control_tensor_evidence=control,error_propagation=prop,fixtures=fixtures)
(OUT/'audit_results.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'reference_qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
(OUT/'reconstructed_cells.json').write_text(json.dumps(cells,indent=2)+'\n')
print(json.dumps(result,indent=2))

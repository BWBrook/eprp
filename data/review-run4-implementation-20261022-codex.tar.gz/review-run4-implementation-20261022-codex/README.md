# Codex review evidence, 22 October 2026

Source checkout: 1a8a7391dc8271f6e640b9ffd2d6e42e11b807d2.
Q-012 result: b6be665; implementation 0fe8961; declaration f863277.
Q-038 implementation: 690756f; pilot inputs 217fa2a; benchmark b0ccd5d.
Triton evidence read from immutable ebcee43, without a worktree change or rebuild.

Contents:
- q012-run4-review-20261022: pinned sources, 1,152-reference reconstruction,
  original run-2 tensor evidence, derivative reductions, and five tiny fixtures.
- q038-implementation-review-20261022: pinned source inventory, executable
  finite restart counterexample, count-law and prediction checks, actual-Stan
  log_prob input/output, all-five-dataset consistency checks. The compiled
  executable is hash-recorded but not copied; no fit or compilation was run.
- q038-cost-review-20261022: manifest/dataset hashes, actual fold row counts,
  allocated-core-hour projections, fixed-look coverage intervals and three
  finite exact-q timing examples. No recovery run or performance optimisation.
- parent_inputs: source/benchmark/contract snapshots and Triton side evidence.

Python checks used cached Python 3.12 with numpy 2.1.3/scipy 1.14.1; actual Stan
used the existing untracked executable. q012/audit.py uses its pinned inputs.
Q-038 scripts name /home/bwbrook/git/eprp and expect the pinned source checkout;
run them only against those sources in a disposable matching checkout.
Do not run the production checks.py or run.py from this archive: they can
write source-directory results or start fits. No such run is needed for review.
All source snapshots are evidence, not replacement current code.

Disposition: run 4 stays 14 pass / 2 adaptive-unresolved; qualified old tensor
controls plus 14 clean adaptive and 29 inherited cells close the finite evidence
for bounded interior-node/fixed-point P11 cost only. Q-038 full pilot retained;
LOEO restart repair before transport; full campaign redesign pending.

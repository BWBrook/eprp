"""Build three tiny existing-binary log_prob tests; no compilation or fit."""
exec((__import__('pathlib').Path(__file__).parent/'independent_checks.py').read_text())
gen=[]
for cl,f,pattern in [('Rhynchonellata',1,{1:2,6:1,9:2}),('Bivalvia',9,{9:1}),('Rhynchonellata',3,{3:1,5:2})]:
    c=np.zeros(10,dtype=int)
    for t,y in pattern.items():c[t]=y
    gen.append(dict(cls=cl,fam=3,ord=0,f=f,counts=c))
data=core.stan_data(gen,core.components(gen,('full',),d),d,likelihood_only=1,grainsize=1)
T=d['T']; cs=core.CLASSES
par=dict(alpha1=[p['alpha'][c][1] for c in cs],s_alpha=[1.,1.],
    z_alpha=[[p['alpha'][c][s]-p['alpha'][c][s-1] for s in range(2,T+1)] for c in cs],
    z_omega=[p['omega'][c] for c in cs],mu_omega=0.,s_omega=1.,
    beta_b=[p['beta_b'][c] for c in cs],beta_e=[p['beta_e'][c] for c in cs],
    z_delta=list(p['delta']),tau=1.,gam=[p['gamma'][c] for c in cs],
    z_fam=[list(p['f_fam'][c]) for c in cs],z_ord=[list(p['g_ord'][c]) for c in cs],s_fam=1.,s_ord=1.,
    gd0=[p['gd0'][c] for c in cs],gd=[p['gd'][c] for c in cs],
    z_b=[list(p['b_fam'][c]) for c in cs],s_b=1.,z_nu=[list(p['nu'][c][1:T+1]) for c in cs],s_nu=1.)
(HERE/'stan_data.json').write_text(json.dumps(data,default=lambda x:x.tolist()))
(HERE/'stan_params.json').write_text(json.dumps(par,default=lambda x:x.tolist()))
expected=sum(core.component_loglik(g['counts'],g['f'],T,g['cls'],g['fam'],g['ord'],p,d) for g in gen)
(HERE/'stan_expected.json').write_text(json.dumps(dict(python_loglik=expected,components=data['N'],rows=data['R']),indent=2)+'\n')
print('Python reference',expected)

"""Bounded implementation audit. No fits, compilation or full-design simulation."""
import copy
import importlib.util
import itertools
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path('/home/bwbrook/git/eprp')
HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location('q038_core', ROOT/'data/q038-probe/core.py')
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)
Dfull = core.load_design()
manifest = json.loads((ROOT/'data/q038-probe/manifest.json').read_text())
p = core.truth_params(np.random.default_rng(913), Dfull, manifest['omega_calibrated'])

# Old genus outside W, later captured again: restart must condition on capture
# without forgetting its original observed age and previous reference counts.
D = dict(Dfull)
D['T'] = 10
D['E'] = np.array([0]+[2]*10)
cnt = np.zeros(11,dtype=int)
cnt[1],cnt[8],cnt[9] = 2,1,2
g = dict(cls='Rhynchonellata',fam=3,ord=0,f=1,counts=cnt)
comps = core.components([g],('loeo',7),D)
assert comps == [(0,1,7),(0,8,10)]
ll_reset = core.component_loglik(cnt,8,10,g['cls'],3,0,p,D)

def suffix_likelihood(counts, original_f, restart, C, params):
    # Independently maintain alive/dead mass, conditional on detection at
    # restart. No contribution for any earlier transition, including event7.
    h = core.history_from_counts(counts,original_f,restart)
    alive,dead = 1.0,0.0
    for s in range(restart,C):
        ph = 1-core.plogis(core.eta(params,g['cls'],3,0,s,h.hazard_features(s,D)))
        alive,dead = alive*ph,dead+alive*(1-ph)
        th = core.theta(params,g['cls'],3,s+1,h.w(s+1))
        y = int(counts[s+1])
        alive *= math.exp(core.log_binom(y,int(D['E'][s+1]),th))
        if y>0:
            dead=0.0
        h.add(s+1,y)
    return math.log(alive+dead)

ll_retained = suffix_likelihood(cnt,1,8,10,p)
p_changed = copy.deepcopy(p)
for cl in core.CLASSES:
    p_changed['omega'][cl][0] += 10
p_changed['delta'][0] += 10
ll_retained_changed = suffix_likelihood(cnt,1,8,10,p_changed)
h_original = core.history_from_counts(cnt,1,8)
h_reset = core.History(8,1)
restart = dict(components=comps,
    reset_loglik=ll_reset,retained_history_loglik=ll_retained,
    difference=ll_reset-ll_retained,
    retained_history_change_under_heldout_event_parameters=ll_retained_changed-ll_retained,
    original_features_at_restart=h_original.hazard_features(8,D),
    reset_features_at_restart=h_reset.hazard_features(8,D),
    original_w_at9=h_original.w(9),reset_w_at9=h_reset.w(9))

# Enumerate small count histories through event7. Conditional initial counts
# are fixed, with delayed first record and C=f edge cases included.
def small_design(T):
    d=dict(Dfull);d['T']=T;d['E']=np.array([0]+[2]*T);return d
d=small_design(9)
mass={}
for f,C in ((1,4),(3,7),(6,9),(8,8)):
    for cf in (1,2):
        total=0
        for fut in itertools.product(range(3),repeat=C-f):
            c=np.zeros(10,dtype=int);c[f]=cf;c[f+1:C+1]=fut
            total+=math.exp(core.component_loglik(c,f,C,'Rhynchonellata',3,0,p,d))
        mass[f'f{f}_C{C}_firstcount{cf}']=total

# Extended exact forecast checks (M=1,2), including last-prefix detection and
# uncertain membership. Independent likelihood-ratio sum integrates stage k.
forecast=[]
for k,M,pattern in ((7,2,{1:2,4:1}),(7,2,{3:1,6:2}),(7,1,{6:1})):
    c=np.zeros(10,dtype=int)
    for t,n in pattern.items():c[t]=n
    f=min(pattern);h=core.history_from_counts(c,f,k-1)
    q=core.predict_q(h,k,M,'Rhynchonellata',3,0,p,d,exact=True)
    base=core.component_loglik(c,f,k-1,'Rhynchonellata',3,0,p,d)
    ref=0
    for ck in range(3):
        c2=c.copy();c2[k]=ck
        ref+=math.exp(core.component_loglik(c2,f,k+M,'Rhynchonellata',3,0,p,d)-base)
    mc=core.predict_q(h,k,M,'Rhynchonellata',3,0,p,d,n=4000,rng=np.random.default_rng(k+f))
    se=math.sqrt(mc*(1-mc)/4000)
    forecast.append(dict(k=k,M=M,pattern=pattern,exact=q,likelihood_ratio=ref,
                         absolute_difference=abs(q-ref),mc=mc,mc_se=se))

result=dict(restart_counterexample=restart,count_likelihood_totals=mass,forecast=forecast)
(HERE/'independent_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

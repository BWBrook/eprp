import hashlib
import json
import math
import pathlib
import sys
import time
import numpy as np
from scipy.stats import beta

ROOT = pathlib.Path('/home/bwbrook/git/eprp')
sys.path.insert(0, str(ROOT / 'data/q038-probe'))
import core
import run

OUT = ROOT / 'scratch/q038-cost-review-20261022'
m = run.load_manifest()
hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == h for p, h in m['inputs'].items()}
dataset_hashes = {}
for line in (run.OUT / 'SHA256SUMS').read_text().splitlines():
    h, p = line.split(maxsplit=1)
    dataset_hashes[p] = hashlib.sha256((run.OUT / p).read_bytes()).hexdigest() == h
D = core.load_design()
gen = run.load_data(38001)
folds = {}
for fold in [('full',)] + [(typ, k) for typ in ('forward', 'loeo') for k in core.EVENTS]:
    comps = core.components(gen, fold, D)
    folds['_'.join(map(str, fold))] = {'components': len(comps), 'rows': sum(C-f for _,f,C in comps)}
full_rows = folds['full']['rows']
b = json.loads((run.OUT / 'bench_38001.json').read_text())
core_hours = b['wall_seconds'] * (2000/200) * 4 * b['threads_per_chain']/3600
cp = []
for n in (20,30,40,60,100,200):
    x = int(round(.95*n))
    ci = [float(beta.ppf(.025,x,n-x+1)) if x else 0.0,
          float(beta.ppf(.975,x+1,n-x)) if x<n else 1.0]
    cp.append({'attempts':n,'covered':x,'coverage':x/n,'CI95':ci,
               'pass_original_gate': x/n>=.9 and ci[0]>=.85,
               'allocated_core_hours':n*core_hours})
# Actual-design exact q uses only the unobserved stage-k count as a branching mark.
# Positive counts after k are excluded by the target event; all later history is a zero path.
truth_rng = np.random.default_rng(38001)
p = core.truth_params(truth_rng,D,m['omega_calibrated'])
qchecks = []
for k in (7,38,68):
    eligible = [g for g in gen if g['f']<k and any(g['counts'][max(1,k-3):k]>0)]
    g = eligible[len(eligible)//2]
    h = core.history_from_counts(g['counts'],g['f'],k-1)
    t0 = time.perf_counter()
    qe = core.predict_q(h,k,3,g['cls'],g['fam'],g['ord'],p,D,exact=True)
    te = time.perf_counter()-t0
    t0 = time.perf_counter()
    qm = core.predict_q(h,k,3,g['cls'],g['fam'],g['ord'],p,D,n=2000,rng=np.random.default_rng(k))
    tm = time.perf_counter()-t0
    qchecks.append({'k':k,'E_k':int(D['E'][k]),'exact_q':qe,'exact_seconds':te,
                    'mc_q':qm,'mc_seconds':tm,'mc_plugin_SE':math.sqrt(qm*(1-qm)/2000)})
out = {'manifest_hashes':hashes,'dataset_hashes':dataset_hashes,'fold_counts':folds,
       'row_ratio_all_11_fits_to_full':sum(v['rows'] for v in folds.values())/full_rows,
       'row_ratio_forward_5_to_full':sum(v['rows'] for k,v in folds.items() if k.startswith('forward'))/full_rows,
       'row_ratio_loeo_5_to_full':sum(v['rows'] for k,v in folds.items() if k.startswith('loeo'))/full_rows,
       'projected_allocated_core_hours_per_full_fit':core_hours,
       'projected_allocated_core_hours_600_full_fits':600*core_hours,
       'coverage_precision_examples':cp,'exact_q_examples':qchecks}
(OUT/'audit_cost.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

"""Bounded structural replay; no Stan execution, C5 simulation, or production writes."""
import contextlib
import hashlib
import importlib.util
import io
import json
import pathlib
import subprocess
import sys
import time

import numpy as np

ROOT=pathlib.Path('/home/bwbrook/git/eprp')
HERE=ROOT/'data/q038-probe'
OUT=ROOT/'scratch/q038-diagnostic-review-20261023'
sys.path.insert(0,str(HERE))
import core
import run

t0=time.monotonic(); out={}
oldtext=subprocess.check_output(['git','show','217fa2a:data/q038-probe/core.py'],cwd=ROOT,text=True)
oldpath=OUT/'core_before_restart.py';oldpath.write_text(oldtext)
spec=importlib.util.spec_from_file_location('q038_old',oldpath);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
D=core.load_design();man=json.loads((HERE/'manifest.json').read_text())
samegen={}; samefold={}; nrestart=0; maxid=0.;maxrow=0.
for seed in man['seeds']:
    rng=np.random.default_rng(seed);p=core.truth_params(rng,D,man['omega_calibrated']);gen=core.simulate(rng,D,p)
    z=np.load(HERE/f'pilot/data_{seed}.npz')
    counts=np.array([g['counts'] for g in gen]);meta=np.array([[core.CLASSES.index(g['cls']),g['fam'],g['ord'],g['entry'],g['f'],g['death']] for g in gen])
    samegen[seed]=bool(np.array_equal(counts,z['counts']) and np.array_equal(meta,z['meta']))
    for fold in [('full',)]+[('forward',k) for k in core.EVENTS]:
        a=core.stan_data(gen,core.components(gen,fold,D),D)
        b=old.stan_data(gen,old.components(gen,fold,D),D)
        samefold[str((seed,fold))]=all(np.array_equal(np.asarray(a[k]),np.asarray(b[k])) for k in a)
    if seed!=38001: continue
    full=core.stan_data(gen,core.components(gen,('full',),D),D)
    fullrow={gi:full['c_tr0'][i]-1 for i,(gi,f,C) in enumerate(core.components(gen,('full',),D))}
    for kk in core.EVENTS:
        comps=core.components(gen,('loeo',kk),D);dk=core.stan_data(gen,comps,D)
        for i,(gi,f,C) in enumerate(comps):
            g=gen[gi]
            if f==g['f']:continue
            nrestart+=1
            def ll(a,b):return core.component_loglik(g['counts'],a,b,g['cls'],g['fam'],g['ord'],p,D)
            maxid=max(maxid,abs(ll(f,C)-(ll(g['f'],C)-ll(g['f'],f))))
            a=dk['c_tr0'][i]-1;b=fullrow[gi]+f-g['f']
            for j in range(C-f):
                maxrow=max(maxrow,float(np.max(np.abs(np.array(dk['tr_feat'][a+j])-np.array(full['tr_feat'][b+j])))),
                           abs(dk['em_w'][a+j]-full['em_w'][b+j]))
out.update(S2_regeneration_equal=samegen,full_forward_vs_217fa2a=samefold,seed38001_restart_count=nrestart,
           restart_suffix_identity_max_abs=maxid,restart_row_max_abs=maxrow)

# Execute the archived derivation text with only its output redirected to this scratch directory.
text=(HERE/'deposit_constants.py').read_text()
scratch_constants=OUT/'deposit_constants_rederived.json'
text=text.replace('open("data/q038-probe/deposit_constants.json","w")',f'open({str(scratch_constants)!r},"w")')
with contextlib.redirect_stdout(io.StringIO()) as cap:exec(compile(text,str(HERE/'deposit_constants.py'),'exec'),{})
out['deposit_derivation_stdout']=cap.getvalue()
out['deposit_constants_byte_identical']=scratch_constants.read_bytes()==(HERE/'deposit_constants.json').read_bytes()
out['derivation_source_hashes']={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in (
    'data/raw/monarrez2023/pbdb.cleaned.classes.csv','data/q038-predictor-contract/stages.tsv')}
out['wall_seconds']=time.monotonic()-t0
(OUT/'replay_structural.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))

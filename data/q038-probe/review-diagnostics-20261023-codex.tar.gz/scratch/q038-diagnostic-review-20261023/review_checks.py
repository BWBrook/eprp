"""Bounded read-only checks for the 23 October independent Q-038 review."""
import copy
import hashlib
import importlib.util
import itertools
import json
import math
import pathlib
import subprocess
import sys
import time
import warnings

import numpy as np
from scipy.special import gammaln, logsumexp

ROOT = pathlib.Path('/home/bwbrook/git/eprp')
HERE = ROOT / 'data/q038-probe'
OUT = ROOT / 'scratch/q038-diagnostic-review-20261023'
sys.path.insert(0, str(HERE))
import core
import score

t0 = time.monotonic()
out = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()}
out['source_sha256'] = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in sorted(HERE.glob('*')) if p.is_file()}
man = json.loads((HERE / 'manifest.json').read_text())
D = core.load_design()

# Recompute receipt-level screen and allocation arithmetic, not raw-draw diagnostics.
fits = [json.loads((HERE / f'pilot/fit_{s}.json').read_text()) for s in man['seeds']]
summary = json.loads((HERE / 'pilot/summary.json').read_text())
out['pilot_receipts'] = {'attempted': len(fits), 'pass_count': sum(r['divergences'] == 0 and r['rhat_max'] <= 1.01
                          and r['ess_bulk_min'] >= 400 and r['ess_tail_min'] >= 400 for r in fits),
                         'allocated_core_hours': [r['wall_seconds'] * 4 * r['threads_per_chain'] / 3600 for r in fits],
                         'screen_flags_match': all(r['success'] == (r['divergences'] == 0 and r['rhat_max'] <= 1.01
                             and r['ess_bulk_min'] >= 400 and r['ess_tail_min'] >= 400) for r in fits)}
out['pilot_receipts']['summary_allocation_max_diff'] = max(abs(a-b) for a,b in zip(
    out['pilot_receipts']['allocated_core_hours'], summary['allocated_core_hours']))
out['diagnostic_receipts'] = {}
for p in sorted((HERE / 'pilot').glob('diag_*.json')):
    r = json.loads(p.read_text())
    out['diagnostic_receipts'][p.name] = {k:r[k] for k in ('divergences', 'rhat_max', 'ess_bulk_min', 'ess_tail_min', 'success', 'wall_seconds')}
out['archived_input_hashes_match'] = all(hashlib.sha256((HERE/'pilot'/line.split()[1]).read_bytes()).hexdigest() == line.split()[0]
    for line in (HERE/'pilot/SHA256SUMS').read_text().splitlines())
bench = {}
for grain in (1,50,250):
    rows = [json.loads((HERE/f'pilot/tbench_t{t}_g{grain}.json').read_text()) for t in (1,2,3,4,6,8,12,16)]
    bench[grain] = [{'threads':r['threads'], 'seconds_per_gradient': (r['walls'][1]-r['walls'][0])/(r['gradients'][1]-r['gradients'][0]),
                    'efficiency':rows[0]['seconds_per_gradient']/(r['threads']*r['seconds_per_gradient'])} for r in rows]
out['benchmark_arithmetic'] = bench

# Exact covariance check of original iid effects, projected effects and scaled STZ.
out['prior_covariance'] = {}
for n in (8,40,87):
    J = np.ones((n,n))/n
    V = np.eye(n)-J
    exact = V+J
    scaled = n/(n-1)*V
    out['prior_covariance'][n] = {'exact_reconstruction_max_error':float(abs(exact-np.eye(n)).max()),
                                'original_contrast_variance_s1':2.,
                                'stz_contrast_variance_s1':float(scaled[0,0]+scaled[1,1]-2*scaled[0,1]),
                                'stz_cross_cov_s1':float(scaled[0,1])}

# Likelihood is identical at independently centered parameter points if means are moved to intercepts.
p = core.truth_params(np.random.default_rng(913), D, man['omega_calibrated'])
pc = copy.deepcopy(p)
for c in core.CLASSES:
    pc['alpha'][c] += p['f_fam'][c].mean()+p['g_ord'][c].mean()
    pc['gd0'][c] += p['b_fam'][c].mean()+p['nu'][c][1:].mean()
    for key in ('f_fam','g_ord','b_fam'):
        pc[key][c] -= p[key][c].mean()
    pc['nu'][c][1:] -= p['nu'][c][1:].mean()
cnt = np.zeros(11,dtype=int); cnt[1],cnt[8],cnt[9] = 2,1,2
Dc = dict(D,T=10,E=np.array([0]+[2]*10))
suf = core.component_loglik(cnt,8,10,'Rhynchonellata',3,0,p,Dc)
out['restart_counterexample'] = {'suffix':suf,'original_review_difference':suf-(-8.9884258733),
    'likelihood_after_centering_difference':core.component_loglik(cnt,8,10,'Rhynchonellata',3,0,pc,Dc)-suf}

# Independent direct alive/dead recursion for a short restarted component, conditional on all observed marks.
def direct(cnt,f,C):
    alive,dead=1.,0.
    origin=int(np.flatnonzero(cnt)[0])
    for s in range(f,C):
        times=[t for t in range(origin,s+1) if cnt[t]>0 and (t<s or t==origin)]
        l=times[-1]; tf=Dc['tf']
        x=(math.log(cnt[l])-tf['log_refs']['mean'])/tf['log_refs']['sd']
        r=(max(0.,Dc['minma'][l]-Dc['maxma'][s])-tf['rec']['mean'])/tf['rec']['sd']
        a=(Dc['maxma'][origin]-Dc['maxma'][s]-tf['age']['mean'])/tf['age']['sd']
        cm=(len(times)/(l-origin+1)-tf['comp']['mean'])/tf['comp']['sd']
        c='Rhynchonellata'
        et=p['alpha'][c][s]+np.dot(p['gamma'][c],[r,a,cm])+p['f_fam'][c][3]+p['g_ord'][c][0]
        et += p['omega'][c][core.EVENTS.index(s)]+(p['beta_e'][c]+p['delta'][core.EVENTS.index(s)])*x if s in core.EVENTS else p['beta_b'][c]*x
        hazard=1/(1+math.exp(-et)); dead+=alive*hazard; alive*=1-hazard
        prev=cnt[origin:s+1]; prev=prev[prev>0]
        w=math.log(prev.mean())
        th=math.exp(p['gd0'][c]+p['gd'][c]*w+p['b_fam'][c][3]+p['nu'][c][s+1])
        y=int(cnt[s+1]); n=int(Dc['E'][s+1]); pr=-math.expm1(-th)
        alive*=math.comb(n,y)*pr**y*(1-pr)**(n-y)
        if y: dead=0.
    return math.log(alive+dead)
out['restart_counterexample']['independent_direct_difference']=direct(cnt,8,10)-suf

# Pooling class-specific uniform nulls creates apparent B gain against a pooled uniform reference.
q=np.array([.2,.2,.8,.8]); lq=np.repeat(np.log(q)[:,None],20,axis=1); l1=np.repeat(np.log1p(-q)[:,None],20,axis=1)
gain=0.; mass=0.
for bits in itertools.product((0,1),repeat=4):
    if sum(bits)!=2: continue
    prob=float(np.prod(np.where(bits,q,1-q)))
    gain+=prob*score.set_scores(lq,l1,bits)['gain_per_genus'];mass+=prob
out['pooled_uniform_class_null']={'expected_conditional_gain_per_genus_D2':gain/mass,'P_D2':mass,
    'within_each_class_expected_conditional_gain':0.}

# Finite mathematical score identity and the probability-DP underflow counterexample.
q=np.array([[.1,.6,.3],[.7,.2,.8],[.4,.5,.1]])
tot={d:0. for d in range(4)}
for bits in itertools.product((0,1),repeat=3):
    tot[sum(bits)]+=math.exp(score.set_scores(np.log(q),np.log1p(-q),bits)['conditional'])
out['independent_set_normalisation_max_error']=max(abs(v-1) for v in tot.values())
with warnings.catch_warnings():
    warnings.simplefilter('ignore')
    n=1000; qs=.99
    ll=np.full((n,20),math.log(qs)); lc=np.full((n,20),math.log1p(-qs)); bits=np.zeros(n,bool);bits[0]=1
    sc=score.set_scores(ll,lc,bits)
    out['score_DP_extreme']={'N':n,'q':qs,'D':1,'returned_conditional':sc['conditional'],'expected_conditional':-math.log(n)}

out['wall_seconds']=time.monotonic()-t0
(OUT/'review_checks.json').write_text(json.dumps(out,indent=2,allow_nan=True)+'\n')
print(json.dumps(out,indent=2,allow_nan=True))

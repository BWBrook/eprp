"""Terminal Q038 review: fixed arithmetic/likelihood only; no fits or raw PBDB access."""
import copy
import hashlib
import itertools
import json
import math
import pathlib
import subprocess
import sys
import time
import warnings

import numpy as np
from scipy.special import logsumexp
from scipy.stats import norm

ROOT=pathlib.Path('/home/bwbrook/git/eprp');HERE=ROOT/'data/q038-probe';OUT=ROOT/'scratch/q038-terminal-review-20261023'
sys.path.insert(0,str(HERE))
import core
import score

t0=time.monotonic();out={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}
paths=['score.py','score_checks.json','model.stan','model_ctr.stan','ctr_checks.py','ctr_checks.json','run.py','README.md']
out['hashes']={p:hashlib.sha256((HERE/p).read_bytes()).hexdigest() for p in paths}
attempts=[]
for pattern in ('fit_*.json','diag_*.json'):
 for p in sorted((HERE/'pilot').glob(pattern)):
  r=json.loads(p.read_text());passed=r['divergences']==0 and r['rhat_max']<=1.01 and r['ess_bulk_min']>=400 and r['ess_tail_min']>=400
  attempts.append(dict(file=p.name,seed=r['seed'],tag=r['tag'],screen=passed,reported_screen=r['success'],divergences=r['divergences'],rhat=r['rhat_max'],
    ess_bulk=r['ess_bulk_min'],ess_tail=r['ess_tail_min'],allocated_core_hours=r['wall_seconds']*4*r['threads_per_chain']/3600,
    sampling=r['sampling'],warmup=r['warmup'],threads=r['threads_per_chain']))
out['attempts']=attempts
out['full_fit_attempt_count']=len(attempts);out['full_fit_screen_pass_count']=sum(r['screen'] for r in attempts)
out['allocated_core_hours_full_fit_total']=sum(r['allocated_core_hours'] for r in attempts)
out['ctr99_core_hours_total']=sum(r['allocated_core_hours'] for r in attempts if r['tag']=='diag_ctr99')
out['fullfit_raw_CSV_directories_present']=[p.name for p in (HERE/'pilot').iterdir() if p.is_dir() and (p.name.startswith('fit_') or p.name.startswith('diag_'))]

# Independent mixture-law enumeration, including class-specific uniform null.
q=np.array([[.05,.7,.3],[.4,.6,.2],[.8,.2,.6],[.3,.5,.9]])
err=0.; totals={d:0. for d in range(5)}
for bits in itertools.product((0,1),repeat=4):
 bits=np.array(bits,bool);d=int(bits.sum());sc=score.set_scores(np.log(q),np.log1p(-q),bits)
 numerator=np.prod(np.where(bits[:,None],q,1-q),axis=0).sum()
 denominator=sum(np.prod(np.where(np.isin(range(4),subset)[:,None],q,1-q),axis=0).sum() for subset in itertools.combinations(range(4),d))
 expected=math.log(numerator/denominator)
 err=max(err,abs(expected-sc['conditional']));totals[d]+=math.exp(sc['conditional'])
out['score_mixture_vs_enumeration_max_abs']=err;out['score_set_normalisation_max_abs']=max(abs(v-1) for v in totals.values())
n=1000;ll=np.full((n,3),math.log(.99));lc=np.full((n,3),math.log(.01));bits=np.zeros(n,bool);bits[0]=1
out['score_rare_D1']=score.set_scores(ll,lc,bits)
out['score_rare_D1_error']=out['score_rare_D1']['conditional']+math.log(n)

D=core.load_design();D['T']=10;D['E']=np.array([0]+[2]*10)
om={c:[1.]*5 for c in core.CLASSES};p=core.truth_params(np.random.default_rng(31),D,om)
gen=[]
for ci,c in enumerate(core.CLASSES):
 p['alpha'][c]+=np.arange(11)*.02
 for j in range(3):
  cnt=np.zeros(11,int);cnt[1]=1
  if j==0:cnt[6]=1;cnt[8]=1
  elif j==1:cnt[6]=2
  else:cnt[8]=1;cnt[9]=2
  gen.append(dict(cls=c,fam=j,ord=0,entry=1,f=1,death=7 if j==1 else 10,counts=cnt))
P=score.stack([copy.deepcopy(p) for _ in range(20)])
out['score_event_class_keys']=list(score.score_event(gen,7,P,D))
out['score_event_outputs']=score.score_event(gen,7,P,D)
with warnings.catch_warnings():
 warnings.simplefilter('ignore')
 try:out['score_empty_class_result']=score.score_event([g for g in gen if g['cls']==core.CLASSES[0]],7,P,D)
 except Exception as e:out['score_empty_class_exception']=str(e)
 out['score_zero_probability_endpoint']=score.set_scores(np.zeros((4,20)),np.full((4,20),-np.inf),[False]*4)

# Prior coupling is conditional scale dependence; it is not a zero-width funnel at zero scales.
out['intercept_coupling']={}
for s in (.3,.5,1.,float(.5*norm.ppf(.995))):
 va=2.25+s*s*(1/40+1/8);vd=4+s*s*(1/40+1/87)
 out['intercept_coupling'][str(s)]={'alpha_variance_relative_increase':va/2.25-1,'alpha_sd_relative_increase':math.sqrt(va)/1.5-1,
   'gd0_variance_relative_increase':vd/4-1,'gd0_sd_relative_increase':math.sqrt(vd)/2-1,
   'dlog_alpha_sd_d_s_ord':s/(8*va),'dlog_gd0_sd_d_s_b':s/(40*vd)}
out['joint_prior_covariance_max_error']=max(float(np.max(abs((a*a+s*s/n)*np.ones((n,n))+s*s*(np.eye(n)-np.ones((n,n))/n)-(a*a*np.ones((n,n))+s*s*np.eye(n)))))
  for n in (8,40,87) for s in (.2,.5,1.) for a in (1.5,2.))

# Existing binaries only: two classes, positive counts >1, restart and censoring, nonunit effect scales.
from cmdstanpy import CmdStanModel
c2=core.CLASSES
orig=dict(alpha1=[p['alpha'][c][1] for c in c2],s_alpha=[.2,.2],z_alpha=[[(p['alpha'][c][s]-p['alpha'][c][s-1])/.2 for s in range(2,11)] for c in c2],
 z_omega=[p['omega'][c] for c in c2],mu_omega=0.,s_omega=1.,beta_b=[p['beta_b'][c] for c in c2],beta_e=[p['beta_e'][c] for c in c2],
 z_delta=list(p['delta']),tau=1.,gam=[p['gamma'][c] for c in c2],gd0=[p['gd0'][c] for c in c2],gd=[p['gd'][c] for c in c2],
 s_fam=.3,s_ord=.3,s_b=.3,s_nu=.2)
for key,src,s in [('z_fam','f_fam',.3),('z_ord','g_ord',.3),('z_b','b_fam',.3),('z_nu','nu',.2)]:
 orig[key]=[(np.array(p[src][c][1:] if src=='nu' else p[src][c])/s).tolist() for c in c2]
ctr=copy.deepcopy(orig)
for i,c in enumerate(c2):
 ctr['alpha1'][i]+=orig['s_fam']*np.mean(orig['z_fam'][i])+orig['s_ord']*np.mean(orig['z_ord'][i])
 ctr['gd0'][i]+=orig['s_b']*np.mean(orig['z_b'][i])+orig['s_nu']*np.mean(orig['z_nu'][i])
for key in ('z_fam','z_ord','z_b','z_nu'):ctr[key]=[(np.array(v)-np.mean(v)).tolist() for v in orig[key]]
m0=CmdStanModel(stan_file=str(HERE/'model.stan'),exe_file=str(HERE/'model'),compile=False)
m1=CmdStanModel(stan_file=str(HERE/'model_ctr.stan'),exe_file=str(HERE/'model_ctr'),compile=False)
out['actual_Stan']={}
for fold in (('full',),('loeo',7)):
 data=core.stan_data(gen,core.components(gen,fold,D),D,likelihood_only=1,grainsize=1)
 a=m0.log_prob(params=orig,data=data,jacobian=False,sig_figs=18)
 b=m1.log_prob(params=ctr,data=data,jacobian=False,sig_figs=18)
 common=[c for c in a.columns if c in b.columns and c!='lp__' and not any(c.removeprefix('g_').startswith(x) for x in ('z_fam','z_ord','z_b','z_nu','s_fam','s_ord','s_b','s_nu'))]
 out['actual_Stan'][str(fold)]={'loglik_orig':float(a['lp__'].iloc[0]),'loglik_ctr':float(b['lp__'].iloc[0]),'shared_gradient_count':len(common),
  'max_abs_shared_gradient_difference':float(np.max(abs(a[common].values-b[common].values)))}
out['binary_hashes']={p:hashlib.sha256((HERE/p).read_bytes()).hexdigest() for p in ('model','model_ctr')}
out['wall_seconds']=time.monotonic()-t0
(OUT/'terminal_checks.json').write_text(json.dumps(out,indent=2,allow_nan=True)+'\n')
print(json.dumps(out,indent=2,allow_nan=True))
